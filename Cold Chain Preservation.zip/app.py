"""
app.py — Phase 4: Cold-Chain Operations dashboard (Streamlit).

Run:
    streamlit run app.py -- --data-dir data --model-dir models

Tabs
----
1. Fleet operations: KPIs, a fleet map (green/amber/red from model predictions), and a
   prioritized action queue with capacity-aware diversion recommendations.
2. Container detail: temperature/humidity/shock history, predicted shelf life with
   forward projections and buyer acceptance specs, ranked secondary buyers with
   projected salvage values, a map of options, and approve/keep-on-plan actions that
   write to an audit log.
3. Model health: Phase 2 ablation and feature importance, and Phase 3 policy evaluation.

A simulation clock advances the replayed fleet. "Show simulator ground truth" overlays
true shelf life and injected faults for validation. Operators never see them by default.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Final, Literal

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from data_engine import COMMODITIES
from fleet_service import ARRIVED, RETAIL_SPEC_FRACTION, TERMINAL_SPEC_FRACTION, FleetService

STATUS_COLORS: Final[dict[str, str]] = {"green": "#2e9e5b", "amber": "#f0a202", "red": "#d64545", ARRIVED: "#9aa0a6"}
STATUS_LABELS: Final[dict[str, str]] = {"green": "🟢 Safe", "amber": "🟠 At risk", "red": "🔴 Critical", ARRIVED: "⚪ Arrived"}
MAP_STYLE: Final[str] = "carto-positron"


def parse_cli() -> argparse.Namespace:
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--data-dir", type=Path, default=Path("data"))
    p.add_argument("--model-dir", type=Path, default=Path("models"))
    args, _ = p.parse_known_args(sys.argv[1:])
    return args


@st.cache_resource(show_spinner="Loading fleet data and models…")
def get_service(data_dir: str, model_dir: str) -> FleetService:
    return FleetService(Path(data_dir), Path(model_dir))


@st.cache_data(show_spinner=False, max_entries=64)
def cached_fleet_state(_svc: FleetService, key: str, offset_h: float) -> pd.DataFrame:
    return _svc.fleet_state(offset_h)


@st.cache_data(show_spinner=False, max_entries=64)
def cached_assignments(_svc: FleetService, key: str, offset_h: float) -> pd.DataFrame:
    return _svc.assignments(_svc.fleet_state(offset_h))


def usd(v: float) -> str:
    return f"-${abs(v):,.0f}" if v < 0 else f"${v:,.0f}"


# ======================================================================================
# Fleet operations tab
# ======================================================================================
def fleet_map(fleet: pd.DataFrame, buyers: pd.DataFrame, show_buyers: bool, status_key: str) -> go.Figure:
    df = fleet.assign(status_label=fleet[status_key].map(STATUS_LABELS),
                      size=np.sqrt(fleet["cargo_value_usd"].clip(lower=1.0)))
    fig = px.scatter_map(
        df, lat="lat", lon="lon", color=status_key, color_discrete_map=STATUS_COLORS, size="size", size_max=16,
        hover_name="container_id",
        hover_data={"display_name": True, "status_label": True, "predicted_rsl_days": ":.1f",
                    "projected_arrival_rsl_days": ":.1f", "destination": True, "activity": True,
                    "lat": False, "lon": False, "size": False, status_key: False},
        category_orders={status_key: ["red", "amber", "green", ARRIVED]}, zoom=2.6,
        center={"lat": 39.5, "lon": -96.0}, height=560, map_style=MAP_STYLE,
    )
    if show_buyers:
        fig.add_trace(go.Scattermap(
            lat=buyers["lat"], lon=buyers["lon"], mode="markers", name="Buyers",
            marker={"size": 8, "color": "#3b5bdb", "opacity": 0.6},
            text=buyers["name"] + " (" + buyers["buyer_type"] + ")", hoverinfo="text"))
    fig.update_layout(margin={"l": 0, "r": 0, "t": 0, "b": 0}, legend={"title": "", "orientation": "h", "y": 1.02})
    return fig


def render_fleet_tab(svc: FleetService, fleet: pd.DataFrame, plan: pd.DataFrame, show_truth: bool,
                     show_buyers: bool) -> None:
    status_key = "true_status" if show_truth else "status"
    active = fleet[fleet["status"] != ARRIVED]
    at_risk = active[active["status"].isin(["amber", "red"])]
    gains = plan.loc[plan["action"] == "divert", "gain_usd"].sum() if not plan.empty else 0.0

    c = st.columns(6)
    c[0].metric("Active containers", f"{len(active):,}", help=f"{(fleet['status'] == ARRIVED).sum()} arrived")
    c[1].metric("🟢 Safe", int((active["status"] == "green").sum()))
    c[2].metric("🟠 At risk", int((active["status"] == "amber").sum()))
    c[3].metric("🔴 Critical", int((active["status"] == "red").sum()))
    c[4].metric("Cargo value at risk", usd(float(at_risk["cargo_value_usd"].sum())))
    c[5].metric("Recoverable by diversion", usd(float(gains)), help="Net gain of recommended diversions vs staying on plan")

    st.plotly_chart(fleet_map(fleet if show_truth else active, svc.buyers(), show_buyers, status_key),
                    width="stretch", config={"scrollZoom": True})

    st.subheader("Action queue")
    if at_risk.empty:
        st.success("No containers at risk at this clock position.")
    else:
        queue = at_risk.merge(plan, on="container_id", how="left")
        queue = queue.assign(
            status_label=queue["status"].map(STATUS_LABELS),
            alert_text=queue["alerts"].map(lambda a: " • ".join(a) if a else "—"),
            recommendation=np.where(queue["action"] == "divert", "Divert → " + queue["buyer_name"].fillna(""),
                                    "Keep on plan → " + queue["destination"]),
        )
        cols = ["container_id", "status_label", "display_name", "predicted_rsl_days", "projected_arrival_rsl_days",
                "hours_to_retail_spec", "alert_text", "recommendation", "net_salvage_value_usd", "gain_usd"]
        if show_truth:
            cols += ["true_rsl_days", "faults"]
        event = st.dataframe(
            queue[cols], hide_index=True, width="stretch", on_select="rerun", selection_mode="single-row",
            key="queue_table",
            column_config={
                "container_id": "Container", "status_label": "Status", "display_name": "Cargo",
                "predicted_rsl_days": st.column_config.NumberColumn("Pred. RSL (d)", format="%.1f"),
                "projected_arrival_rsl_days": st.column_config.NumberColumn("RSL at arrival (d)", format="%.1f",
                                                                            help="Worse of setpoint-hold and current-conditions projections"),
                "hours_to_retail_spec": st.column_config.NumberColumn("Hours to retail spec", format="%.0f"),
                "alert_text": st.column_config.TextColumn("Alerts", width="large"),
                "recommendation": st.column_config.TextColumn("Recommendation", width="medium"),
                "net_salvage_value_usd": st.column_config.NumberColumn("Net value", format="dollar"),
                "gain_usd": st.column_config.NumberColumn("Gain vs plan", format="dollar"),
                "true_rsl_days": st.column_config.NumberColumn("True RSL (d)", format="%.1f"),
                "faults": "Injected faults",
            })
        rows = event.selection.rows if event is not None else []
        if rows:
            st.session_state["selected_container"] = str(queue.iloc[rows[0]]["container_id"])
            st.info(f"Selected **{st.session_state['selected_container']}**, open the *Container detail* tab.")

    with st.expander(f"All containers ({len(fleet)})"):
        st.dataframe(fleet[["container_id", "status", "display_name", "origin", "destination", "activity",
                            "predicted_rsl_days", "projected_arrival_rsl_days", "pulp_temp_c", "setpoint_c",
                            "remaining_transit_h", "alert_count"]],
                     hide_index=True, width="stretch")


# ======================================================================================
# Container detail tab
# ======================================================================================
def temperature_figure(hist: pd.DataFrame, row: pd.Series) -> go.Figure:
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True, row_heights=[0.6, 0.2, 0.2], vertical_spacing=0.04,
                        subplot_titles=("Temperature (°C)", "Relative humidity (%)", "Shock (g) & events"))
    x = hist["timestamp"]
    for col, name, color, dash in (("return_air_temp_c", "Return air", "#1c7ed6", "solid"),
                                   ("supply_air_temp_c", "Supply air", "#74c0fc", "solid"),
                                   ("pulp_temp_c", "Pulp probe", "#e8590c", "solid"),
                                   ("ambient_temp_c", "Ambient", "#adb5bd", "dot")):
        fig.add_trace(go.Scatter(x=x, y=hist[col], name=name, line={"color": color, "dash": dash, "width": 1.6}), 1, 1)
    comm = COMMODITIES[str(row["commodity"])]
    fig.add_trace(go.Scatter(x=x, y=hist["setpoint_c"], name="Configured setpoint",
                             line={"color": "#212529", "dash": "dash", "width": 1}), 1, 1)
    fig.add_hline(y=comm.setpoint_c, line={"color": "#2e9e5b", "dash": "dot", "width": 1}, row=1, col=1,
                  annotation_text=f"Spec {comm.setpoint_c:g} °C", annotation_position="bottom right")
    fig.add_hline(y=comm.highest_freezing_point_c, line={"color": "#4dabf7", "dash": "dot", "width": 1}, row=1, col=1,
                  annotation_text="Freezing point", annotation_position="bottom left")
    if comm.chilling_threshold_c is not None:
        fig.add_hline(y=comm.chilling_threshold_c, line={"color": "#9775fa", "dash": "dot", "width": 1}, row=1, col=1,
                      annotation_text="Chilling threshold", annotation_position="top left")
    fig.add_trace(go.Scatter(x=x, y=hist["relative_humidity_pct"], name="RH", line={"color": "#15aabf", "width": 1.4},
                             showlegend=False), 2, 1)
    fig.add_hline(y=comm.optimal_rh_pct, line={"color": "#2e9e5b", "dash": "dot", "width": 1}, row=2, col=1)
    fig.add_trace(go.Bar(x=x, y=hist["vibration_peak_g"], name="Peak g", marker_color="#868e96", showlegend=False), 3, 1)
    for mask, label, color in ((hist["door_open"] == 1, "Door open", "#f76707"),
                               (hist["power_on"] == 0, "Power off", "#e03131")):
        if mask.any():
            fig.add_trace(go.Scatter(x=x[mask], y=np.full(int(mask.sum()), max(3.0, hist["vibration_peak_g"].max())),
                                     mode="markers", name=label, marker={"color": color, "symbol": "triangle-down", "size": 9}),
                          3, 1)
    fig.update_layout(height=620, margin={"l": 10, "r": 10, "t": 40, "b": 10}, legend={"orientation": "h", "y": -0.08},
                      hovermode="x unified")
    return fig


def rsl_figure(svc: FleetService, hist: pd.DataFrame, row: pd.Series, show_truth: bool) -> go.Figure:
    sl = COMMODITIES[str(row["commodity"])].shelf_life_days_at_setpoint
    proj = svc.rsl_projection(row)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=hist["timestamp"], y=hist["predicted_rsl_days"], name="Predicted RSL (XGBoost)",
                             line={"color": "#1c7ed6", "width": 2.2}))
    fig.add_trace(go.Scatter(x=hist["timestamp"], y=hist["physics_rsl_days"], name="Physics prior (Arrhenius)",
                             line={"color": "#74c0fc", "dash": "dot", "width": 1.2}))
    if show_truth:
        fig.add_trace(go.Scatter(x=hist["timestamp"], y=hist["remaining_shelf_life_days"], name="True RSL (simulator)",
                                 line={"color": "#212529", "dash": "dash", "width": 1.2}))
    fig.add_trace(go.Scatter(x=proj["timestamp"], y=proj["at_setpoint"], name="Projection: held at setpoint",
                             line={"color": "#2e9e5b", "dash": "dash"}))
    fig.add_trace(go.Scatter(x=proj["timestamp"], y=proj["current_conditions"],
                             name=f"Projection: stays at {row['pulp_temp_c']:.1f} °C", line={"color": "#d64545", "dash": "dash"}))
    fig.add_hline(y=RETAIL_SPEC_FRACTION * sl, line={"color": "#f0a202", "dash": "dot"},
                  annotation_text=f"Retail acceptance ({RETAIL_SPEC_FRACTION:.0%} of {sl:g} d)")
    fig.add_hline(y=TERMINAL_SPEC_FRACTION * sl, line={"color": "#d64545", "dash": "dot"},
                  annotation_text=f"Terminal-market acceptance ({TERMINAL_SPEC_FRACTION:.0%})")
    fig.add_vline(x=pd.Timestamp(row["timestamp"]), line={"color": "#495057", "width": 1})
    fig.update_layout(height=380, yaxis_title="Remaining shelf life (days at setpoint)", hovermode="x unified",
                      margin={"l": 10, "r": 10, "t": 30, "b": 10}, legend={"orientation": "h", "y": -0.2})
    fig.update_yaxes(rangemode="tozero")
    return fig


def options_map(svc: FleetService, row: pd.Series, recs: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    for r, net in zip(recs.itertuples(), recs["net_salvage_value_usd"].to_numpy(dtype=np.float64)):
        color = "#2e9e5b" if r.recommended else ("#1c7ed6" if r.feasible else "#adb5bd")
        fig.add_trace(go.Scattermap(lat=[row["lat"], r.lat], lon=[row["lon"], r.lon], mode="lines",
                                    line={"width": 3 if r.recommended else 1.5, "color": color}, hoverinfo="skip",
                                    showlegend=False))
        fig.add_trace(go.Scattermap(lat=[r.lat], lon=[r.lon], mode="markers+text", text=[f"#{r.rank}"],
                                    textposition="top right", marker={"size": 12, "color": color}, showlegend=False,
                                    hovertext=f"{r.buyer_name}<br>Net {usd(net)}",
                                    hoverinfo="text"))
    fig.add_trace(go.Scattermap(lat=[row["lat"]], lon=[row["lon"]], mode="markers", name=str(row["container_id"]),
                                marker={"size": 16, "color": STATUS_COLORS.get(str(row["status"]), "#000")},
                                hovertext=str(row["container_id"]), hoverinfo="text", showlegend=False))
    lats = [row["lat"], *recs["lat"]]
    lons = [row["lon"], *recs["lon"]]
    fig.update_layout(map={"style": MAP_STYLE, "center": {"lat": float(np.mean(lats)), "lon": float(np.mean(lons))},
                           "zoom": 3.0}, height=420, margin={"l": 0, "r": 0, "t": 0, "b": 0})
    return fig


def render_detail_tab(svc: FleetService, fleet: pd.DataFrame, offset_h: float, show_truth: bool) -> None:
    ids = fleet["container_id"].tolist()
    default = st.session_state.get("selected_container", ids[0])
    idx = ids.index(default) if default in ids else 0
    label = {str(r.container_id): f"{r.container_id} · {STATUS_LABELS[str(r.status)]} · {r.display_name} · "
                                  f"{r.origin}→{r.destination}" for r in fleet.itertuples()}
    cid = st.selectbox("Container", ids, index=idx, format_func=lambda c: label[c])
    st.session_state["selected_container"] = cid
    row = fleet.set_index("container_id").loc[cid].copy()
    row["container_id"] = cid
    hist = svc.container_history(cid, offset_h)

    st.markdown(f"### {cid} · {row['display_name']} · {STATUS_LABELS[row['status']]}")
    st.caption(f"{row['origin']} → {row['destination']} · currently: {row['activity']} "
               f"({row['from_hub']} → {row['to_hub']}) · clock {pd.Timestamp(row['timestamp']):%Y-%m-%d %H:%M} UTC")
    c = st.columns(5)
    c[0].metric("Predicted RSL", f"{row['predicted_rsl_days']:.1f} d",
                delta=f"{row['rsl_fraction']:.0%} of {row['ref_shelf_life_days']:g} d", delta_color="off")
    arrival = float(row["projected_arrival_rsl_days"])
    c[1].metric("RSL at arrival (worst case)", f"{arrival:.1f} d" if arrival > 0 else "Spoils before arrival",
                help="Worse of: held at setpoint, or current pulp temperature persisting until ETA")
    c[2].metric("Pulp vs spec", f"{row['pulp_temp_c']:.1f} °C",
                delta=f"{row['pulp_temp_c'] - COMMODITIES[str(row['commodity'])].setpoint_c:+.1f} °C", delta_color="inverse")
    c[3].metric("ETA", f"{row['remaining_transit_h']:.0f} h")
    c[4].metric("Cargo value", usd(float(row["cargo_value_usd"])))
    if show_truth:
        st.caption(f"🧪 Simulator truth: RSL {row['true_rsl_days']:.2f} d · status {row['true_status']} · "
                   f"injected faults: {row['faults']}")
    for a in row["alerts"]:
        (st.error if row["status"] == "red" else st.warning)(a)

    left, right = st.columns([3, 2])
    with left:
        st.plotly_chart(temperature_figure(hist, row), width="stretch")
    with right:
        st.plotly_chart(rsl_figure(svc, hist, row, show_truth), width="stretch")
        st.caption("RSL is expressed in days of sellable life if held at the optimal setpoint. The red projection "
                   "assumes the current pulp temperature persists, which is the conservative view if the reefer has failed.")

    st.subheader("Secondary buyers & projected salvage")
    if row["status"] == ARRIVED:
        st.info("Container has arrived; no diversion options.")
        return
    recs = svc.recommendations(pd.DataFrame([row]).reset_index(drop=True), top_k=5)[0]
    plan_row = recs[recs["is_planned_destination"]]
    plan_value = float(plan_row["net_salvage_value_usd"].iloc[0]) if not plan_row.empty else float("nan")
    best = recs[recs["recommended"]].iloc[0] if recs["recommended"].any() else recs.iloc[0]
    if not bool(recs["feasible"].any()):
        st.error("**No buyer can accept this load within spec.** Hold for USDA/quality inspection, document the "
                 "temperature record for a carrier/reefer claim, and route to the lowest-cost disposal or "
                 f"compost outlet. Least-cost option below: {best['buyer_name']} ({usd(best['net_salvage_value_usd'])}).")
    elif bool(best["is_planned_destination"]):
        st.success(f"Recommendation: **keep on plan** to {best['buyer_name']} (net {usd(best['net_salvage_value_usd'])}).")
    else:
        st.warning(f"Recommendation: **divert** to {best['buyer_name']}, net {usd(best['net_salvage_value_usd'])} "
                   f"vs {usd(plan_value)} on plan (gain {usd(best['net_salvage_value_usd'] - plan_value)}).")
    table = recs.assign(option=np.where(recs["is_planned_destination"], "📍 " + recs["buyer_name"] + " (planned)",
                                        recs["buyer_name"]))
    st.dataframe(
        table[["rank", "option", "buyer_type", "distance_km", "travel_h", "projected_rsl_at_arrival_days", "feasible",
               "sellable_kg", "projected_revenue_usd", "incremental_freight_usd", "contract_breach_usd",
               "disposal_cost_usd", "net_salvage_value_usd", "recommended"]],
        hide_index=True, width="stretch",
        column_config={
            "rank": "#", "option": st.column_config.TextColumn("Buyer", width="large"), "buyer_type": "Channel",
            "distance_km": st.column_config.NumberColumn("Distance (km)", format="%.0f"),
            "travel_h": st.column_config.NumberColumn("Travel (h)", format="%.1f"),
            "projected_rsl_at_arrival_days": st.column_config.NumberColumn("RSL at arrival (d)", format="%.1f"),
            "feasible": st.column_config.CheckboxColumn("Meets spec"),
            "sellable_kg": st.column_config.NumberColumn("Sellable (kg)", format="localized"),
            "projected_revenue_usd": st.column_config.NumberColumn("Revenue", format="dollar"),
            "incremental_freight_usd": st.column_config.NumberColumn("Extra freight", format="dollar"),
            "contract_breach_usd": st.column_config.NumberColumn("PO breach", format="dollar"),
            "disposal_cost_usd": st.column_config.NumberColumn("Disposal", format="dollar"),
            "net_salvage_value_usd": st.column_config.NumberColumn("Net salvage value", format="dollar"),
            "recommended": st.column_config.CheckboxColumn("Recommended"),
        })
    m, form = st.columns([3, 2])
    with m:
        st.plotly_chart(options_map(svc, row, recs), width="stretch")
    with form:
        st.markdown("**Operator decision**")
        with st.form(f"decision_{cid}", clear_on_submit=True):
            choice = st.selectbox("Destination", recs["buyer_code"].tolist(),
                                  index=int(np.flatnonzero(recs["buyer_code"] == best["buyer_code"])[0]),
                                  format_func=lambda b: recs.set_index("buyer_code").loc[b, "buyer_name"])
            operator = st.text_input("Operator", value=st.session_state.get("operator", ""))
            note = st.text_input("Note", placeholder="e.g. confirmed receiving slot with buyer")
            submitted = st.form_submit_button("Record decision", type="primary")
        if submitted:
            st.session_state["operator"] = operator
            chosen = recs.set_index("buyer_code").loc[choice]
            action: Literal["divert", "continue"] = "continue" if bool(chosen["is_planned_destination"]) else "divert"
            svc.log_action(row, action, choice, float(chosen["net_salvage_value_usd"]), plan_value, operator, note)
            st.success(f"Logged: {action} → {chosen['buyer_name']}. Carrier/buyer notification happens outside this tool.")
    log = svc.action_log()
    if not log.empty:
        with st.expander(f"Decision log ({len(log)})"):
            st.dataframe(log.iloc[::-1], hide_index=True, width="stretch")


# ======================================================================================
# Model health tab
# ======================================================================================
def render_model_tab(svc: FleetService, fleet: pd.DataFrame) -> None:
    reports = svc.model_reports()
    st.markdown(f"**Shelf-life model variant in use:** `{svc.model_variant}` (pulp probe if available, else virtual pulp).")
    active = fleet[fleet["status"] != ARRIVED]
    if not active.empty:
        err = active["predicted_rsl_days"] - active["true_rsl_days"]
        agree = (active["status"] == active["true_status"]).mean()
        c = st.columns(3)
        c[0].metric("Live RMSE vs simulator (days)", f"{np.sqrt(np.mean(err ** 2)):.2f}")
        c[1].metric("Live bias (days)", f"{err.mean():+.2f}")
        c[2].metric("Status agreement with truth", f"{agree:.0%}")
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Phase 2: shelf-life ablation")
        if "ablation" in reports:
            st.dataframe(reports["ablation"][["feature_set", "description", "rmse", "mae", "r2", "meets_target"]],
                         hide_index=True, width="stretch",
                         column_config={"rmse": st.column_config.NumberColumn("RMSE (d)", format="%.3f"),
                                        "mae": st.column_config.NumberColumn("MAE (d)", format="%.3f"),
                                        "r2": st.column_config.NumberColumn("R²", format="%.4f")})
        st.caption("The error floor is set by load-out QC precision on initial shelf life, not by the model. "
                   "Roughly: QC error 1% → 0.17 d, 2% → 0.29 d, 5% → 0.7 d RMSE.")
    with col2:
        st.subheader("Feature importance (permutation)")
        if "feature_importance" in reports:
            fi = reports["feature_importance"].head(15).iloc[::-1]
            fig = px.bar(fi, x="permutation_rmse_increase_days", y="feature", orientation="h", log_x=True,
                         labels={"permutation_rmse_increase_days": "RMSE increase when shuffled (d, log)", "feature": ""})
            fig.update_layout(height=420, margin={"l": 10, "r": 10, "t": 10, "b": 10})
            st.plotly_chart(fig, width="stretch")
    st.subheader("Phase 3: diversion policy evaluation (held-out containers)")
    if "recommender_eval" in reports:
        ev = reports["recommender_eval"]
        st.dataframe(ev, hide_index=True, width="stretch",
                     column_config={c: st.column_config.NumberColumn(format="%.1f")
                                    for c in ev.columns if ev[c].dtype.kind == "f"})
        st.caption("Value capture = realized gain over staying on plan / oracle's gain over plan. The oracle knows true shelf life; "
                   "all policies act on predicted shelf life.")


# ======================================================================================
# Main
# ======================================================================================
def main() -> None:
    st.set_page_config(page_title="Cold-Chain Operations", page_icon="🧊", layout="wide")
    args = parse_cli()
    with st.sidebar:
        st.title("🧊 Cold-Chain Ops")
        data_dir = st.text_input("Data directory", value=str(args.data_dir))
        model_dir = st.text_input("Model directory", value=str(args.model_dir))
        try:
            svc = get_service(data_dir, model_dir)
        except FileNotFoundError as exc:
            st.error(f"Missing artifact: {exc}. Run data_engine.py, spoilage_model.py and recommender.py first.")
            st.stop()
        st.subheader("Simulation clock")
        max_off = int(np.ceil(svc.max_offset_h()))
        if "offset_h" not in st.session_state:
            st.session_state["offset_h"] = 0
        b1, b2 = st.columns(2)
        if b1.button("⏪ Reset", width="stretch"):
            st.session_state["offset_h"] = 0
        if b2.button("⏩ +1 h", width="stretch"):
            st.session_state["offset_h"] = min(max_off, int(st.session_state["offset_h"]) + 1)
        offset_h = st.slider("Hours from snapshot", 0, max_off, key="offset_h")
        st.subheader("Filters")
        commodities = st.multiselect("Cargo", list(COMMODITIES), format_func=lambda k: COMMODITIES[k].display_name)
        show_arrived = st.toggle("Include arrived containers", value=False)
        show_buyers = st.toggle("Show buyers on map", value=True)
        show_truth = st.toggle("Show simulator ground truth", value=False,
                               help="Validation only: overlays true shelf life, true status and injected faults.")

    key = f"{data_dir}|{model_dir}"
    fleet = cached_fleet_state(svc, key, float(offset_h))
    plan = cached_assignments(svc, key, float(offset_h))
    view = fleet if show_arrived else fleet[fleet["status"] != ARRIVED]
    if commodities:
        view = view[view["commodity"].isin(commodities)]
    if view.empty:
        st.warning("No containers match the current filters and clock position.")
        st.stop()

    t1, t2, t3 = st.tabs(["🗺️ Fleet operations", "📦 Container detail", "🩺 Model health"])
    with t1:
        render_fleet_tab(svc, view, plan, show_truth, show_buyers)
    with t2:
        render_detail_tab(svc, view, float(offset_h), show_truth)
    with t3:
        render_model_tab(svc, fleet)


if __name__ == "__main__":
    main()
