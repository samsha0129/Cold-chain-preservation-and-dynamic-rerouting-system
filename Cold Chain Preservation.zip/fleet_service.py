"""
fleet_service.py — Phase 4 core: operational logic shared by the dashboard (app.py) and API (api.py).

Responsibilities
----------------
* Load Phase 1 data, the Phase 2 shelf-life models and the Phase 3 recommender once.
* Replay the fleet on a simulation clock. Each container starts at its Phase 1
  snapshot position, and `offset_h` advances every container together.
* Derive status from *model predictions*, as operations would see it, never from
  simulator ground truth. Ground truth is exposed separately, only for validation.
* Raise operational alerts: temperature excursion, setpoint misconfiguration, power
  loss, door opening in transit, impacts, compressor saturation, chill/freeze risk.
* Produce diversion recommendations with salvage economics, run capacity-aware fleet
  assignment, and keep an auditable operator action log.

Phase 2 features are strictly causal (past-only), so predicting once on full
histories and slicing at the clock is identical to re-predicting on truncated
histories, and is much faster.
"""
from __future__ import annotations

import csv
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Final, Literal

import numpy as np
import pandas as pd

from data_engine import BUYER_ECONOMICS, COMMODITIES, BuyerType, Status, classify_status, load_table
from recommender import DiversionRecommender, query_batch_from_states
from spoilage_model import SpoilagePredictor, hours_until_threshold, project_remaining_shelf_life

LOGGER: Final[logging.Logger] = logging.getLogger("coldchain.fleet_service")

ARRIVED: Final[str] = "arrived"
STATUS_ORDER: Final[dict[str, int]] = {Status.RED.value: 0, Status.AMBER.value: 1, Status.GREEN.value: 2, ARRIVED: 3}
RETAIL_SPEC_FRACTION: Final[float] = BUYER_ECONOMICS[BuyerType.RETAIL_DC].min_rsl_fraction
TERMINAL_SPEC_FRACTION: Final[float] = BUYER_ECONOMICS[BuyerType.TERMINAL_MARKET].min_rsl_fraction
ACTION_LOG_FIELDS: Final[tuple[str, ...]] = (
    "logged_at_utc", "sim_time_utc", "container_id", "commodity", "action", "buyer_code",
    "net_salvage_value_usd", "plan_net_value_usd", "predicted_rsl_days", "operator", "note",
)


@dataclass(frozen=True, slots=True)
class AlertThresholds:
    excursion_c: float = 2.0  # mean return air above setpoint over the last 2 h
    setpoint_mismatch_c: float = 0.9
    impact_g: float = 2.5
    saturated_duty: float = 0.9
    window_h: float = 6.0
    short_window_h: float = 2.0


class FleetService:
    """Loaded system (data + models) with query methods for the operations UI and API."""

    def __init__(self, data_dir: Path, model_dir: Path, thresholds: AlertThresholds = AlertThresholds()) -> None:
        self.data_dir = Path(data_dir)
        self.model_dir = Path(model_dir)
        self.thresholds = thresholds
        self.shipments = load_table(self.data_dir, "shipments")
        self.shipments["container_id"] = self.shipments["container_id"].astype(str)
        self.hubs = load_table(self.data_dir, "hubs")
        self.depot_market = load_table(self.data_dir, "depot_market")
        snapshot = load_table(self.data_dir, "fleet_snapshot")
        self.snapshot_elapsed = snapshot.set_index(snapshot["container_id"].astype(str))["snapshot_elapsed_h"]
        self.predictor = SpoilagePredictor.load(self.model_dir)
        self.recommender = DiversionRecommender.load(self.model_dir, self.depot_market, self.hubs)

        tel = load_table(self.data_dir, "telemetry")
        tel["container_id"] = tel["container_id"].astype(str)
        tel["commodity"] = tel["commodity"].astype(str)
        tel = tel.sort_values(["container_id", "elapsed_h"], kind="mergesort").reset_index(drop=True)
        pred = self.predictor.predict(tel, self.shipments).sort_values(
            ["container_id", "elapsed_h"], kind="mergesort").reset_index(drop=True)
        if not np.allclose(pred["elapsed_h"].to_numpy(), tel["elapsed_h"].to_numpy()):
            raise RuntimeError("Shelf-life predictions are misaligned with telemetry")
        tel["predicted_rsl_days"] = pred["predicted_rsl_days"].to_numpy()
        tel["physics_rsl_days"] = pred["physics_rsl_days"].to_numpy()
        tel["ref_setpoint_c"] = tel["commodity"].map({k: p.setpoint_c for k, p in COMMODITIES.items()})
        self.telemetry = tel
        self.total_elapsed = tel.groupby("container_id", sort=False)["elapsed_h"].max()
        self.model_variant = str(pred["variant"].iloc[0])
        self._action_log_path = self.data_dir / "operator_actions.csv"
        LOGGER.info("Fleet service ready: %d containers, %s telemetry rows, model variant '%s'",
                    len(self.total_elapsed), f"{len(tel):,}", self.model_variant)

    # ------------------------------------------------------------------ clock
    def clock(self, offset_h: float) -> pd.Series:
        """Current elapsed hours per container at the given fleet clock offset."""
        start = self.snapshot_elapsed.reindex(self.total_elapsed.index).fillna(0.0)
        return (start + offset_h).combine(self.total_elapsed, min).clip(lower=0.0)

    def max_offset_h(self) -> float:
        start = self.snapshot_elapsed.reindex(self.total_elapsed.index).fillna(0.0)
        return float((self.total_elapsed - start).max())

    def _masks(self, offset_h: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        now = self.telemetry["container_id"].map(self.clock(offset_h)).to_numpy(np.float64)
        e = self.telemetry["elapsed_h"].to_numpy(np.float64)
        hist = e <= now + 1e-9
        return hist, hist & (e > now - self.thresholds.window_h), hist & (e > now - self.thresholds.short_window_h)

    # ------------------------------------------------------------------ fleet state
    def fleet_state(self, offset_h: float = 0.0) -> pd.DataFrame:
        """One row per container: position, sensors, predicted shelf life, model-based status, alerts."""
        th = self.thresholds
        hist_m, win_m, short_m = self._masks(offset_h)
        t = self.telemetry
        last = t[hist_m].groupby("container_id", sort=False).tail(1).set_index("container_id")
        win = t[win_m].groupby("container_id", sort=False).agg(
            power_loss_6h=("power_on", lambda s: bool((s == 0).any())),
            door_open_6h=("door_open", lambda s: bool((s == 1).any())),
            max_g_6h=("vibration_peak_g", "max"))
        short = t[short_m].assign(air_dev=t["return_air_temp_c"] - t["ref_setpoint_c"]).groupby(
            "container_id", sort=False).agg(air_dev_2h=("air_dev", "mean"), duty_2h=("compressor_duty_cycle", "mean"))
        state = last.join(win).join(short)
        ship = self.shipments.set_index("container_id")
        state = state.join(ship[["origin", "destination", "payload_kg", "cargo_value_usd", "arrival", "faults"]])

        sl = state["commodity"].map({k: p.shelf_life_days_at_setpoint for k, p in COMMODITIES.items()})
        pred = state["predicted_rsl_days"].to_numpy(np.float64)
        rem = state["remaining_transit_h"].to_numpy(np.float64)
        proj_cur = np.empty(len(state))
        to_retail = np.empty(len(state))
        for comm_key, idx in state.groupby("commodity").indices.items():
            comm = str(comm_key)
            proj_cur[idx] = project_remaining_shelf_life(pred[idx], comm, state["pulp_temp_c"].to_numpy()[idx], rem[idx])
            spec = RETAIL_SPEC_FRACTION * COMMODITIES[comm].shelf_life_days_at_setpoint
            to_retail[idx] = [hours_until_threshold(float(r), comm, float(p), spec)
                              for r, p in zip(pred[idx], state["pulp_temp_c"].to_numpy()[idx])]
        proj_sp = pred - rem / 24.0
        worst = np.minimum(proj_sp, proj_cur)
        status = [ARRIVED if r <= 1e-6 else classify_status(float(w), float(s), float(p) / float(s)).value
                  for w, s, p, r in zip(worst, sl, pred, rem)]
        true_status = state["status"].astype(str).to_numpy()
        state = state.assign(
            display_name=state["commodity"].map({k: p.display_name for k, p in COMMODITIES.items()}),
            ref_shelf_life_days=sl, rsl_fraction=pred / sl.to_numpy(),
            projected_arrival_rsl_setpoint_days=proj_sp, projected_arrival_rsl_current_days=proj_cur,
            projected_arrival_rsl_days=worst, hours_to_retail_spec=np.minimum(to_retail, 9_999.0), status=status,
            true_status=np.where(rem <= 1e-6, ARRIVED, true_status),
            true_rsl_days=state["remaining_shelf_life_days"],
        )
        state["alerts"] = [self._alerts(r) for r in state.itertuples()]
        state["alert_count"] = state["alerts"].map(len)
        state["status_rank"] = state["status"].map(STATUS_ORDER)
        state = state.reset_index().sort_values(["status_rank", "projected_arrival_rsl_days"]).reset_index(drop=True)
        return state

    def _alerts(self, r: Any) -> list[str]:
        th = self.thresholds
        out: list[str] = []
        if r.remaining_transit_h <= 1e-6:
            return out
        comm = COMMODITIES[r.commodity]
        if abs(r.setpoint_c - comm.setpoint_c) > th.setpoint_mismatch_c:
            out.append(f"Setpoint misconfigured: {r.setpoint_c:.1f} C vs {comm.setpoint_c:.1f} C spec")
        if pd.notna(r.air_dev_2h) and r.air_dev_2h > th.excursion_c:
            out.append(f"Temperature excursion: return air +{r.air_dev_2h:.1f} C over setpoint (2 h mean)")
        if comm.chilling_threshold_c is not None and r.pulp_temp_c < comm.chilling_threshold_c:
            out.append(f"Chilling-injury risk: pulp {r.pulp_temp_c:.1f} C < {comm.chilling_threshold_c:.1f} C")
        if r.pulp_temp_c < comm.highest_freezing_point_c:
            out.append(f"Freeze risk: pulp {r.pulp_temp_c:.1f} C < freezing point {comm.highest_freezing_point_c:.1f} C")
        if bool(r.power_loss_6h):
            out.append("Reefer power loss in last 6 h")
        if pd.notna(r.duty_2h) and r.duty_2h > th.saturated_duty and pd.notna(r.air_dev_2h) and r.air_dev_2h > 0.5:
            out.append("Compressor saturated while temperature above setpoint (capacity loss?)")
        if bool(r.door_open_6h) and r.activity != "dwell":
            out.append("Door opened while in transit")
        if pd.notna(r.max_g_6h) and r.max_g_6h > th.impact_g:
            out.append(f"Impact {r.max_g_6h:.1f} g (bruise threshold {th.impact_g:.1f} g)")
        return out

    # ------------------------------------------------------------------ container detail
    def container_history(self, container_id: str, offset_h: float = 0.0) -> pd.DataFrame:
        now = float(self.clock(offset_h).loc[container_id])
        t = self.telemetry
        return t[(t["container_id"] == container_id) & (t["elapsed_h"] <= now + 1e-9)].reset_index(drop=True)

    def rsl_projection(self, row: pd.Series, step_h: float = 1.0) -> pd.DataFrame:
        """Forward RSL curves from now to ETA: held at setpoint vs. current conditions persisting."""
        rem = float(row["remaining_transit_h"])
        hours = np.arange(0.0, max(rem, 0.0) + step_h, step_h)
        hours[-1] = max(rem, 0.0)
        pred = float(row["predicted_rsl_days"])
        ts = pd.Timestamp(row["timestamp"]) + pd.to_timedelta(hours, unit="h")
        return pd.DataFrame({
            "timestamp": ts, "hours_ahead": hours,
            "at_setpoint": np.maximum(pred - hours / 24.0, 0.0),
            "current_conditions": project_remaining_shelf_life(np.full_like(hours, pred), str(row["commodity"]),
                                                               np.full_like(hours, float(row["pulp_temp_c"])), hours),
        })

    def recommendations(self, states: pd.DataFrame, top_k: int = 5) -> list[pd.DataFrame]:
        q = query_batch_from_states(states, self.shipments, self.recommender.cube)
        return self.recommender.recommend(q, top_k=top_k)

    def assignments(self, fleet: pd.DataFrame) -> pd.DataFrame:
        """Capacity-aware joint assignment for active amber/red containers."""
        at_risk = fleet[fleet["status"].isin([Status.AMBER.value, Status.RED.value])]
        if at_risk.empty:
            return pd.DataFrame(columns=["container_id", "action", "buyer_code", "net_salvage_value_usd",
                                         "plan_net_value_usd", "projected_rsl_at_arrival_days", "gain_usd"])
        q = query_batch_from_states(at_risk, self.shipments, self.recommender.cube)
        plan = self.recommender.assign_fleet(q, at_risk["container_id"].tolist())
        plan["gain_usd"] = np.where(plan["action"] == "divert",
                                    plan["net_salvage_value_usd"] - plan["plan_net_value_usd"], 0.0)
        names = dict(zip(self.recommender.cube.buyer_codes, self.recommender.cube.buyer_names))
        plan["buyer_name"] = plan["buyer_code"].map(names).fillna("")
        return plan

    def buyers(self) -> pd.DataFrame:
        return self.hubs[self.hubs["node_type"] == "buyer"].reset_index(drop=True)

    def hub_coordinates(self, code: str) -> tuple[float, float] | None:
        row = self.hubs[self.hubs["hub_code"] == code]
        return None if row.empty else (float(row["lat"].iloc[0]), float(row["lon"].iloc[0]))

    # ------------------------------------------------------------------ action log
    def log_action(self, row: pd.Series, action: Literal["divert", "continue"], buyer_code: str,
                   net_value: float, plan_value: float, operator: str, note: str) -> dict[str, Any]:
        record = {
            "logged_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "sim_time_utc": pd.Timestamp(row["timestamp"]).isoformat(),
            "container_id": str(row["container_id"]), "commodity": str(row["commodity"]),
            "action": action, "buyer_code": buyer_code, "net_salvage_value_usd": round(float(net_value), 2),
            "plan_net_value_usd": round(float(plan_value), 2),
            "predicted_rsl_days": round(float(row["predicted_rsl_days"]), 3),
            "operator": operator.strip() or "unknown", "note": note.strip(),
        }
        new_file = not self._action_log_path.exists()
        with self._action_log_path.open("a", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=ACTION_LOG_FIELDS)
            if new_file:
                writer.writeheader()
            writer.writerow(record)
        return record

    def action_log(self) -> pd.DataFrame:
        if not self._action_log_path.exists():
            return pd.DataFrame(columns=list(ACTION_LOG_FIELDS))
        return pd.read_csv(self._action_log_path)

    # ------------------------------------------------------------------ model health
    def model_reports(self) -> dict[str, pd.DataFrame]:
        out: dict[str, pd.DataFrame] = {}
        for name in ("ablation", "feature_importance", "recommender_eval"):
            path = self.model_dir / f"{name}.csv"
            if path.exists():
                out[name] = pd.read_csv(path)
        return out
