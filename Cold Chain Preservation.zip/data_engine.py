#!/usr/bin/env python3
"""
data_engine.py — Phase 1 of the Cold-Chain Preservation & Dynamic Rerouting System.

Generates a physically grounded, fully reproducible dataset for intermodal reefer
monitoring. The data feeds Phase 2 (XGBoost shelf-life regressor), Phase 3
(two-tower diversion recommender) and Phase 4 (Streamlit operations dashboard).

What is real vs. simulated
--------------------------
REAL reference data (embedded as constants, sources cited inline):
  * Commodity storage conditions, shelf lives, freezing points and chilling
    thresholds: USDA Agriculture Handbook 66 (Gross, Wang & Saltveit, 2016 rev.),
    "The Commercial Storage of Fruits, Vegetables, and Florist and Nursery Stocks".
  * Temperature sensitivity (Q10) of produce respiration: Kader (ed.), Postharvest
    Technology of Horticultural Crops, UC ANR Pub. 3311. Fresh-fish spoilage rate
    uses the Ross/Dalgaard relative-rate-of-spoilage model, (1 + 0.1*T)^2, which
    implies Q10 ~ 4 over 0-10 C.
  * Hub network: coordinates of real North American seaports, US border produce
    crossings, growing regions, Class I intermodal ramps, wholesale terminal
    markets, and rail corridors actually operated (BNSF, UP, CN, CPKC, CSX, NS).
  * Demand: approximate US per-capita availability (USDA ERS Food Availability
    Data System; NOAA Fisheries for salmon) and approximate metro populations.
  * Standard reefer payload for bananas: 20 pallets x 54 boxes x 18.14 kg.

SIMULATED (with physics, calibrated to published ranges):
  * Reefer thermal behaviour: two-node (air/pulp) lumped-capacitance model with
    compressor capacity, fan heat, heaters, defrost cycles, door openings and
    power gaps at intermodal transfers or rail genset failures.
  * Ambient climate from a latitude/season/diurnal approximation.
  * Dwell times: log-normal per hub with an AR(1) congestion index and a seaport
    peak-season bulge, i.e. dwell delays that change day by day.
  * Faults: wrong setpoint, compressor degradation, humidity-control failure,
    hot (poorly pre-cooled) loads. These are the leading causes of real claims.
    Fault rates are deliberately enriched (~25-30% of loads carry at least one fault)
    so that downstream models see enough incident trajectories.

Spoilage kinetics (training labels)
-----------------------------------
Quality index Q in [0, 1] decays by zero-order kinetics with an Arrhenius rate:

    k(T) = A * exp(-Ea / (R * T))            [fraction of shelf life per day]

Ea is derived from the literature Q10 around the commodity's setpoint:
    Ea = ln(Q10) * R * T1 * T2 / 10,         where T2 = T1 + 10 K.
A is anchored so that k(T_setpoint) = 1 / shelf_life_at_setpoint.

Additive or multiplicative damage terms cover chilling injury, freezing injury,
water loss when relative humidity falls below optimum, and mechanical bruising
from shocks above 2.5 g. Kinetics use the simulated *pulp* temperature, while
telemetry reports air temperatures. This gives the Phase 2 model the same
observability gap that real-world systems face.

Lot-to-lot biological variability
---------------------------------
Real lots of the same commodity differ in storage life, which depends on cultivar,
maturity, growing conditions and field heat. Each shipment draws a latent lot
shelf-life factor f ~ LogNormal(0, 0.12) and a lot Q10 ~ Q10_ref * LogNormal(0, 0.06).
Kader notes that storage life varies inversely with respiration rate, so a lot's
respiration heat scales as 1/f. This gives a weak, physically honest signal in the
pulp-air temperature gap and in compressor duty. The latent lot factors are never
exposed as features. Load-out QC reports a *noisy estimate* of the initial RSL
(qc_rsl_days_at_load, CV 5% by default) and of the pulp temperature (+/- 0.3 C).

Label: remaining_shelf_life_days = Q / k_lot(T_setpoint), which is the true lot-specific
days of sellable life left if the cargo is held at setpoint from now on.

Status (green/amber/red) uses the worse of two arrival projections: (a) hold at
setpoint for the remaining transit, or (b) the current excursion persists to arrival.
A failed compressor therefore turns a container red while it still has sellable
life, which is the moment when diversion is valuable.

Outputs (under --out-dir). Parquet is used when pyarrow is installed; otherwise CSV.
  hubs, edges, hub_congestion, commodities, shipments, telemetry, depot_market,
  fleet_snapshot

Usage
-----
    python data_engine.py --containers 400 --interval-minutes 15 --seed 42 --out-dir data
"""
from __future__ import annotations

import argparse
import logging
import math
import string
import sys
import time
from dataclasses import dataclass, field, replace
from enum import Enum
from pathlib import Path
from typing import Any, Final, Literal, Mapping, Sequence

import networkx as nx
import numpy as np
import pandas as pd

LOGGER: Final[logging.Logger] = logging.getLogger("coldchain.data_engine")

# --------------------------------------------------------------------------------------
# Physical constants
# --------------------------------------------------------------------------------------
R_GAS_J_PER_MOL_K: Final[float] = 8.314462618
KELVIN_OFFSET: Final[float] = 273.15
EARTH_RADIUS_KM: Final[float] = 6371.0088
HOURS_PER_DAY: Final[float] = 24.0
DAYS_PER_YEAR: Final[float] = 365.25

# --------------------------------------------------------------------------------------
# Reefer thermal model (40' high-cube, fully loaded). This is a two-node lumped model.
# The time constants are chosen so that an unpowered loaded box warms its pulp at
# ~0.1 K/h at a 25 K ambient delta, in line with carrier guidance. Cooling capacity is
# ~10x the wall heat leak at design conditions. Units are K/h on the air node.
# --------------------------------------------------------------------------------------
REEFER_COOLING_CAPACITY_K_PER_H: Final[float] = 50.0
REEFER_HEATING_CAPACITY_K_PER_H: Final[float] = 25.0
EVAPORATOR_FAN_HEAT_K_PER_H: Final[float] = 7.5
DEFROST_HEAT_LEAK_K_PER_H: Final[float] = 6.0
TAU_WALL_CLOSED_H: Final[float] = 5.0
TAU_WALL_DOOR_OPEN_H: Final[float] = 0.2
TAU_AIR_CARGO_H: Final[float] = 0.25
TAU_PULP_H: Final[float] = 12.0
TAU_RH_H: Final[float] = 1.5
TAU_RH_DOOR_OPEN_H: Final[float] = 0.3
COIL_DEHUMIDIFICATION_PCT: Final[float] = 8.0
SUPPLY_RETURN_DELTA_K: Final[float] = 2.0
DEFROST_INTERVAL_H: Final[tuple[float, float]] = (6.0, 12.0)
DEFROST_DURATION_H: Final[float] = 0.5
MAX_INTEGRATION_STEP_H: Final[float] = 0.1

# --------------------------------------------------------------------------------------
# Damage model and status thresholds
# --------------------------------------------------------------------------------------
BRUISE_THRESHOLD_G: Final[float] = 2.5
FREEZE_DAMAGE_RATE_MULTIPLIER: Final[float] = 25.0  # x k_ref per degree C below freezing point
HANDLING_SHOCK_PROB: Final[float] = 0.85
HANDLING_SHOCK_G_RANGE: Final[tuple[float, float]] = (1.2, 3.2)
GREEN_MIN_ARRIVAL_FRACTION: Final[float] = 0.35  # projected RSL at arrival / reference shelf life
AMBER_MIN_ARRIVAL_FRACTION: Final[float] = 0.15
TRANSFER_FEE_USD: Final[float] = 350.0  # lift + dray + terminal handling per intermediate hub


# ======================================================================================
# Enumerations and reference data structures
# ======================================================================================
class NodeType(str, Enum):
    GROWING_REGION = "growing_region"
    LAND_PORT = "land_port"
    SEAPORT = "seaport"
    RAIL_RAMP = "rail_ramp"
    BUYER = "buyer"


class BuyerType(str, Enum):
    TERMINAL_MARKET = "terminal_market"
    RETAIL_DC = "retail_dc"
    PROCESSOR = "processor"
    FOOD_BANK = "food_bank"


class Mode(str, Enum):
    TRUCK = "truck"
    RAIL = "rail"
    OCEAN = "ocean"


class Status(str, Enum):
    GREEN = "green"
    AMBER = "amber"
    RED = "red"


@dataclass(frozen=True, slots=True)
class ModeSpec:
    """Operating characteristics of a transport mode."""

    circuity: float  # network distance / great-circle distance
    speed_kmh_mean: float  # effective door-to-door speed including rest and yard time
    speed_cv: float
    cost_usd_per_km: float  # indicative reefer linehaul rate
    vibration_base_g: float
    shock_rate_per_h: float
    shock_median_g: float
    shock_sigma: float
    power_failure_prob_per_leg: float  # genset or clip-on failure during the leg


MODE_SPECS: Final[Mapping[Mode, ModeSpec]] = {
    Mode.TRUCK: ModeSpec(1.20, 62.0, 0.15, 1.45, 0.35, 0.06, 1.3, 0.35, 0.01),
    Mode.RAIL: ModeSpec(1.25, 40.0, 0.15, 0.85, 0.25, 0.10, 1.6, 0.40, 0.06),
    Mode.OCEAN: ModeSpec(1.35, 29.0, 0.08, 0.55, 0.08, 0.01, 1.1, 0.30, 0.01),
}


@dataclass(frozen=True, slots=True)
class CommodityProfile:
    """Storage and economic reference data for a perishable commodity."""

    key: str
    display_name: str
    setpoint_c: float
    optimal_rh_pct: float
    shelf_life_days_at_setpoint: float
    q10: float
    highest_freezing_point_c: float
    chilling_threshold_c: float | None
    chilling_injury_coeff: float  # extra rate, as x k_ref per degree C below threshold
    rh_sensitivity: float  # rate multiplier increment per 10 %RH below optimum
    bruise_coeff: float  # quality loss per g above BRUISE_THRESHOLD_G, per event
    respiration_heat_k_per_h: float  # pulp self-heating at setpoint
    unit_value_usd_per_kg: float  # indicative wholesale; replace with USDA AMS Market News
    payload_kg: float
    per_capita_kg_per_year: float
    origins: tuple[tuple[str, tuple[int, ...]], ...]  # (hub code, active months; () = all year)
    processor_acceptable: bool
    reference: str

    @property
    def cargo_value_usd(self) -> float:
        return self.unit_value_usd_per_kg * self.payload_kg


COMMODITIES: Final[Mapping[str, CommodityProfile]] = {
    p.key: p
    for p in (
        CommodityProfile(
            key="strawberries", display_name="Strawberries",
            setpoint_c=0.0, optimal_rh_pct=92.5, shelf_life_days_at_setpoint=7.0, q10=3.5,
            highest_freezing_point_c=-0.8, chilling_threshold_c=None, chilling_injury_coeff=0.0,
            rh_sensitivity=0.20, bruise_coeff=0.004, respiration_heat_k_per_h=0.020,
            unit_value_usd_per_kg=4.00, payload_kg=12_000.0, per_capita_kg_per_year=3.6,
            origins=(("OXNARD", (1, 2, 3, 4, 5, 6)), ("SALINAS", (4, 5, 6, 7, 8, 9, 10)),
                     ("OTAY_MESA", (11, 12, 1, 2, 3, 4, 5))),
            processor_acceptable=True,
            reference="USDA AH-66: 0 C, 90-95% RH, 7-10 d; Kader Q10 ~3-4 (0-10 C)",
        ),
        CommodityProfile(
            key="blueberries", display_name="Blueberries",
            setpoint_c=0.0, optimal_rh_pct=92.5, shelf_life_days_at_setpoint=14.0, q10=3.2,
            highest_freezing_point_c=-1.3, chilling_threshold_c=None, chilling_injury_coeff=0.0,
            rh_sensitivity=0.15, bruise_coeff=0.002, respiration_heat_k_per_h=0.015,
            unit_value_usd_per_kg=7.50, payload_kg=12_000.0, per_capita_kg_per_year=1.0,
            origins=(("PHILADELPHIA", (12, 1, 2, 3)), ("LGB", (8, 9, 10, 11, 12, 1)),
                     ("PHARR", (10, 11, 12, 1, 2, 3, 4, 5)), ("TACOMA", (6, 7, 8, 9))),
            processor_acceptable=True,
            reference="USDA AH-66: -0.5-0 C, 90-95% RH, 10-18 d",
        ),
        CommodityProfile(
            key="iceberg_lettuce", display_name="Iceberg lettuce",
            setpoint_c=0.0, optimal_rh_pct=98.5, shelf_life_days_at_setpoint=21.0, q10=2.8,
            highest_freezing_point_c=-0.2, chilling_threshold_c=None, chilling_injury_coeff=0.0,
            rh_sensitivity=0.35, bruise_coeff=0.0015, respiration_heat_k_per_h=0.012,
            unit_value_usd_per_kg=1.20, payload_kg=18_000.0, per_capita_kg_per_year=5.2,
            origins=(("SALINAS", (4, 5, 6, 7, 8, 9, 10)), ("YUMA", (11, 12, 1, 2, 3))),
            processor_acceptable=False,
            reference="USDA AH-66: 0 C, 98-100% RH, 2-3 wk",
        ),
        CommodityProfile(
            key="avocados_hass", display_name="Avocados (Hass, mature-green)",
            setpoint_c=5.5, optimal_rh_pct=87.5, shelf_life_days_at_setpoint=21.0, q10=2.6,
            highest_freezing_point_c=-1.6, chilling_threshold_c=4.0, chilling_injury_coeff=0.08,
            rh_sensitivity=0.10, bruise_coeff=0.002, respiration_heat_k_per_h=0.030,
            unit_value_usd_per_kg=3.50, payload_kg=19_000.0, per_capita_kg_per_year=3.9,
            origins=(("PHARR", ()), ("LAREDO", ()), ("OXNARD", (3, 4, 5, 6, 7, 8, 9))),
            processor_acceptable=True,
            reference="USDA AH-66: Hass 5-7 C, 85-90% RH, 2-4 wk; chilling injury below ~4 C",
        ),
        CommodityProfile(
            key="bananas", display_name="Bananas (green)",
            setpoint_c=13.5, optimal_rh_pct=92.5, shelf_life_days_at_setpoint=21.0, q10=2.0,
            highest_freezing_point_c=-0.8, chilling_threshold_c=12.5, chilling_injury_coeff=0.25,
            rh_sensitivity=0.12, bruise_coeff=0.003, respiration_heat_k_per_h=0.025,
            unit_value_usd_per_kg=0.90, payload_kg=19_590.0, per_capita_kg_per_year=12.2,
            origins=(("WILMINGTON_DE", ()), ("GULFPORT", ()), ("EVERGLADES", ()), ("HUENEME", ())),
            processor_acceptable=True,
            reference="USDA AH-66: 13-14 C, 90-95% RH; chilling injury below ~12-13 C",
        ),
        CommodityProfile(
            key="atlantic_salmon_fresh", display_name="Atlantic salmon (fresh, iced)",
            setpoint_c=0.0, optimal_rh_pct=95.0, shelf_life_days_at_setpoint=14.0, q10=4.0,
            highest_freezing_point_c=-2.2, chilling_threshold_c=None, chilling_injury_coeff=0.0,
            rh_sensitivity=0.0, bruise_coeff=0.0, respiration_heat_k_per_h=0.0,
            unit_value_usd_per_kg=12.00, payload_kg=15_000.0, per_capita_kg_per_year=1.4,
            origins=(("VANCOUVER", ()), ("HALIFAX", ())),
            processor_acceptable=True,
            reference="Ross/Dalgaard RRS model (1+0.1T)^2 -> Q10~4; ~14 d at 0 C",
        ),
    )
}


@dataclass(frozen=True, slots=True)
class KineticModel:
    """Arrhenius degradation kinetics for a commodity (precomputed constants)."""

    profile: CommodityProfile
    activation_energy_j_per_mol: float
    pre_exponential_per_day: float
    k_ref_per_day: float

    @classmethod
    def from_profile(cls, profile: CommodityProfile) -> KineticModel:
        t_ref = profile.setpoint_c + KELVIN_OFFSET
        ea = math.log(profile.q10) * R_GAS_J_PER_MOL_K * t_ref * (t_ref + 10.0) / 10.0
        k_ref = 1.0 / profile.shelf_life_days_at_setpoint
        a = k_ref * math.exp(ea / (R_GAS_J_PER_MOL_K * t_ref))
        return cls(profile, ea, a, k_ref)

    @classmethod
    def for_lot(cls, profile: CommodityProfile, shelf_life_factor: float, q10: float | None) -> KineticModel:
        """Kinetics for a specific lot: scaled storage life and lot-specific temperature sensitivity."""
        lot_profile = replace(profile, shelf_life_days_at_setpoint=profile.shelf_life_days_at_setpoint * shelf_life_factor,
                              q10=profile.q10 if q10 is None else q10)
        return cls.from_profile(lot_profile)

    def arrhenius_rate_per_day(self, temp_c: float) -> float:
        """k = A * exp(-Ea / (R*T)) at the given product temperature."""
        temp_k = max(temp_c + KELVIN_OFFSET, 200.0)
        return self.pre_exponential_per_day * math.exp(
            -self.activation_energy_j_per_mol / (R_GAS_J_PER_MOL_K * temp_k)
        )

    def relative_rate(self, temp_c: float) -> float:
        return self.arrhenius_rate_per_day(temp_c) / self.k_ref_per_day

    def degradation_rate_per_day(self, pulp_temp_c: float, rh_pct: float) -> float:
        """Total quality-loss rate, combining Arrhenius, chilling, freezing and water loss."""
        p = self.profile
        k = self.arrhenius_rate_per_day(pulp_temp_c)
        if p.chilling_threshold_c is not None and pulp_temp_c < p.chilling_threshold_c:
            k += self.k_ref_per_day * p.chilling_injury_coeff * (p.chilling_threshold_c - pulp_temp_c)
        if pulp_temp_c < p.highest_freezing_point_c:
            k += self.k_ref_per_day * FREEZE_DAMAGE_RATE_MULTIPLIER * (
                p.highest_freezing_point_c - pulp_temp_c
            )
        rh_deficit = max(0.0, p.optimal_rh_pct - rh_pct)
        return k * (1.0 + p.rh_sensitivity * rh_deficit / 10.0)


@dataclass(frozen=True, slots=True)
class Hub:
    """A node of the logistics network."""

    code: str
    name: str
    lat: float
    lon: float
    node_type: NodeType
    country: str
    dwell_median_h: float
    dwell_sigma: float
    door_open_prob: float  # inspection or cross-dock door opening during dwell
    power_gap_prob: float  # unplugged interval during transfer
    buyer_type: BuyerType | None = None
    metro_population_m: float = 0.0
    accepts: tuple[str, ...] = ()


ALL_COMMODITY_KEYS: Final[tuple[str, ...]] = tuple(COMMODITIES)
PROCESSOR_KEYS: Final[tuple[str, ...]] = tuple(k for k, p in COMMODITIES.items() if p.processor_acceptable)


def _grower(code: str, name: str, lat: float, lon: float) -> Hub:
    return Hub(code, name, lat, lon, NodeType.GROWING_REGION, "US", 3.0, 0.4, 0.0, 0.0)


def _land_port(code: str, name: str, lat: float, lon: float, dwell_h: float) -> Hub:
    # USDA/CBP inspection of produce trucks makes door openings likely.
    return Hub(code, name, lat, lon, NodeType.LAND_PORT, "US", dwell_h, 0.6, 0.55, 0.2)


def _seaport(code: str, name: str, lat: float, lon: float, country: str, dwell_h: float) -> Hub:
    return Hub(code, name, lat, lon, NodeType.SEAPORT, country, dwell_h, 0.55, 0.12, 0.65)


def _ramp(code: str, name: str, lat: float, lon: float, country: str) -> Hub:
    return Hub(code, name, lat, lon, NodeType.RAIL_RAMP, country, 10.0, 0.5, 0.02, 0.6)


def _buyer(code: str, name: str, lat: float, lon: float, country: str, buyer_type: BuyerType,
           population_m: float, accepts: tuple[str, ...] = ALL_COMMODITY_KEYS) -> Hub:
    return Hub(code, name, lat, lon, NodeType.BUYER, country, 6.0, 0.4, 0.25, 0.2,
               buyer_type, population_m, accepts)


# Real locations. Coordinates are approximate terminal or market sites (WGS84).
HUBS: Final[tuple[Hub, ...]] = (
    # Growing regions (origins)
    _grower("SALINAS", "Salinas Valley, CA", 36.6777, -121.6555),
    _grower("OXNARD", "Oxnard Plain, CA", 34.1975, -119.1771),
    _grower("YUMA", "Yuma, AZ (winter lettuce)", 32.6927, -114.6277),
    # US-Mexico produce crossings
    _land_port("NOGALES", "Nogales Mariposa POE, AZ", 31.3404, -110.9343, 6.0),
    _land_port("PHARR", "Pharr-Reynosa Intl Bridge, TX", 26.1948, -98.1836, 8.0),
    _land_port("LAREDO", "Laredo World Trade Bridge, TX", 27.5306, -99.4803, 10.0),
    _land_port("OTAY_MESA", "Otay Mesa POE, CA", 32.5530, -116.9380, 5.0),
    # Seaports
    _seaport("LGB", "San Pedro Bay Ports (LA/Long Beach)", 33.7542, -118.2165, "US", 40.0),
    _seaport("HUENEME", "Port of Hueneme, CA", 34.1486, -119.2083, "US", 18.0),
    _seaport("OAKLAND", "Port of Oakland, CA", 37.7956, -122.2789, "US", 36.0),
    _seaport("TACOMA", "Northwest Seaport Alliance (Tacoma)", 47.2690, -122.4130, "US", 36.0),
    _seaport("VANCOUVER", "Port of Vancouver, BC", 49.2888, -123.1111, "CA", 48.0),
    _seaport("HALIFAX", "Port of Halifax, NS", 44.6310, -63.5660, "CA", 36.0),
    _seaport("MONTREAL_PORT", "Port of Montreal, QC", 45.5600, -73.5200, "CA", 36.0),
    _seaport("NYNJ", "Port Newark-Elizabeth, NJ", 40.6840, -74.1480, "US", 40.0),
    _seaport("PHILADELPHIA", "Port of Philadelphia (Packer Ave), PA", 39.9040, -75.1370, "US", 18.0),
    _seaport("WILMINGTON_DE", "Port of Wilmington, DE", 39.7160, -75.5260, "US", 18.0),
    _seaport("NORFOLK", "Port of Virginia (Norfolk Intl Terminals)", 36.9280, -76.3250, "US", 36.0),
    _seaport("CHARLESTON", "Port of Charleston (Wando Welch), SC", 32.8360, -79.8950, "US", 36.0),
    _seaport("SAVANNAH", "Port of Savannah (Garden City), GA", 32.1300, -81.1400, "US", 36.0),
    _seaport("EVERGLADES", "Port Everglades, FL", 26.0920, -80.1210, "US", 18.0),
    _seaport("GULFPORT", "Port of Gulfport, MS", 30.3560, -89.0860, "US", 18.0),
    _seaport("HOUSTON", "Port Houston (Barbours Cut), TX", 29.6870, -95.0000, "US", 36.0),
    # Intermodal rail ramps
    _ramp("CHI_RAMP", "Chicago intermodal (Joliet/Elwood), IL", 41.4150, -88.1100, "US"),
    _ramp("KC_RAMP", "Kansas City intermodal (Edgerton), KS", 38.7650, -94.9940, "US"),
    _ramp("DAL_RAMP", "Dallas-Fort Worth intermodal (Alliance), TX", 32.9850, -97.3190, "US"),
    _ramp("MEM_RAMP", "Memphis intermodal, TN", 35.1495, -90.0490, "US"),
    _ramp("ATL_RAMP", "Atlanta intermodal (Fairburn), GA", 33.5670, -84.5810, "US"),
    _ramp("COL_RAMP", "Columbus intermodal (Rickenbacker), OH", 39.8140, -82.9280, "US"),
    _ramp("TOR_RAMP", "Toronto intermodal (Brampton), ON", 43.7300, -79.7600, "CA"),
    _ramp("CAL_RAMP", "Calgary intermodal, AB", 51.0900, -113.9500, "CA"),
    # Wholesale terminal markets (real facilities)
    _buyer("HUNTS_POINT", "Hunts Point Produce Market, Bronx NY", 40.8065, -73.8740, "US", BuyerType.TERMINAL_MARKET, 19.5),
    _buyer("PHL_WPM", "Philadelphia Wholesale Produce Market", 39.8966, -75.1780, "US", BuyerType.TERMINAL_MARKET, 6.2),
    _buyer("BOSTON_NEPC", "New England Produce Center, Chelsea MA", 42.3925, -71.0440, "US", BuyerType.TERMINAL_MARKET, 4.9),
    _buyer("CHICAGO_IPM", "Chicago International Produce Market", 41.8466, -87.6818, "US", BuyerType.TERMINAL_MARKET, 9.3),
    _buyer("LA_WPM", "Los Angeles Wholesale Produce Market", 34.0310, -118.2420, "US", BuyerType.TERMINAL_MARKET, 12.8),
    _buyer("SF_WPM", "San Francisco Wholesale Produce Market", 37.7445, -122.3880, "US", BuyerType.TERMINAL_MARKET, 4.6),
    _buyer("ATL_SFM", "Atlanta State Farmers Market, Forest Park GA", 33.6330, -84.3960, "US", BuyerType.TERMINAL_MARKET, 6.3),
    _buyer("TORONTO_OFT", "Ontario Food Terminal, Toronto", 43.6320, -79.4935, "CA", BuyerType.TERMINAL_MARKET, 6.7),
    _buyer("MONTREAL_MC", "Marche Central, Montreal", 45.5335, -73.6560, "CA", BuyerType.TERMINAL_MARKET, 4.4),
    # Regional grocery DCs (metro-level locations)
    _buyer("DALLAS_RDC", "Regional grocery DC - Dallas-Fort Worth", 32.7767, -96.7970, "US", BuyerType.RETAIL_DC, 8.1),
    _buyer("HOUSTON_RDC", "Regional grocery DC - Houston", 29.7604, -95.3698, "US", BuyerType.RETAIL_DC, 7.5),
    _buyer("MIAMI_RDC", "Regional grocery DC - Miami", 25.7617, -80.1918, "US", BuyerType.RETAIL_DC, 6.1),
    _buyer("PHOENIX_RDC", "Regional grocery DC - Phoenix", 33.4484, -112.0740, "US", BuyerType.RETAIL_DC, 5.1),
    _buyer("SEATTLE_RDC", "Regional grocery DC - Seattle", 47.6062, -122.3321, "US", BuyerType.RETAIL_DC, 4.0),
    _buyer("MINNEAPOLIS_RDC", "Regional grocery DC - Minneapolis", 44.9778, -93.2650, "US", BuyerType.RETAIL_DC, 3.7),
    _buyer("DENVER_RDC", "Regional grocery DC - Denver", 39.7392, -104.9903, "US", BuyerType.RETAIL_DC, 3.0),
    _buyer("COLUMBUS_RDC", "Regional grocery DC - Columbus", 39.9612, -82.9988, "US", BuyerType.RETAIL_DC, 2.2),
    _buyer("KC_RDC", "Regional grocery DC - Kansas City", 39.0997, -94.5786, "US", BuyerType.RETAIL_DC, 2.2),
    _buyer("SLC_RDC", "Regional grocery DC - Salt Lake City", 40.7608, -111.8910, "US", BuyerType.RETAIL_DC, 1.3),
    _buyer("CALGARY_RDC", "Regional grocery DC - Calgary", 51.0447, -114.0719, "CA", BuyerType.RETAIL_DC, 1.6),
    # Secondary / salvage channels
    _buyer("WATSONVILLE_PROC", "Berry freezing & processing cluster - Watsonville CA", 36.9102, -121.7569, "US", BuyerType.PROCESSOR, 0.0, PROCESSOR_KEYS),
    _buyer("OXNARD_PROC", "Frozen fruit processing - Oxnard CA", 34.2100, -119.1400, "US", BuyerType.PROCESSOR, 0.0, PROCESSOR_KEYS),
    _buyer("MIDWEST_PROC", "Fruit & seafood processing - Chicago area", 41.7500, -87.8000, "US", BuyerType.PROCESSOR, 0.0, PROCESSOR_KEYS),
    _buyer("NYC_FOODBANK", "Food bank network - New York", 40.8110, -73.8790, "US", BuyerType.FOOD_BANK, 19.5),
    _buyer("CHI_FOODBANK", "Food bank network - Chicago", 41.8190, -87.7230, "US", BuyerType.FOOD_BANK, 9.3),
    _buyer("LA_FOODBANK", "Food bank network - Los Angeles", 33.9990, -118.2290, "US", BuyerType.FOOD_BANK, 12.8),
    _buyer("HOU_FOODBANK", "Food bank network - Houston", 29.7900, -95.3100, "US", BuyerType.FOOD_BANK, 7.5),
    _buyer("ATL_FOODBANK", "Food bank network - Atlanta", 33.7700, -84.4200, "US", BuyerType.FOOD_BANK, 6.3),
)

# Intermodal corridors actually operated by North American Class I railroads (bidirectional).
RAIL_CORRIDORS: Final[tuple[tuple[str, str], ...]] = (
    ("LGB", "CHI_RAMP"), ("LGB", "DAL_RAMP"), ("LGB", "KC_RAMP"), ("LGB", "MEM_RAMP"),
    ("HUENEME", "CHI_RAMP"), ("HUENEME", "DAL_RAMP"),
    ("OAKLAND", "CHI_RAMP"), ("TACOMA", "CHI_RAMP"),
    ("VANCOUVER", "TOR_RAMP"), ("VANCOUVER", "CAL_RAMP"), ("VANCOUVER", "CHI_RAMP"),
    ("HALIFAX", "TOR_RAMP"), ("HALIFAX", "MONTREAL_PORT"), ("MONTREAL_PORT", "TOR_RAMP"),
    ("MONTREAL_PORT", "CHI_RAMP"), ("TOR_RAMP", "CHI_RAMP"), ("CAL_RAMP", "TOR_RAMP"),
    ("NYNJ", "CHI_RAMP"), ("NYNJ", "COL_RAMP"), ("NORFOLK", "CHI_RAMP"), ("NORFOLK", "COL_RAMP"),
    ("PHILADELPHIA", "CHI_RAMP"), ("SAVANNAH", "ATL_RAMP"), ("SAVANNAH", "MEM_RAMP"),
    ("CHARLESTON", "ATL_RAMP"), ("EVERGLADES", "ATL_RAMP"), ("HOUSTON", "DAL_RAMP"),
    ("HOUSTON", "CHI_RAMP"), ("GULFPORT", "MEM_RAMP"), ("LAREDO", "DAL_RAMP"),
    ("LAREDO", "KC_RAMP"), ("LAREDO", "CHI_RAMP"), ("KC_RAMP", "CHI_RAMP"),
    ("MEM_RAMP", "CHI_RAMP"), ("DAL_RAMP", "CHI_RAMP"), ("ATL_RAMP", "CHI_RAMP"),
)

# Coastal short-sea / feeder lanes (bidirectional).
OCEAN_LANES: Final[tuple[tuple[str, str], ...]] = (
    ("LGB", "OAKLAND"), ("OAKLAND", "TACOMA"), ("TACOMA", "VANCOUVER"),
    ("EVERGLADES", "SAVANNAH"), ("SAVANNAH", "CHARLESTON"), ("CHARLESTON", "NORFOLK"),
    ("NORFOLK", "NYNJ"), ("NORFOLK", "PHILADELPHIA"), ("NYNJ", "HALIFAX"),
    ("HALIFAX", "MONTREAL_PORT"), ("GULFPORT", "HOUSTON"), ("GULFPORT", "EVERGLADES"),
)


@dataclass(frozen=True, slots=True)
class BuyerEconomics:
    share_of_metro_demand: float
    target_days_of_supply: float
    price_realization: float  # fraction of reference wholesale value realized on diversion
    min_rsl_fraction: float  # minimum remaining shelf-life fraction the buyer accepts
    fixed_capacity_kg_per_day: float = 0.0


BUYER_ECONOMICS: Final[Mapping[BuyerType, BuyerEconomics]] = {
    # min_rsl_fraction is aligned with fleet status: retail accepts what "green" delivers (>= 35% of
    # reference shelf life); terminal markets clear amber loads; processors and food banks take the rest.
    BuyerType.TERMINAL_MARKET: BuyerEconomics(0.15, 2.5, 0.80, 0.20),
    BuyerType.RETAIL_DC: BuyerEconomics(0.25, 3.0, 1.00, 0.35),
    BuyerType.PROCESSOR: BuyerEconomics(0.0, 5.0, 0.35, 0.03, 120_000.0),
    # Donations realize no cash price. The US enhanced deduction (IRC 170(e)(3)) is
    # taxpayer-specific, so it is deliberately left out of price_realization.
    BuyerType.FOOD_BANK: BuyerEconomics(0.015, 4.0, 0.0, 0.10),
}


# ======================================================================================
# Geometry, climate and identifiers
# ======================================================================================
def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi, dlmb = phi2 - phi1, math.radians(lon2 - lon1)
    a = math.sin(dphi / 2.0) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlmb / 2.0) ** 2
    return 2.0 * EARTH_RADIUS_KM * math.asin(math.sqrt(min(1.0, a)))


def ambient_conditions(lat: float, lon: float, day_of_year: float, utc_hour: float,
                       rh_bias_pct: float = 0.0) -> tuple[float, float]:
    """Approximate outdoor dry-bulb temperature (C) and relative humidity (%).

    Annual mean ~ 44 - 0.75*|lat| (within ~3 C of NOAA/ECCC normals for the hubs used),
    seasonal amplitude grows with latitude, the seasonal peak is ~20 July (N. hemisphere),
    and the diurnal peak is 15:00 local solar time.
    """
    abs_lat = abs(lat)
    annual_mean = min(29.0, max(-5.0, 44.0 - 0.75 * abs_lat))
    seasonal_amp = max(1.5, 0.6 * (abs_lat - 20.0))
    hemisphere = 1.0 if lat >= 0.0 else -1.0
    seasonal = hemisphere * seasonal_amp * math.cos(2.0 * math.pi * (day_of_year - 201.0) / DAYS_PER_YEAR)
    local_hour = (utc_hour + lon / 15.0) % 24.0
    diurnal = 5.0 * math.cos(2.0 * math.pi * (local_hour - 15.0) / 24.0)
    temp_c = annual_mean + seasonal + diurnal
    rh = 68.0 - 2.5 * diurnal + 0.3 * (annual_mean - 15.0) + rh_bias_pct
    return temp_c, min(100.0, max(15.0, rh))


def _iso6346_letter_values() -> dict[str, int]:
    values: dict[str, int] = {}
    v = 10
    for ch in string.ascii_uppercase:
        if v % 11 == 0:
            v += 1
        values[ch] = v
        v += 1
    return values


_ISO6346_VALUES: Final[dict[str, int]] = _iso6346_letter_values()


def iso6346_check_digit(owner_and_serial: str) -> int:
    """ISO 6346 check digit for a 10-character code (4 letters + 6 digits)."""
    if len(owner_and_serial) != 10:
        raise ValueError(f"Expected 10 characters, got {owner_and_serial!r}")
    total = 0
    for i, ch in enumerate(owner_and_serial):
        value = _ISO6346_VALUES[ch] if ch.isalpha() else int(ch)
        total += value * (2 ** i)
    return total % 11 % 10


def make_container_id(owner_prefix: str, serial: int) -> str:
    """Build an ISO 6346 container number (owner prefix must end in 'U', i.e. freight container)."""
    body = f"{owner_prefix}{serial:06d}"
    return f"{body}{iso6346_check_digit(body)}"


# ======================================================================================
# Logistics network
# ======================================================================================
@dataclass(frozen=True, slots=True)
class Leg:
    origin: str
    destination: str
    mode: Mode
    distance_km: float
    planned_hours: float


class LogisticsNetwork:
    """Multimodal North American cold-chain network (NetworkX MultiDiGraph)."""

    def __init__(self, hubs: Sequence[Hub] = HUBS,
                 rail_corridors: Sequence[tuple[str, str]] = RAIL_CORRIDORS,
                 ocean_lanes: Sequence[tuple[str, str]] = OCEAN_LANES) -> None:
        codes = [h.code for h in hubs]
        if len(codes) != len(set(codes)):
            raise ValueError("Duplicate hub codes in network definition")
        self.hubs: dict[str, Hub] = {h.code: h for h in hubs}
        self.graph: nx.MultiDiGraph = self._build_graph(rail_corridors, ocean_lanes)

    def _add_edge_pair(self, g: nx.MultiDiGraph, a: str, b: str, mode: Mode) -> None:
        for u, v in ((a, b), (b, a)):
            if u not in self.hubs or v not in self.hubs:
                raise ValueError(f"Corridor references unknown hub: {u}->{v}")
            hu, hv = self.hubs[u], self.hubs[v]
            spec = MODE_SPECS[mode]
            dist = haversine_km(hu.lat, hu.lon, hv.lat, hv.lon) * spec.circuity
            g.add_edge(u, v, key=mode.value, mode=mode.value, distance_km=dist,
                       planned_hours=dist / spec.speed_kmh_mean, cost_usd_per_km=spec.cost_usd_per_km)

    def _build_graph(self, rail: Sequence[tuple[str, str]], ocean: Sequence[tuple[str, str]]) -> nx.MultiDiGraph:
        g: nx.MultiDiGraph = nx.MultiDiGraph()
        for hub in self.hubs.values():
            g.add_node(hub.code, name=hub.name, lat=hub.lat, lon=hub.lon, node_type=hub.node_type.value,
                       dwell_median_h=hub.dwell_median_h)
        codes = list(self.hubs)
        # Reefer trucking reaches every continental hub directly.
        for i, a in enumerate(codes):
            for b in codes[i + 1:]:
                self._add_edge_pair(g, a, b, Mode.TRUCK)
        for a, b in rail:
            self._add_edge_pair(g, a, b, Mode.RAIL)
        for a, b in ocean:
            for code in (a, b):
                if self.hubs[code].node_type is not NodeType.SEAPORT:
                    raise ValueError(f"Ocean lane endpoint {code} is not a seaport")
            self._add_edge_pair(g, a, b, Mode.OCEAN)
        return g

    def plan_route(self, origin: str, destination: str, value_of_time_usd_per_h: float) -> list[Leg]:
        """Minimum generalized-cost route: linehaul $ + time value + transfer fees + expected dwell."""
        if origin == destination:
            raise ValueError("Origin and destination must differ")
        hubs = self.hubs

        def edge_cost(attrs: Mapping[str, Any]) -> float:
            return (float(attrs["distance_km"]) * float(attrs["cost_usd_per_km"])
                    + float(attrs["planned_hours"]) * value_of_time_usd_per_h)

        def weight(u: str, v: str, keyed: Mapping[str, Mapping[str, Any]]) -> float:
            cost = min(edge_cost(a) for a in keyed.values())
            if v != destination:
                cost += TRANSFER_FEE_USD + hubs[v].dwell_median_h * value_of_time_usd_per_h
            return cost

        path: list[str] = nx.shortest_path(self.graph, origin, destination, weight=weight)
        legs: list[Leg] = []
        for u, v in zip(path[:-1], path[1:]):
            keyed = self.graph[u][v]
            best = min(keyed.values(), key=edge_cost)
            legs.append(Leg(u, v, Mode(best["mode"]), float(best["distance_km"]), float(best["planned_hours"])))
        return legs

    def primary_buyers(self, commodity: str) -> list[Hub]:
        return [h for h in self.hubs.values()
                if h.node_type is NodeType.BUYER
                and h.buyer_type in (BuyerType.TERMINAL_MARKET, BuyerType.RETAIL_DC)
                and commodity in h.accepts]

    def buyers(self) -> list[Hub]:
        return [h for h in self.hubs.values() if h.node_type is NodeType.BUYER]

    def hubs_frame(self) -> pd.DataFrame:
        rows = [{
            "hub_code": h.code, "name": h.name, "lat": h.lat, "lon": h.lon,
            "node_type": h.node_type.value, "country": h.country,
            "dwell_median_h": h.dwell_median_h, "dwell_sigma": h.dwell_sigma,
            "door_open_prob": h.door_open_prob, "power_gap_prob": h.power_gap_prob,
            "buyer_type": h.buyer_type.value if h.buyer_type else "",
            "metro_population_m": h.metro_population_m, "accepts": "|".join(h.accepts),
        } for h in self.hubs.values()]
        return pd.DataFrame(rows)

    def edges_frame(self) -> pd.DataFrame:
        rows = [{"from_hub": u, "to_hub": v, "mode": d["mode"], "distance_km": round(d["distance_km"], 1),
                 "planned_hours": round(d["planned_hours"], 2), "cost_usd_per_km": d["cost_usd_per_km"]}
                for u, v, d in self.graph.edges(data=True)]
        return pd.DataFrame(rows)


# ======================================================================================
# Dynamic dwell (congestion) model
# ======================================================================================
class CongestionModel:
    """Daily dwell multiplier per hub: AR(1) log-process plus a seaport peak-season bulge."""

    def __init__(self, network: LogisticsNetwork, start: pd.Timestamp, n_days: int,
                 rng: np.random.Generator, phi: float = 0.85, sigma: float = 0.12) -> None:
        self.start = start.normalize()
        self.n_days = n_days
        self.codes: list[str] = list(network.hubs)
        self._index = {c: i for i, c in enumerate(self.codes)}
        x = np.zeros((len(self.codes), n_days))
        x[:, 0] = rng.normal(0.0, sigma / math.sqrt(1 - phi ** 2), len(self.codes))
        shocks = rng.normal(0.0, sigma, (len(self.codes), n_days))
        for d in range(1, n_days):
            x[:, d] = phi * x[:, d - 1] + shocks[:, d]
        doy = (pd.date_range(self.start, periods=n_days, freq="D").dayofyear.to_numpy()).astype(float)
        peak = 0.15 * np.exp(-(((doy - 260.0) / 35.0) ** 2))  # Aug-Oct import peak season
        is_seaport = np.array([network.hubs[c].node_type is NodeType.SEAPORT for c in self.codes])
        self._matrix = np.exp(x) * (1.0 + np.outer(is_seaport.astype(float), peak))

    def multiplier(self, hub_code: str, day_index: int) -> float:
        d = min(max(day_index, 0), self.n_days - 1)
        return float(self._matrix[self._index[hub_code], d])

    def to_frame(self) -> pd.DataFrame:
        dates = pd.date_range(self.start, periods=self.n_days, freq="D")
        return pd.DataFrame({
            "date": np.tile(dates, len(self.codes)),
            "hub_code": np.repeat(self.codes, self.n_days),
            "congestion_multiplier": self._matrix.ravel().round(4),
        })


# ======================================================================================
# Shipment simulation
# ======================================================================================
@dataclass(frozen=True, slots=True)
class ReeferFaults:
    setpoint_offset_c: float = 0.0
    compressor_fault_fraction: float | None = None  # position in trip (0..1) where degradation starts
    compressor_residual_capacity: float = 1.0
    rh_control_offset_pct: float = 0.0
    hot_load: bool = False

    def labels(self) -> str:
        tags: list[str] = []
        if self.setpoint_offset_c > 0:
            tags.append("setpoint_too_warm")
        elif self.setpoint_offset_c < 0:
            tags.append("setpoint_too_cold")
        if self.compressor_fault_fraction is not None:
            tags.append("compressor_degradation")
        if self.rh_control_offset_pct < 0:
            tags.append("humidity_control_fault")
        if self.hot_load:
            tags.append("hot_load")
        return "|".join(tags) if tags else "none"


@dataclass(frozen=True, slots=True)
class ShipmentSpec:
    container_id: str
    commodity: str
    origin: str
    destination: str
    departure: pd.Timestamp
    initial_quality: float
    initial_pulp_temp_c: float
    value_of_time_usd_per_h: float
    faults: ReeferFaults
    lot_shelf_life_factor: float = 1.0
    lot_q10: float | None = None
    qc_rsl_days_at_load: float | None = None
    qc_pulp_temp_c_at_load: float | None = None


@dataclass(frozen=True, slots=True)
class Segment:
    kind: Literal["leg", "dwell"]
    start_h: float
    end_h: float
    mode: Mode | None
    from_code: str
    to_code: str
    lat0: float
    lon0: float
    lat1: float
    lon1: float
    door_windows: tuple[tuple[float, float], ...] = ()
    power_gaps: tuple[tuple[float, float], ...] = ()

    @property
    def activity(self) -> str:
        return self.mode.value if self.mode is not None else "dwell"

    def position(self, t: float) -> tuple[float, float]:
        span = self.end_h - self.start_h
        f = 0.0 if span <= 0 else min(1.0, max(0.0, (t - self.start_h) / span))
        return self.lat0 + (self.lat1 - self.lat0) * f, self.lon0 + (self.lon1 - self.lon0) * f

    def door_open(self, t: float) -> bool:
        return any(a <= t < b for a, b in self.door_windows)

    def powered(self, t: float) -> bool:
        return not any(a <= t < b for a, b in self.power_gaps)


def build_segments(legs: Sequence[Leg], network: LogisticsNetwork, congestion: CongestionModel,
                   departure_day_index: int, rng: np.random.Generator) -> list[Segment]:
    segments: list[Segment] = []
    t = 0.0
    for i, leg in enumerate(legs):
        spec = MODE_SPECS[leg.mode]
        speed = spec.speed_kmh_mean * max(0.5, 1.0 + spec.speed_cv * rng.standard_normal())
        duration = leg.distance_km / speed
        gaps: tuple[tuple[float, float], ...] = ()
        if rng.random() < spec.power_failure_prob_per_leg:
            g0 = t + rng.uniform(0.1, 0.8) * duration
            gaps = ((g0, min(g0 + rng.uniform(2.0, 14.0), t + duration)),)
        a, b = network.hubs[leg.origin], network.hubs[leg.destination]
        segments.append(Segment("leg", t, t + duration, leg.mode, a.code, b.code,
                                a.lat, a.lon, b.lat, b.lon, (), gaps))
        t += duration
        if i == len(legs) - 1:
            break
        day = departure_day_index + int(t // HOURS_PER_DAY)
        dwell = max(0.5, b.dwell_median_h * math.exp(b.dwell_sigma * rng.standard_normal())
                    * congestion.multiplier(b.code, day))
        doors: list[tuple[float, float]] = []
        if rng.random() < b.door_open_prob:
            d0 = t + rng.uniform(0.05, 0.9) * dwell
            doors.append((d0, min(d0 + rng.uniform(0.25, 1.0), t + dwell)))
        dwell_gaps: list[tuple[float, float]] = []
        if rng.random() < b.power_gap_prob:
            p0 = t + rng.uniform(0.0, 0.3) * dwell
            dwell_gaps.append((p0, min(p0 + 1.2 * math.exp(0.8 * rng.standard_normal()), t + dwell)))
        segments.append(Segment("dwell", t, t + dwell, None, b.code, b.code, b.lat, b.lon, b.lat, b.lon,
                                tuple(doors), tuple(dwell_gaps)))
        t += dwell
    return segments


def classify_status(projected_arrival_rsl_days: float, shelf_life_ref_days: float, quality: float) -> Status:
    frac = projected_arrival_rsl_days / shelf_life_ref_days
    if quality <= 0.0 or frac < AMBER_MIN_ARRIVAL_FRACTION:
        return Status.RED
    if frac < GREEN_MIN_ARRIVAL_FRACTION:
        return Status.AMBER
    return Status.GREEN


def simulate_shipment(spec: ShipmentSpec, network: LogisticsNetwork, congestion: CongestionModel,
                      sample_interval_h: float, rng: np.random.Generator) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Integrate reefer thermodynamics and Arrhenius spoilage along a planned route."""
    profile = COMMODITIES[spec.commodity]
    kin = KineticModel.for_lot(profile, spec.lot_shelf_life_factor, spec.lot_q10)
    resp_heat_lot = profile.respiration_heat_k_per_h / spec.lot_shelf_life_factor
    legs = network.plan_route(spec.origin, spec.destination, spec.value_of_time_usd_per_h)
    day0 = int((spec.departure.normalize() - congestion.start).days)
    segments = build_segments(legs, network, congestion, day0, rng)
    total_h = segments[-1].end_h
    last_seg = len(segments) - 1
    n_rec = max(1, math.ceil(total_h / sample_interval_h))
    n_sub = max(1, math.ceil(sample_interval_h / MAX_INTEGRATION_STEP_H))
    faults = spec.faults
    fault_at_h = None if faults.compressor_fault_fraction is None else faults.compressor_fault_fraction * total_h

    f64 = lambda: np.empty(n_rec, dtype=np.float64)  # noqa: E731
    i8 = lambda: np.empty(n_rec, dtype=np.int8)  # noqa: E731
    elapsed, lat_a, lon_a = f64(), f64(), f64()
    amb_t, amb_rh, sp_a = f64(), f64(), f64()
    supply, ret, pulp_a, rh_a = f64(), f64(), f64(), f64()
    vib, duty_a = f64(), f64()
    door_a, power_a, defrost_a = i8(), i8(), i8()
    k_a, q_a, rsl_a, h0_a, rem_a, proj_a, projc_a = f64(), f64(), f64(), f64(), f64(), f64(), f64()
    activity: list[str] = []
    from_hub: list[str] = []
    to_hub: list[str] = []
    status: list[str] = []

    setpoint = profile.setpoint_c + faults.setpoint_offset_c
    rh_base = min(99.0, profile.optimal_rh_pct + faults.rh_control_offset_pct)
    pulp = spec.initial_pulp_temp_c
    air = setpoint + 0.5 * (pulp - setpoint)
    rh = rh_base
    q = spec.initial_quality
    dep = spec.departure
    start_hour = dep.hour + dep.minute / 60.0
    start_doy = dep.dayofyear - 1 + start_hour / HOURS_PER_DAY
    rh_bias = float(rng.normal(0.0, 8.0))
    next_defrost = float(rng.uniform(1.0, DEFROST_INTERVAL_H[1]))
    defrost_until = -1.0
    ptr = 0

    def advance(t: float, p: int) -> int:
        while p < last_seg and t >= segments[p].end_h:
            p += 1
        return p

    for i in range(n_rec):
        t0 = i * sample_interval_h
        t1 = min((i + 1) * sample_interval_h, total_h)
        h = (t1 - t0) / n_sub
        ptr_start = advance(t0, ptr)
        duty_acc = powered_time = 0.0
        door_any = defrost_any = False
        for s in range(n_sub):
            tau = t0 + s * h
            ptr = advance(tau, ptr)
            seg = segments[ptr]
            lat, lon = seg.position(tau)
            amb, amb_h = ambient_conditions(lat, lon, (start_doy + tau / HOURS_PER_DAY) % DAYS_PER_YEAR,
                                            (start_hour + tau) % HOURS_PER_DAY, rh_bias)
            door = seg.door_open(tau)
            powered = seg.powered(tau)
            if tau >= next_defrost:
                defrost_until = next_defrost + DEFROST_DURATION_H
                next_defrost = defrost_until + float(rng.uniform(*DEFROST_INTERVAL_H))
            defrosting = powered and tau < defrost_until
            health = faults.compressor_residual_capacity if (fault_at_h is not None and tau >= fault_at_h) else 1.0
            derate = min(1.1, max(0.8, 1.1 - 0.005 * amb))
            cap_cool = REEFER_COOLING_CAPACITY_K_PER_H * health * derate if (powered and not defrosting) else 0.0
            cap_heat = REEFER_HEATING_CAPACITY_K_PER_H if powered else 0.0
            tau_wall = TAU_WALL_DOOR_OPEN_H if door else TAU_WALL_CLOSED_H
            flux = (amb - air) / tau_wall + (pulp - air) / TAU_AIR_CARGO_H
            if powered:
                flux += EVAPORATOR_FAN_HEAT_K_PER_H
            if defrosting:
                flux += DEFROST_HEAT_LEAK_K_PER_H
            required = (air + flux * h - setpoint) / h
            cool = min(max(required, 0.0), cap_cool)
            heat = min(max(-required, 0.0), cap_heat)
            air_next = air + (flux - cool + heat) * h
            resp = resp_heat_lot * kin.relative_rate(pulp)
            pulp_next = pulp + ((air - pulp) / TAU_PULP_H + resp) * h
            duty_inst = cool / REEFER_COOLING_CAPACITY_K_PER_H
            if door:
                rh_eq, tau_rh = amb_h, TAU_RH_DOOR_OPEN_H
            elif powered:
                rh_eq, tau_rh = rh_base - COIL_DEHUMIDIFICATION_PCT * duty_inst, TAU_RH_H
            else:
                rh_eq, tau_rh = min(99.5, rh_base + 3.0), TAU_RH_H
            rh = min(100.0, max(20.0, rh + (rh_eq - rh) * min(1.0, h / tau_rh)))
            q -= kin.degradation_rate_per_day(pulp, rh) * h / HOURS_PER_DAY
            air, pulp = air_next, pulp_next
            duty_acc += duty_inst
            powered_time += h if powered else 0.0
            door_any |= door
            defrost_any |= defrosting

        # Mechanical shocks over the interval.
        ptr = advance(t1, ptr)
        mid_seg = segments[advance(0.5 * (t0 + t1), ptr_start)]
        dt_int = t1 - t0
        if mid_seg.mode is not None:
            ms = MODE_SPECS[mid_seg.mode]
            peak = ms.vibration_base_g * abs(1.0 + 0.25 * rng.standard_normal())
            n_events = int(rng.poisson(ms.shock_rate_per_h * dt_int))
            event_g = [ms.shock_median_g * math.exp(ms.shock_sigma * rng.standard_normal()) for _ in range(n_events)]
        else:
            peak = 0.02 * abs(1.0 + 0.25 * rng.standard_normal())
            event_g = []
        if ptr != ptr_start and rng.random() < HANDLING_SHOCK_PROB:
            event_g.append(float(rng.uniform(*HANDLING_SHOCK_G_RANGE)))
        for g in event_g:
            peak = max(peak, g)
            if g > BRUISE_THRESHOLD_G:
                q -= profile.bruise_coeff * (g - BRUISE_THRESHOLD_G)
        q = max(0.0, q)

        seg_end = segments[ptr]
        lat, lon = seg_end.position(t1)
        amb, amb_h = ambient_conditions(lat, lon, (start_doy + t1 / HOURS_PER_DAY) % DAYS_PER_YEAR,
                                        (start_hour + t1) % HOURS_PER_DAY, rh_bias)
        duty_mean = duty_acc / n_sub
        powered_frac = powered_time / dt_int if dt_int > 0 else 1.0
        k_now = kin.degradation_rate_per_day(pulp, rh)
        rsl = q / kin.k_ref_per_day
        remaining = total_h - t1
        projected = rsl - remaining / HOURS_PER_DAY
        # If the current excursion persists to arrival (e.g., failed compressor), how much is left?
        projected_current = (q - k_now * remaining / HOURS_PER_DAY) / kin.k_ref_per_day
        worst_projection = min(projected, projected_current)

        elapsed[i], lat_a[i], lon_a[i] = t1, lat, lon
        amb_t[i], amb_rh[i], sp_a[i] = amb, amb_h, setpoint
        supply[i] = air - SUPPLY_RETURN_DELTA_K * duty_mean + rng.normal(0.0, 0.15)
        ret[i] = air + rng.normal(0.0, 0.15)
        pulp_a[i] = pulp + rng.normal(0.0, 0.10)
        rh_a[i] = min(100.0, max(0.0, rh + rng.normal(0.0, 1.2)))
        vib[i] = peak
        duty_a[i] = 0.0 if powered_frac < 0.05 else min(1.0, max(0.0, duty_mean + rng.normal(0.0, 0.02)))
        door_a[i], power_a[i], defrost_a[i] = int(door_any), int(powered_frac >= 0.5), int(defrost_any)
        k_a[i], q_a[i], rsl_a[i] = k_now, q, rsl
        h0_a[i] = min(9_999.0, q / k_now * HOURS_PER_DAY)
        rem_a[i], proj_a[i], projc_a[i] = remaining, projected, projected_current
        activity.append(seg_end.activity)
        from_hub.append(seg_end.from_code)
        to_hub.append(seg_end.to_code)
        status.append(classify_status(worst_projection, profile.shelf_life_days_at_setpoint, q).value)

    frame = pd.DataFrame({
        "container_id": spec.container_id,
        "commodity": spec.commodity,
        "timestamp": dep + pd.to_timedelta(elapsed, unit="h"),
        "elapsed_h": elapsed.round(4),
        "lat": lat_a.round(5), "lon": lon_a.round(5),
        "activity": activity, "from_hub": from_hub, "to_hub": to_hub,
        "ambient_temp_c": amb_t.round(2), "ambient_rh_pct": amb_rh.round(1),
        "setpoint_c": sp_a.round(2),
        "supply_air_temp_c": supply.round(2), "return_air_temp_c": ret.round(2),
        "pulp_temp_c": pulp_a.round(2), "relative_humidity_pct": rh_a.round(1),
        "vibration_peak_g": vib.round(3), "door_open": door_a, "power_on": power_a,
        "defrost_active": defrost_a, "compressor_duty_cycle": duty_a.round(3),
        "arrhenius_rate_per_day": k_a.round(6), "quality_index": q_a.round(6),
        "remaining_shelf_life_days": rsl_a.round(4),
        "hours_to_zero_current_conditions": h0_a.round(2),
        "remaining_transit_h": rem_a.round(3),
        "projected_rsl_at_arrival_days": proj_a.round(4),
        "projected_rsl_at_arrival_current_days": projc_a.round(4),
        "status": status,
    })
    total_km = sum(l.distance_km for l in legs)
    summary: dict[str, Any] = {
        "container_id": spec.container_id,
        "commodity": spec.commodity,
        "origin": spec.origin,
        "destination": spec.destination,
        "departure": dep,
        "arrival": dep + pd.to_timedelta(total_h, unit="h"),
        "route": ">".join([legs[0].origin] + [l.destination for l in legs]),
        "modes": ">".join(l.mode.value for l in legs),
        "distance_km": round(total_km, 1),
        "transit_h": round(total_h, 2),
        "payload_kg": profile.payload_kg,
        "cargo_value_usd": round(profile.cargo_value_usd, 2),
        "recommended_setpoint_c": profile.setpoint_c,
        "configured_setpoint_c": round(setpoint, 2),
        "qc_rsl_days_at_load": round(spec.qc_rsl_days_at_load if spec.qc_rsl_days_at_load is not None
                                     else spec.initial_quality / kin.k_ref_per_day, 4),
        "qc_pulp_temp_c_at_load": round(spec.qc_pulp_temp_c_at_load if spec.qc_pulp_temp_c_at_load is not None
                                        else spec.initial_pulp_temp_c, 2),
        # Latent ground truth for evaluation only; never use as model features.
        "true_initial_quality": round(spec.initial_quality, 4),
        "true_initial_pulp_temp_c": round(spec.initial_pulp_temp_c, 2),
        "true_lot_shelf_life_factor": round(spec.lot_shelf_life_factor, 4),
        "true_lot_q10": round(kin.profile.q10, 4),
        "faults": faults.labels(),
        "final_quality": round(q, 4),
        "final_rsl_days": round(q / kin.k_ref_per_day, 3),
        "final_status": status[-1],
        "spoiled_on_arrival": bool(q <= 0.0),
    }
    return frame, summary


# ======================================================================================
# Fleet generation
# ======================================================================================
@dataclass(frozen=True, slots=True)
class SimulationConfig:
    n_containers: int = 400
    seed: int = 42
    sample_interval_minutes: int = 15
    start: pd.Timestamp = field(default_factory=lambda: pd.Timestamp("2025-01-01", tz="UTC"))
    end: pd.Timestamp = field(default_factory=lambda: pd.Timestamp("2025-12-31", tz="UTC"))
    owner_prefixes: tuple[str, ...] = ("SIMU", "SYNU", "CCRU")
    lot_shelf_life_sigma: float = 0.12  # log-sd of lot storage-life factor
    lot_q10_sigma: float = 0.06  # log-sd of lot Q10
    qc_rsl_cv: float = 0.05  # load-out QC error on initial RSL (multiplicative)
    qc_pulp_temp_sd_c: float = 0.3

    def __post_init__(self) -> None:
        if self.n_containers < 1:
            raise ValueError("n_containers must be >= 1")
        if min(self.lot_shelf_life_sigma, self.lot_q10_sigma, self.qc_rsl_cv, self.qc_pulp_temp_sd_c) < 0:
            raise ValueError("Variability parameters must be non-negative")
        if not 1 <= self.sample_interval_minutes <= 60:
            raise ValueError("sample_interval_minutes must be within [1, 60]")
        if self.end <= self.start + pd.Timedelta(days=14):
            raise ValueError("Simulation window must exceed 14 days")
        for p in self.owner_prefixes:
            if len(p) != 4 or not p.isalpha() or not p.isupper() or p[3] != "U":
                raise ValueError(f"Invalid ISO 6346 owner prefix: {p}")


@dataclass(slots=True)
class FleetDataset:
    hubs: pd.DataFrame
    edges: pd.DataFrame
    hub_congestion: pd.DataFrame
    commodities: pd.DataFrame
    shipments: pd.DataFrame
    telemetry: pd.DataFrame
    depot_market: pd.DataFrame
    fleet_snapshot: pd.DataFrame


def _sample_origin(profile: CommodityProfile, month: int, rng: np.random.Generator) -> str:
    active = [code for code, months in profile.origins if not months or month in months]
    pool = active or [code for code, _ in profile.origins]
    return str(pool[int(rng.integers(len(pool)))])


def _sample_destination(network: LogisticsNetwork, commodity: str, origin: str,
                        rng: np.random.Generator, min_km: float = 250.0) -> str:
    o = network.hubs[origin]
    candidates = [h for h in network.primary_buyers(commodity)
                  if haversine_km(o.lat, o.lon, h.lat, h.lon) >= min_km]
    if not candidates:
        raise RuntimeError(f"No destination >= {min_km} km from {origin} for {commodity}")
    w = np.array([h.metro_population_m for h in candidates], dtype=float)
    return candidates[int(rng.choice(len(candidates), p=w / w.sum()))].code


def _sample_initial_quality(origin_type: NodeType, rng: np.random.Generator) -> float:
    """Quality at gate-out. Seaport origins are imports (e.g., Chilean blueberries, Central
    American bananas) that already spent 7-14 days on the ocean; land-port loads are Mexican
    produce trucked 1-3 days to the border; growing-region loads leave straight from pre-cooling."""
    if origin_type is NodeType.SEAPORT:
        return float(rng.uniform(0.55, 0.85))
    if origin_type is NodeType.LAND_PORT:
        return float(rng.uniform(0.75, 0.95))
    return float(rng.uniform(0.90, 1.00))


def _sample_faults(rng: np.random.Generator) -> ReeferFaults:
    setpoint_offset = 0.0
    if rng.random() < 0.06:
        setpoint_offset = -float(rng.uniform(1.5, 3.0)) if rng.random() < 0.25 else float(rng.uniform(2.0, 6.0))
    fault_frac: float | None = None
    residual = 1.0
    if rng.random() < 0.08:
        fault_frac, residual = float(rng.uniform(0.1, 0.8)), float(rng.uniform(0.0, 0.35))
    rh_offset = -float(rng.uniform(10.0, 25.0)) if rng.random() < 0.06 else 0.0
    return ReeferFaults(setpoint_offset, fault_frac, residual, rh_offset, bool(rng.random() < 0.12))


def sample_shipment_specs(config: SimulationConfig, network: LogisticsNetwork,
                          rng: np.random.Generator) -> list[ShipmentSpec]:
    keys = list(COMMODITIES)
    window_s = (config.end - pd.Timedelta(days=10) - config.start).total_seconds()
    specs: list[ShipmentSpec] = []
    for n in range(config.n_containers):
        commodity = keys[int(rng.integers(len(keys)))]
        profile = COMMODITIES[commodity]
        departure = (config.start + pd.Timedelta(seconds=float(rng.uniform(0.0, window_s)))).floor("15min")
        origin = _sample_origin(profile, int(departure.month), rng)
        destination = _sample_destination(network, commodity, origin, rng)
        faults = _sample_faults(rng)
        precool_excess = float(rng.uniform(3.0, 8.0)) if faults.hot_load else float(rng.uniform(0.0, 2.0))
        # Value of time = shelf-life value consumed per hour x shipper urgency (median ~0.4:
        # quality loss only costs money if the load arrives below buyer spec) + equipment cost.
        vot = (profile.cargo_value_usd / profile.shelf_life_days_at_setpoint / HOURS_PER_DAY
               * float(rng.lognormal(-0.9, 0.9)) + 10.0)
        prefix = config.owner_prefixes[n % len(config.owner_prefixes)]
        q0 = _sample_initial_quality(network.hubs[origin].node_type, rng)
        lot_f = float(np.clip(rng.lognormal(0.0, config.lot_shelf_life_sigma), 0.6, 1.5))
        lot_q10 = float(profile.q10 * np.clip(rng.lognormal(0.0, config.lot_q10_sigma), 0.8, 1.25))
        pulp0 = profile.setpoint_c + precool_excess
        true_rsl0 = q0 * profile.shelf_life_days_at_setpoint * lot_f
        specs.append(ShipmentSpec(
            container_id=make_container_id(prefix, 100_000 + n),
            commodity=commodity, origin=origin, destination=destination, departure=departure,
            initial_quality=q0, initial_pulp_temp_c=pulp0,
            value_of_time_usd_per_h=vot, faults=faults,
            lot_shelf_life_factor=lot_f, lot_q10=lot_q10,
            qc_rsl_days_at_load=true_rsl0 * float(rng.lognormal(0.0, config.qc_rsl_cv)),
            qc_pulp_temp_c_at_load=pulp0 + float(rng.normal(0.0, config.qc_pulp_temp_sd_c)),
        ))
    return specs


def generate_depot_market(network: LogisticsNetwork, start: pd.Timestamp, n_days: int,
                          rng: np.random.Generator) -> pd.DataFrame:
    """Daily buyer-side state for the Tower B features: demand, inventory, turnover velocity, deficit."""
    dates = pd.date_range(start.normalize(), periods=n_days, freq="D")
    doy = dates.dayofyear.to_numpy().astype(float)
    frames: list[pd.DataFrame] = []
    for hub in network.buyers():
        assert hub.buyer_type is not None
        econ = BUYER_ECONOMICS[hub.buyer_type]
        for commodity in hub.accepts:
            profile = COMMODITIES[commodity]
            if hub.buyer_type is BuyerType.PROCESSOR:
                base = econ.fixed_capacity_kg_per_day
            else:
                base = hub.metro_population_m * 1e6 * profile.per_capita_kg_per_year / 365.0 * econ.share_of_metro_demand
            seasonal = 1.0 + 0.08 * np.cos(2.0 * math.pi * (doy - 190.0) / DAYS_PER_YEAR)
            demand = base * seasonal * rng.lognormal(0.0, 0.08, n_days)
            x = np.empty(n_days)
            x[0] = rng.normal(0.0, 0.3)
            eps = rng.normal(0.0, 0.3 * math.sqrt(1 - 0.7 ** 2), n_days)
            for d in range(1, n_days):
                x[d] = 0.7 * x[d - 1] + eps[d]
            target = econ.target_days_of_supply * demand
            on_hand = target * np.exp(x)
            frames.append(pd.DataFrame({
                "date": dates, "buyer_code": hub.code, "buyer_name": hub.name,
                "buyer_type": hub.buyer_type.value, "lat": hub.lat, "lon": hub.lon,
                "commodity": commodity,
                "daily_demand_kg": demand.round(1), "on_hand_kg": on_hand.round(1),
                "target_days_of_supply": econ.target_days_of_supply,
                "turnover_velocity_per_day": (demand / on_hand).round(4),
                "inventory_deficit_kg": np.maximum(0.0, target - on_hand).round(1),
                "spot_price_index": (1.0 + 0.25 * np.tanh(-x)).round(4),
                "price_realization": econ.price_realization,
                "min_rsl_fraction": econ.min_rsl_fraction,
                "reference_value_usd_per_kg": profile.unit_value_usd_per_kg,
            }))
    return pd.concat(frames, ignore_index=True)


def commodities_frame() -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for p in COMMODITIES.values():
        kin = KineticModel.from_profile(p)
        rows.append({
            "commodity": p.key, "display_name": p.display_name, "setpoint_c": p.setpoint_c,
            "optimal_rh_pct": p.optimal_rh_pct, "shelf_life_days_at_setpoint": p.shelf_life_days_at_setpoint,
            "q10": p.q10, "activation_energy_kj_per_mol": round(kin.activation_energy_j_per_mol / 1000.0, 3),
            "pre_exponential_per_day": kin.pre_exponential_per_day,
            "highest_freezing_point_c": p.highest_freezing_point_c,
            "chilling_threshold_c": p.chilling_threshold_c if p.chilling_threshold_c is not None else np.nan,
            "unit_value_usd_per_kg": p.unit_value_usd_per_kg, "payload_kg": p.payload_kg,
            "cargo_value_usd": p.cargo_value_usd, "reference": p.reference,
        })
    return pd.DataFrame(rows)


def build_fleet_snapshot(telemetry: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    """Freeze each container at a random point mid-journey to emulate a live fleet for the dashboard."""
    rows: list[pd.Series] = []
    for _, grp in telemetry.groupby("container_id", sort=False):
        cut = float(rng.uniform(0.05, 0.95)) * float(grp["elapsed_h"].iloc[-1])
        idx = int(np.searchsorted(grp["elapsed_h"].to_numpy(), cut, side="right")) - 1
        row = grp.iloc[max(idx, 0)].copy()
        row["snapshot_elapsed_h"] = row["elapsed_h"]
        rows.append(row)
    return pd.DataFrame(rows).reset_index(drop=True)


def validate_dataset(ds: FleetDataset) -> None:
    """Raise AssertionError if physical or label invariants are violated."""
    t = ds.telemetry
    numeric = t.select_dtypes(include=[np.number])
    assert not numeric.isna().any().any(), "NaN in telemetry"
    assert np.isfinite(numeric.to_numpy()).all(), "Non-finite telemetry values"
    assert (t["quality_index"].between(0.0, 1.0)).all(), "Quality index out of [0, 1]"
    assert (t["remaining_shelf_life_days"] >= 0.0).all(), "Negative RSL label"
    assert t["compressor_duty_cycle"].between(0.0, 1.0).all(), "Duty cycle out of [0, 1]"
    assert t["relative_humidity_pct"].between(0.0, 100.0).all(), "RH out of range"
    assert t["return_air_temp_c"].between(-40.0, 60.0).all(), "Air temperature out of physical range"
    q_diff = t.groupby("container_id", sort=False)["quality_index"].diff().dropna()
    assert (q_diff <= 1e-6).all(), "Quality increased over time (kinetics must be irreversible)"
    e_diff = t.groupby("container_id", sort=False)["elapsed_h"].diff().dropna()
    assert (e_diff > 0).all(), "Non-monotonic timestamps"
    assert set(t["status"].unique()) <= {s.value for s in Status}, "Unknown status value"
    assert ds.shipments["container_id"].is_unique, "Duplicate container ids"
    for cid in ds.shipments["container_id"]:
        assert iso6346_check_digit(cid[:10]) == int(cid[10]), f"Bad ISO 6346 check digit: {cid}"


def generate_fleet(config: SimulationConfig) -> FleetDataset:
    root = np.random.SeedSequence(config.seed)
    net_seed, spec_seed, market_seed, snap_seed, ship_seed = root.spawn(5)
    network = LogisticsNetwork()
    n_days = int((config.end.normalize() - config.start.normalize()).days) + 30
    congestion = CongestionModel(network, config.start, n_days, np.random.default_rng(net_seed))
    specs = sample_shipment_specs(config, network, np.random.default_rng(spec_seed))
    ship_rngs = [np.random.default_rng(s) for s in ship_seed.spawn(len(specs))]
    dt_h = config.sample_interval_minutes / 60.0

    frames: list[pd.DataFrame] = []
    summaries: list[dict[str, Any]] = []
    t_start = time.perf_counter()
    for n, (spec, rng) in enumerate(zip(specs, ship_rngs), start=1):
        frame, summary = simulate_shipment(spec, network, congestion, dt_h, rng)
        frames.append(frame)
        summaries.append(summary)
        if n % 100 == 0 or n == len(specs):
            LOGGER.info("Simulated %d/%d containers (%.1fs)", n, len(specs), time.perf_counter() - t_start)

    telemetry = pd.concat(frames, ignore_index=True)
    for col in ("container_id", "commodity", "activity", "from_hub", "to_hub", "status"):
        telemetry[col] = telemetry[col].astype("category")
    dataset = FleetDataset(
        hubs=network.hubs_frame(),
        edges=network.edges_frame(),
        hub_congestion=congestion.to_frame(),
        commodities=commodities_frame(),
        shipments=pd.DataFrame(summaries),
        telemetry=telemetry,
        depot_market=generate_depot_market(network, config.start, n_days, np.random.default_rng(market_seed)),
        fleet_snapshot=pd.DataFrame(),
    )
    dataset.fleet_snapshot = build_fleet_snapshot(telemetry, np.random.default_rng(snap_seed))
    validate_dataset(dataset)
    return dataset


# ======================================================================================
# Persistence
# ======================================================================================
def _parquet_available() -> bool:
    try:
        import pyarrow  # noqa: F401
    except ImportError:
        return False
    return True


def write_dataset(ds: FleetDataset, out_dir: Path) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    use_parquet = _parquet_available()
    if not use_parquet:
        LOGGER.warning("pyarrow not installed; writing CSV (pip install pyarrow for Parquet)")
    written: dict[str, Path] = {}
    for name in ("hubs", "edges", "hub_congestion", "commodities", "shipments",
                 "telemetry", "depot_market", "fleet_snapshot"):
        df: pd.DataFrame = getattr(ds, name)
        if use_parquet:
            path = out_dir / f"{name}.parquet"
            df.to_parquet(path, index=False)
        else:
            path = out_dir / f"{name}.csv"
            df.to_csv(path, index=False)
        written[name] = path
    return written


def load_table(out_dir: Path, name: str) -> pd.DataFrame:
    """Load a table written by write_dataset (Parquet preferred, CSV fallback)."""
    pq, csv = out_dir / f"{name}.parquet", out_dir / f"{name}.csv"
    if pq.exists():
        return pd.read_parquet(pq)
    if csv.exists():
        parse = [c for c in ("timestamp", "date", "departure", "arrival") if c in pd.read_csv(csv, nrows=0).columns]
        return pd.read_csv(csv, parse_dates=parse)
    raise FileNotFoundError(f"No table '{name}' in {out_dir}")


def log_summary(ds: FleetDataset) -> None:
    s, t = ds.shipments, ds.telemetry
    LOGGER.info("Telemetry rows: %s | containers: %d | hubs: %d | edges: %d",
                f"{len(t):,}", len(s), len(ds.hubs), len(ds.edges))
    LOGGER.info("Mode mix (legs): %s",
                s["modes"].str.split(">").explode().value_counts().to_dict())
    LOGGER.info("Final status: %s", s["final_status"].value_counts().to_dict())
    LOGGER.info("Faults: %s", s["faults"].value_counts().to_dict())
    LOGGER.info("Spoiled on arrival: %d | median transit %.1f h | RSL label range [%.2f, %.2f] d",
                int(s["spoiled_on_arrival"].sum()), s["transit_h"].median(),
                t["remaining_shelf_life_days"].min(), t["remaining_shelf_life_days"].max())


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Generate cold-chain reefer telemetry and logistics network data.")
    p.add_argument("--containers", type=int, default=400)
    p.add_argument("--interval-minutes", type=int, default=15)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--start", type=str, default="2025-01-01")
    p.add_argument("--end", type=str, default="2025-12-31")
    p.add_argument("--lot-shelf-life-sigma", type=float, default=0.12)
    p.add_argument("--qc-rsl-cv", type=float, default=0.05, help="Load-out QC error (CV) on initial RSL")
    p.add_argument("--out-dir", type=Path, default=Path("data"))
    p.add_argument("--log-level", type=str, default="INFO")
    return p.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=args.log_level.upper(), format="%(asctime)s %(levelname)s %(name)s | %(message)s")
    config = SimulationConfig(
        n_containers=args.containers, seed=args.seed, sample_interval_minutes=args.interval_minutes,
        start=pd.Timestamp(args.start, tz="UTC"), end=pd.Timestamp(args.end, tz="UTC"),
        lot_shelf_life_sigma=args.lot_shelf_life_sigma, qc_rsl_cv=args.qc_rsl_cv,
    )
    dataset = generate_fleet(config)
    log_summary(dataset)
    for name, path in write_dataset(dataset, args.out_dir).items():
        LOGGER.info("Wrote %-15s -> %s", name, path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
