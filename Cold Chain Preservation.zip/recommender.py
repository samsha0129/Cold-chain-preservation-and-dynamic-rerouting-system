#!/usr/bin/env python3
"""
recommender.py — Phase 3 of the Cold-Chain Preservation & Dynamic Rerouting System.

Ranks diversion destinations for reefer containers before their cargo stops being
sellable, and projects the salvage value of each option.

Architecture: retrieval + economic re-ranking
---------------------------------------------
1. Two-tower retrieval (PyTorch)
   * Tower A (shipment state): cargo type (embedding), predicted remaining shelf life
     (Phase 2), current geolocation (unit-sphere xyz), unit value, payload, current
     holding temperature and its Arrhenius-relative decay rate, and planned ETA.
   * Tower B (receiving hub): buyer identity and channel (embeddings), turnover
     velocity, inventory deficit and demand for *this* commodity, spot price index,
     price realization, minimum-RSL acceptance spec, location, and distance/drive time
     from the container. Because the distance and commodity-specific inventory make
     Tower B query-contextualized, depot embeddings are computed per query (27 buyers:
     trivial cost).
   * Score = learnable scale x cosine(zA, zB). Trained with a listwise soft-label
     cross-entropy against an economic oracle.
2. Economic re-ranking (exact, deterministic)
   The retrieved top-K (planned destination always included) are re-scored with the
   same salvage model the oracle uses, fed with the *predicted* shelf life:
     net value = revenue - incremental freight - PO breach cost - disposal of unsellable volume
   where revenue depends on shelf life at arrival (Arrhenius projection at the current
   holding temperature), buyer acceptance spec, absorbable volume
   (deficit + demand x sell window) and channel price realization. The planned
   destination is modelled as a purchase order: it takes the full load at contract price
   if the load meets spec, and rejects it otherwise.
3. Fleet assignment (SciPy)
   At-risk containers compete for the same inventory deficits. A linear assignment over
   buyer capacity slots (scipy.optimize.linear_sum_assignment) maximizes total fleet
   net value so that five containers are not all sent to one market.

Training data
-------------
Queries are telemetry states still in transit (at-risk states oversampled), each
paired with the buyer market on that day. Labels use the TRUE lot shelf life; model
inputs use the Phase 2 PREDICTED shelf life, which is the information available in
production. Real at-risk states are rare, so counterfactual excursion scenarios
(reefer failure: warmer holding temperature, depleted shelf life) are added. The oracle
is analytic, so these labels are exact. Evaluation reports real and augmented queries
separately, split by container.

Artifacts (in --model-dir): recommender.pt, recommender_meta.json, recommender_eval.csv

Usage
-----
    python recommender.py --data-dir data --model-dir models
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Final, Mapping, Sequence

import numpy as np
import numpy.typing as npt
import pandas as pd
import torch
from scipy.optimize import linear_sum_assignment
from torch import Tensor, nn

from data_engine import COMMODITIES, EARTH_RADIUS_KM, HOURS_PER_DAY, BuyerType, load_table
from spoilage_model import SpoilagePredictor, kinetic_rate_per_day

LOGGER: Final[logging.Logger] = logging.getLogger("coldchain.recommender")

MODEL_VERSION: Final[str] = "3.0.0"
COMMODITY_KEYS: Final[tuple[str, ...]] = tuple(COMMODITIES)
BUYER_TYPES: Final[tuple[str, ...]] = tuple(bt.value for bt in BuyerType)
FRESH_CHANNELS: Final[frozenset[str]] = frozenset({BuyerType.TERMINAL_MARKET.value, BuyerType.RETAIL_DC.value})
MASK_VALUE: Final[float] = -1e9

FloatArray = npt.NDArray[np.float64]
IntArray = npt.NDArray[np.int64]
BoolArray = npt.NDArray[np.bool_]


# ======================================================================================
# Diversion economics
# ======================================================================================
@dataclass(frozen=True, slots=True)
class DiversionEconomics:
    truck_circuity: float = 1.20
    truck_speed_kmh: float = 62.0
    dispatch_overhead_h: float = 2.0  # reconsignment, re-dispatch and receiving appointment
    truck_cost_usd_per_km: float = 1.45
    reconsignment_fee_usd: float = 350.0
    disposal_cost_usd_per_kg: float = 0.05  # landfill/compost tipping (~$50/t)
    sell_window_days: float = 2.0  # demand the buyer can absorb beyond its deficit
    fresh_price_floor: float = 0.60  # price multiplier for fresh channels at the acceptance edge
    fresh_full_price_fraction: float = 0.60  # RSL fraction at which fresh channels pay full price
    divert_min_gain_usd: float = 500.0  # do not recommend a diversion for less incremental value
    distressed_sale_discount: float = 0.85  # spot buyers discount an unplanned, time-pressured load
    contract_breach_fraction: float = 0.15  # cost of abandoning a PO the load could still fulfil


def _to_day(values: pd.Series | pd.DatetimeIndex) -> npt.NDArray[np.datetime64]:
    ts = pd.to_datetime(values, utc=True)
    idx = pd.DatetimeIndex(ts).tz_convert(None).normalize()
    return idx.to_numpy(dtype="datetime64[D]")


def unit_sphere(lat: FloatArray, lon: FloatArray) -> FloatArray:
    la, lo = np.radians(lat), np.radians(lon)
    return np.stack([np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)], axis=-1)


def haversine_matrix(lat1: FloatArray, lon1: FloatArray, lat2: FloatArray, lon2: FloatArray) -> FloatArray:
    """Great-circle km between each query (rows) and each buyer (columns)."""
    p1, p2 = np.radians(lat1)[:, None], np.radians(lat2)[None, :]
    dphi = p2 - p1
    dl = np.radians(lon2)[None, :] - np.radians(lon1)[:, None]
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 2.0 * EARTH_RADIUS_KM * np.arcsin(np.sqrt(np.clip(a, 0.0, 1.0)))


class MarketCube:
    """Dense [day, buyer, commodity] view of the buyer market panel from Phase 1."""

    def __init__(self, depot_market: pd.DataFrame, hubs: pd.DataFrame) -> None:
        buyers = hubs[hubs["node_type"] == "buyer"].sort_values("hub_code").reset_index(drop=True)
        if buyers.empty:
            raise ValueError("Hub table has no buyer nodes")
        self.buyer_codes: list[str] = buyers["hub_code"].astype(str).tolist()
        self.buyer_names: list[str] = buyers["name"].astype(str).tolist()
        self.buyer_type: list[str] = buyers["buyer_type"].astype(str).tolist()
        self.buyer_type_idx: IntArray = np.array([BUYER_TYPES.index(t) for t in self.buyer_type], dtype=np.int64)
        self.lat = buyers["lat"].to_numpy(np.float64)
        self.lon = buyers["lon"].to_numpy(np.float64)
        self.index = {c: i for i, c in enumerate(self.buyer_codes)}
        self.fresh: BoolArray = np.array([t in FRESH_CHANNELS for t in self.buyer_type])

        m = depot_market.copy()
        m["day"] = _to_day(m["date"])
        self.days = np.array(sorted(m["day"].unique()), dtype="datetime64[D]")
        d_idx = np.searchsorted(self.days, m["day"].to_numpy(dtype="datetime64[D]"))
        b_idx = m["buyer_code"].astype(str).map(self.index).to_numpy()
        c_idx = m["commodity"].astype(str).map({k: i for i, k in enumerate(COMMODITY_KEYS)}).to_numpy()
        if np.isnan(b_idx.astype(float)).any() or np.isnan(c_idx.astype(float)).any():
            raise ValueError("Market panel references unknown buyers or commodities")
        b_idx, c_idx = b_idx.astype(np.int64), c_idx.astype(np.int64)
        shape = (len(self.days), len(self.buyer_codes), len(COMMODITY_KEYS))
        self.deficit_kg = np.zeros(shape)
        self.demand_kg = np.zeros(shape)
        self.turnover = np.zeros(shape)
        self.spot = np.ones(shape)
        self.accepts: BoolArray = np.zeros(shape[1:], dtype=bool)
        self.deficit_kg[d_idx, b_idx, c_idx] = m["inventory_deficit_kg"].to_numpy(np.float64)
        self.demand_kg[d_idx, b_idx, c_idx] = m["daily_demand_kg"].to_numpy(np.float64)
        self.turnover[d_idx, b_idx, c_idx] = m["turnover_velocity_per_day"].to_numpy(np.float64)
        self.spot[d_idx, b_idx, c_idx] = m["spot_price_index"].to_numpy(np.float64)
        self.accepts[b_idx, c_idx] = True
        per_buyer = m.groupby("buyer_code")[["price_realization", "min_rsl_fraction"]].first()
        self.price_realization = per_buyer.reindex(self.buyer_codes)["price_realization"].fillna(0.0).to_numpy(np.float64)
        self.min_rsl_fraction = per_buyer.reindex(self.buyer_codes)["min_rsl_fraction"].fillna(1.0).to_numpy(np.float64)

    @property
    def n_buyers(self) -> int:
        return len(self.buyer_codes)

    def day_index(self, days: npt.NDArray[np.datetime64]) -> IntArray:
        idx = np.searchsorted(self.days, days.astype("datetime64[D]"))
        return np.clip(idx, 0, len(self.days) - 1).astype(np.int64)


@dataclass(slots=True)
class QueryBatch:
    """Container states to score. One row per query."""

    commodity_idx: IntArray
    lat: FloatArray
    lon: FloatArray
    rsl_days: FloatArray  # shelf life used for decisions (predicted in production, true for oracle)
    holding_temp_c: FloatArray
    payload_kg: FloatArray
    value_per_kg: FloatArray
    remaining_transit_h: FloatArray
    planned_idx: IntArray  # buyer index of the planned destination (-1 if not a buyer)
    day_idx: IntArray

    def __len__(self) -> int:
        return int(self.commodity_idx.shape[0])

    def with_rsl(self, rsl_days: FloatArray) -> QueryBatch:
        return QueryBatch(self.commodity_idx, self.lat, self.lon, rsl_days, self.holding_temp_c, self.payload_kg,
                          self.value_per_kg, self.remaining_transit_h, self.planned_idx, self.day_idx)

    def subset(self, mask: BoolArray | IntArray) -> QueryBatch:
        return QueryBatch(*(getattr(self, f)[mask] for f in (
            "commodity_idx", "lat", "lon", "rsl_days", "holding_temp_c", "payload_kg", "value_per_kg",
            "remaining_transit_h", "planned_idx", "day_idx")))


def relative_decay_rate(q: QueryBatch) -> FloatArray:
    """Arrhenius rate at the holding temperature relative to the setpoint rate (1.0 = nominal)."""
    names = np.array(COMMODITY_KEYS, dtype=object)[q.commodity_idx]
    opt_rh = np.array([COMMODITIES[k].optimal_rh_pct for k in COMMODITY_KEYS])[q.commodity_idx]
    sl = np.array([COMMODITIES[k].shelf_life_days_at_setpoint for k in COMMODITY_KEYS])[q.commodity_idx]
    return kinetic_rate_per_day(names, q.holding_temp_c.astype(np.float64), opt_rh) * sl


@dataclass(slots=True)
class CandidateEconomics:
    distance_km: FloatArray
    travel_h: FloatArray
    rsl_at_arrival_days: FloatArray
    accepts: BoolArray
    feasible: BoolArray
    sellable_kg: FloatArray
    revenue_usd: FloatArray
    incremental_freight_usd: FloatArray
    contract_breach_usd: FloatArray
    disposal_usd: FloatArray
    net_value_usd: FloatArray
    is_planned: BoolArray


def evaluate_candidates(q: QueryBatch, cube: MarketCube, econ: DiversionEconomics) -> CandidateEconomics:
    """Exact salvage economics for every (query, buyer) pair. Arrays are [Q, B]."""
    n_q, n_b = len(q), cube.n_buyers
    dist = haversine_matrix(q.lat, q.lon, cube.lat, cube.lon) * econ.truck_circuity
    travel = dist / econ.truck_speed_kmh + econ.dispatch_overhead_h
    is_planned = np.zeros((n_q, n_b), dtype=bool)
    has_plan = q.planned_idx >= 0
    rows = np.nonzero(has_plan)[0]
    is_planned[rows, q.planned_idx[has_plan]] = True
    travel = np.where(is_planned, q.remaining_transit_h[:, None], travel)  # planned leg keeps its ETA

    rel = relative_decay_rate(q)
    rsl_arr = np.maximum(0.0, q.rsl_days[:, None] - rel[:, None] * travel / HOURS_PER_DAY)
    sl = np.array([COMMODITIES[k].shelf_life_days_at_setpoint for k in COMMODITY_KEYS])[q.commodity_idx][:, None]
    frac = rsl_arr / sl
    accepts = cube.accepts[:, q.commodity_idx].T  # [Q, B]
    feasible = accepts & (rsl_arr > 0.0) & (frac >= cube.min_rsl_fraction[None, :])

    d, c = q.day_idx, q.commodity_idx
    deficit = cube.deficit_kg[d, :, c]
    demand = cube.demand_kg[d, :, c]
    spot = cube.spot[d, :, c]
    absorb = deficit + demand * np.minimum(econ.sell_window_days, rsl_arr)
    sellable = np.where(feasible, np.minimum(q.payload_kg[:, None], absorb), 0.0)
    fresh_mult = econ.fresh_price_floor + (1.0 - econ.fresh_price_floor) * np.clip(
        frac / econ.fresh_full_price_fraction, 0.0, 1.0)
    freshness = np.where(cube.fresh[None, :], fresh_mult, 1.0)
    price = (q.value_per_kg[:, None] * cube.price_realization[None, :] * spot * freshness
             * econ.distressed_sale_discount)
    # The planned destination holds a purchase order: full load at contract price if within spec.
    contract_price = q.value_per_kg[:, None] * cube.price_realization[None, :]
    sellable = np.where(is_planned, np.where(feasible, q.payload_kg[:, None], 0.0), sellable)
    price = np.where(is_planned, contract_price, price)
    revenue = sellable * price

    freight = dist * econ.truck_cost_usd_per_km
    planned_freight = np.where(has_plan, freight[np.arange(n_q), np.maximum(q.planned_idx, 0)], 0.0)
    incremental = np.maximum(0.0, freight - planned_freight[:, None]) + econ.reconsignment_fee_usd
    incremental = np.where(is_planned, 0.0, incremental)
    # Walking away from a PO the load can still fulfil costs the relationship (and often a penalty).
    plan_col = np.maximum(q.planned_idx, 0)
    plan_ok = has_plan & feasible[np.arange(n_q), plan_col]
    plan_revenue = np.where(plan_ok, revenue[np.arange(n_q), plan_col], 0.0)
    breach = np.where(is_planned, 0.0, econ.contract_breach_fraction * plan_revenue[:, None])
    disposal = (q.payload_kg[:, None] - sellable) * econ.disposal_cost_usd_per_kg
    net = revenue - incremental - breach - disposal
    return CandidateEconomics(dist, travel, rsl_arr, accepts, feasible, sellable, revenue, incremental,
                              breach, disposal, net, is_planned)


# ======================================================================================
# Features and model
# ======================================================================================
QUERY_FEATURES: Final[tuple[str, ...]] = (
    "rsl_fraction", "log_rsl_days", "log_rel_decay_rate", "log_hours_to_zero", "loc_x", "loc_y", "loc_z",
    "log_value_per_kg", "log_payload_t", "log_remaining_transit_h", "holding_temp_dev_c",
)
CANDIDATE_FEATURES: Final[tuple[str, ...]] = (
    "accepts", "log_deficit_t", "log_demand_t", "turnover_velocity", "spot_price_index", "price_realization",
    "min_rsl_fraction", "log_distance_km", "travel_days", "loc_x", "loc_y", "loc_z", "is_planned",
    "log_deficit_to_payload",
)


def query_features(q: QueryBatch) -> FloatArray:
    sl = np.array([COMMODITIES[k].shelf_life_days_at_setpoint for k in COMMODITY_KEYS])[q.commodity_idx]
    sp = np.array([COMMODITIES[k].setpoint_c for k in COMMODITY_KEYS])[q.commodity_idx]
    rel = np.maximum(relative_decay_rate(q), 1e-3)
    rsl = np.maximum(q.rsl_days, 0.0)
    xyz = unit_sphere(q.lat, q.lon)
    return np.column_stack([
        rsl / sl, np.log1p(rsl), np.log(rel), np.log1p(rsl / rel * HOURS_PER_DAY), xyz,
        np.log(q.value_per_kg), np.log(q.payload_kg / 1000.0), np.log1p(np.maximum(q.remaining_transit_h, 0.0)),
        q.holding_temp_c - sp,
    ]).astype(np.float64)


def candidate_features(q: QueryBatch, cube: MarketCube, ce: CandidateEconomics) -> FloatArray:
    d, c = q.day_idx, q.commodity_idx
    n_q, n_b = len(q), cube.n_buyers
    deficit = cube.deficit_kg[d, :, c]
    xyz = np.broadcast_to(unit_sphere(cube.lat, cube.lon)[None, :, :], (n_q, n_b, 3))
    cols = [
        ce.accepts.astype(np.float64), np.log1p(deficit / 1000.0), np.log1p(cube.demand_kg[d, :, c] / 1000.0),
        cube.turnover[d, :, c], cube.spot[d, :, c],
        np.broadcast_to(cube.price_realization[None, :], (n_q, n_b)),
        np.broadcast_to(cube.min_rsl_fraction[None, :], (n_q, n_b)),
        np.log1p(ce.distance_km), ce.travel_h / HOURS_PER_DAY,
        xyz[..., 0], xyz[..., 1], xyz[..., 2], ce.is_planned.astype(np.float64),
        np.log1p(deficit / q.payload_kg[:, None]),
    ]
    return np.stack(cols, axis=-1).astype(np.float64)


@dataclass(slots=True)
class Standardizer:
    mean: FloatArray
    std: FloatArray

    @classmethod
    def fit(cls, x: FloatArray) -> Standardizer:
        flat = x.reshape(-1, x.shape[-1])
        return cls(flat.mean(axis=0), np.maximum(flat.std(axis=0), 1e-6))

    def transform(self, x: FloatArray) -> FloatArray:
        return (x - self.mean) / self.std

    def to_dict(self) -> dict[str, list[float]]:
        return {"mean": self.mean.tolist(), "std": self.std.tolist()}

    @classmethod
    def from_dict(cls, d: Mapping[str, Sequence[float]]) -> Standardizer:
        return cls(np.asarray(d["mean"], dtype=np.float64), np.asarray(d["std"], dtype=np.float64))


def _mlp(d_in: int, hidden: int, d_out: int, dropout: float) -> nn.Sequential:
    return nn.Sequential(
        nn.Linear(d_in, hidden), nn.LayerNorm(hidden), nn.GELU(), nn.Dropout(dropout),
        nn.Linear(hidden, hidden // 2), nn.GELU(), nn.Linear(hidden // 2, d_out),
    )


class TwoTowerRecommender(nn.Module):
    """Shipment tower x receiving-hub tower, scored by scaled cosine similarity."""

    def __init__(self, n_commodities: int, n_buyers: int, n_buyer_types: int, d_query: int, d_candidate: int,
                 embed_dim: int = 32, hidden: int = 128, dropout: float = 0.1) -> None:
        super().__init__()
        self.commodity_emb = nn.Embedding(n_commodities, 8)
        self.buyer_emb = nn.Embedding(n_buyers, 8)
        self.buyer_type_emb = nn.Embedding(n_buyer_types, 4)
        self.tower_a = _mlp(d_query + 8, hidden, embed_dim, dropout)
        self.tower_b = _mlp(d_candidate + 8 + 4 + 8, hidden, embed_dim, dropout)
        self.logit_scale = nn.Parameter(torch.tensor(math.log(10.0)))

    def encode_shipment(self, commodity_idx: Tensor, xq: Tensor) -> Tensor:
        z = self.tower_a(torch.cat([xq, self.commodity_emb(commodity_idx)], dim=-1))
        return nn.functional.normalize(z, dim=-1)

    def encode_hubs(self, commodity_idx: Tensor, buyer_idx: Tensor, buyer_type_idx: Tensor, xc: Tensor) -> Tensor:
        n_q, n_b, _ = xc.shape
        ctx = self.commodity_emb(commodity_idx)[:, None, :].expand(n_q, n_b, -1)  # cargo context for hub tower
        z = self.tower_b(torch.cat([xc, self.buyer_emb(buyer_idx).expand(n_q, -1, -1),
                                    self.buyer_type_emb(buyer_type_idx).expand(n_q, -1, -1), ctx], dim=-1))
        return nn.functional.normalize(z, dim=-1)

    def forward(self, commodity_idx: Tensor, xq: Tensor, buyer_idx: Tensor, buyer_type_idx: Tensor,
                xc: Tensor) -> Tensor:
        za = self.encode_shipment(commodity_idx, xq)
        zb = self.encode_hubs(commodity_idx, buyer_idx, buyer_type_idx, xc)
        scale = self.logit_scale.clamp(max=math.log(100.0)).exp()
        return scale * torch.einsum("qe,qbe->qb", za, zb)


def soft_targets(net_value: FloatArray, accepts: BoolArray, cargo_value: FloatArray, temperature: float) -> FloatArray:
    """Listwise target distribution: softmax of net value (as fraction of cargo value) over accepting buyers."""
    z = net_value / (temperature * cargo_value[:, None])
    z = np.where(accepts, z, -np.inf)
    z = z - z.max(axis=1, keepdims=True)
    e = np.where(accepts, np.exp(z), 0.0)
    return e / e.sum(axis=1, keepdims=True)


# ======================================================================================
# Training data
# ======================================================================================
@dataclass(frozen=True, slots=True)
class RecommenderConfig:
    seed: int = 42
    max_real_queries: int = 30_000
    augment_fraction: float = 0.4
    at_risk_oversample: float = 6.0
    val_fraction: float = 0.15
    test_fraction: float = 0.15
    epochs: int = 40
    batch_size: int = 512
    learning_rate: float = 2e-3
    weight_decay: float = 1e-5
    target_temperature: float = 0.02
    patience: int = 6
    embed_dim: int = 32
    hidden: int = 128
    retrieve_k: int = 5


@dataclass(slots=True)
class QueryDataset:
    true_q: QueryBatch
    pred_q: QueryBatch
    container_id: npt.NDArray[np.object_]
    augmented: BoolArray
    status: npt.NDArray[np.object_]


def build_query_dataset(telemetry: pd.DataFrame, shipments: pd.DataFrame, rsl_pred: FloatArray,
                        cube: MarketCube, cfg: RecommenderConfig) -> QueryDataset:
    rng = np.random.default_rng(cfg.seed)
    t = telemetry.reset_index(drop=True)
    in_transit = (t["remaining_transit_h"].to_numpy(np.float64) > 1.0)
    at_risk = t["status"].astype(str).isin(["amber", "red"]).to_numpy()
    w = np.where(in_transit, np.where(at_risk, cfg.at_risk_oversample, 1.0), 0.0)
    n_real = int(min(cfg.max_real_queries, in_transit.sum()))
    idx = rng.choice(len(t), size=n_real, replace=False, p=w / w.sum())
    rows = t.iloc[idx].reset_index(drop=True)
    ship = shipments.set_index(shipments["container_id"].astype(str))
    cid = rows["container_id"].astype(str).to_numpy(dtype=object)
    dest = ship.loc[cid, "destination"].astype(str).to_numpy()
    payload = ship.loc[cid, "payload_kg"].to_numpy(np.float64)
    commodity_idx = rows["commodity"].astype(str).map({k: i for i, k in enumerate(COMMODITY_KEYS)}).to_numpy(np.int64)
    value = np.array([COMMODITIES[k].unit_value_usd_per_kg for k in COMMODITY_KEYS])[commodity_idx]
    base = dict(
        commodity_idx=commodity_idx, lat=rows["lat"].to_numpy(np.float64), lon=rows["lon"].to_numpy(np.float64),
        holding_temp_c=rows["pulp_temp_c"].to_numpy(np.float64), payload_kg=payload, value_per_kg=value,
        remaining_transit_h=rows["remaining_transit_h"].to_numpy(np.float64),
        planned_idx=np.array([cube.index.get(d, -1) for d in dest], dtype=np.int64),
        day_idx=cube.day_index(_to_day(rows["timestamp"])),
    )
    true_rsl = rows["remaining_shelf_life_days"].to_numpy(np.float64)
    pred_rsl = rsl_pred[idx]
    augmented = np.zeros(n_real, dtype=bool)

    # Counterfactual excursions: reefer failure -> warmer holding temperature and depleted shelf life.
    n_aug = int(round(n_real * cfg.augment_fraction / (1.0 - cfg.augment_fraction)))
    if n_aug > 0:
        a = rng.integers(0, n_real, n_aug)
        sp = np.array([COMMODITIES[k].setpoint_c for k in COMMODITY_KEYS])[commodity_idx[a]]
        scale = rng.uniform(0.15, 0.9, n_aug)
        base = {k: np.concatenate([v, v[a]]) for k, v in base.items()}
        base["holding_temp_c"][n_real:] = sp + rng.uniform(2.0, 14.0, n_aug)
        true_rsl = np.concatenate([true_rsl, true_rsl[a] * scale])
        pred_rsl = np.concatenate([pred_rsl, pred_rsl[a] * scale])
        cid = np.concatenate([cid, cid[a]])
        augmented = np.concatenate([augmented, np.ones(n_aug, dtype=bool)])
        status = np.concatenate([rows["status"].astype(str).to_numpy(dtype=object), np.full(n_aug, "augmented", dtype=object)])
    else:
        status = rows["status"].astype(str).to_numpy(dtype=object)
    true_q = QueryBatch(rsl_days=true_rsl, **base)
    return QueryDataset(true_q, true_q.with_rsl(pred_rsl), cid, augmented, status)


def split_by_container(container_id: npt.NDArray[np.object_], cfg: RecommenderConfig) -> tuple[BoolArray, BoolArray, BoolArray]:
    uniq = np.array(sorted(set(container_id.tolist())), dtype=object)
    rng = np.random.default_rng(cfg.seed + 1)
    rng.shuffle(uniq)
    n_test = max(1, int(round(len(uniq) * cfg.test_fraction)))
    n_val = max(1, int(round(len(uniq) * cfg.val_fraction)))
    test = np.isin(container_id, uniq[:n_test])
    val = np.isin(container_id, uniq[n_test:n_test + n_val])
    return ~(test | val), val, test


@dataclass(slots=True)
class TensorPack:
    commodity_idx: Tensor
    xq: Tensor
    xc: Tensor
    accepts: Tensor
    target: Tensor

    def slice(self, sel: Tensor) -> TensorPack:
        return TensorPack(self.commodity_idx[sel], self.xq[sel], self.xc[sel], self.accepts[sel], self.target[sel])


# ======================================================================================
# Trained artifact and inference
# ======================================================================================
class DiversionRecommender:
    """Two-tower retrieval + exact economic re-ranking + fleet assignment."""

    def __init__(self, model: TwoTowerRecommender, cube: MarketCube, q_scaler: Standardizer,
                 c_scaler: Standardizer, econ: DiversionEconomics, retrieve_k: int) -> None:
        self.model = model.eval()
        self.cube = cube
        self.q_scaler = q_scaler
        self.c_scaler = c_scaler
        self.econ = econ
        self.retrieve_k = retrieve_k
        self._buyer_idx = torch.arange(cube.n_buyers)[None, :]
        self._buyer_type_idx = torch.as_tensor(cube.buyer_type_idx)[None, :]

    @torch.no_grad()
    def scores(self, q: QueryBatch) -> tuple[FloatArray, CandidateEconomics]:
        ce = evaluate_candidates(q, self.cube, self.econ)
        xq = torch.as_tensor(self.q_scaler.transform(query_features(q)), dtype=torch.float32)
        xc = torch.as_tensor(self.c_scaler.transform(candidate_features(q, self.cube, ce)), dtype=torch.float32)
        s = self.model(torch.tensor(q.commodity_idx), xq, self._buyer_idx, self._buyer_type_idx, xc).numpy()
        return np.where(ce.accepts, s.astype(np.float64), MASK_VALUE), ce

    def select(self, q: QueryBatch) -> tuple[IntArray, FloatArray, CandidateEconomics]:
        """Retrieve top-K by two-tower score (+ planned destination), re-rank by exact net value."""
        s, ce = self.scores(q)
        k = min(self.retrieve_k, self.cube.n_buyers)
        top = np.argsort(-s, axis=1)[:, :k]
        shortlist = np.zeros_like(s, dtype=bool)
        np.put_along_axis(shortlist, top, True, axis=1)
        shortlist |= ce.is_planned
        shortlist &= ce.accepts
        net = np.where(shortlist, ce.net_value_usd, -np.inf)
        choice = np.argmax(net, axis=1)
        # Keep the plan unless diversion gains at least divert_min_gain_usd.
        has_plan = q.planned_idx >= 0
        plan_net = np.where(has_plan, ce.net_value_usd[np.arange(len(q)), np.maximum(q.planned_idx, 0)], -np.inf)
        best_net = net[np.arange(len(q)), choice]
        keep = has_plan & (best_net - plan_net < self.econ.divert_min_gain_usd)
        choice = np.where(keep, q.planned_idx, choice)
        return choice.astype(np.int64), s, ce

    def recommend(self, q: QueryBatch, top_k: int = 5) -> list[pd.DataFrame]:
        """Per-query ranked options with projected salvage economics (Phase 4 container view)."""
        choice, s, ce = self.select(q)
        out: list[pd.DataFrame] = []
        for i in range(len(q)):
            cand = np.argsort(-s[i])[: max(top_k, self.retrieve_k)]
            if q.planned_idx[i] >= 0 and q.planned_idx[i] not in cand:
                cand = np.append(cand, q.planned_idx[i])
            cand = cand[ce.accepts[i, cand]]
            df = pd.DataFrame({
                "buyer_code": [self.cube.buyer_codes[j] for j in cand],
                "buyer_name": [self.cube.buyer_names[j] for j in cand],
                "buyer_type": [self.cube.buyer_type[j] for j in cand],
                "lat": self.cube.lat[cand], "lon": self.cube.lon[cand],
                "two_tower_score": s[i, cand],
                "distance_km": ce.distance_km[i, cand].round(1), "travel_h": ce.travel_h[i, cand].round(2),
                "projected_rsl_at_arrival_days": ce.rsl_at_arrival_days[i, cand].round(3),
                "feasible": ce.feasible[i, cand], "sellable_kg": ce.sellable_kg[i, cand].round(0),
                "projected_revenue_usd": ce.revenue_usd[i, cand].round(2),
                "incremental_freight_usd": ce.incremental_freight_usd[i, cand].round(2),
                "contract_breach_usd": ce.contract_breach_usd[i, cand].round(2),
                "disposal_cost_usd": ce.disposal_usd[i, cand].round(2),
                "net_salvage_value_usd": ce.net_value_usd[i, cand].round(2),
                "is_planned_destination": ce.is_planned[i, cand],
                "recommended": cand == choice[i],
            }).sort_values("net_salvage_value_usd", ascending=False).head(top_k + 1).reset_index(drop=True)
            df.insert(0, "rank", np.arange(1, len(df) + 1))
            out.append(df)
        return out

    def assign_fleet(self, q: QueryBatch, container_ids: Sequence[str], max_slots_per_buyer: int = 3) -> pd.DataFrame:
        """Jointly assign containers to buyers so shared deficits are not oversubscribed (SciPy LAP)."""
        _, s, ce = self.select(q)
        n_q, n_b = len(q), self.cube.n_buyers
        deficit = self.cube.deficit_kg[q.day_idx, :, q.commodity_idx]  # [Q, B], commodity specific
        slots: list[int] = []
        for j in range(n_b):
            max_def = float(deficit[:, j].max()) if n_q else 0.0
            payload = float(np.median(q.payload_kg)) if n_q else 1.0
            slots += [j] * int(np.clip(math.ceil(max_def / max(payload, 1.0)), 1, max_slots_per_buyer))
        slot_buyer = np.array(slots, dtype=np.int64)
        # Each container also has a private "stay on plan" slot so it is never forced elsewhere.
        value = np.full((n_q, len(slot_buyer) + n_q), -1e12)
        value[:, : len(slot_buyer)] = np.where(ce.accepts[:, slot_buyer] & ~ce.is_planned[:, slot_buyer],
                                               ce.net_value_usd[:, slot_buyer], -1e12)
        plan_net = np.where(q.planned_idx >= 0,
                            ce.net_value_usd[np.arange(n_q), np.maximum(q.planned_idx, 0)], -1e12)
        value[np.arange(n_q), len(slot_buyer) + np.arange(n_q)] = plan_net + self.econ.divert_min_gain_usd
        rows, cols = linear_sum_assignment(-value)
        records = []
        for r, c in zip(rows, cols):
            on_plan = c >= len(slot_buyer)
            j = int(q.planned_idx[r]) if on_plan else int(slot_buyer[c])
            records.append({
                "container_id": container_ids[r], "action": "continue" if on_plan else "divert",
                "buyer_code": self.cube.buyer_codes[j] if j >= 0 else "",
                "net_salvage_value_usd": round(float(ce.net_value_usd[r, j]) if j >= 0 else float("nan"), 2),
                "plan_net_value_usd": round(float(plan_net[r]), 2),
                "projected_rsl_at_arrival_days": round(float(ce.rsl_at_arrival_days[r, j]) if j >= 0 else 0.0, 3),
            })
        return pd.DataFrame(records)

    def save(self, model_dir: Path, meta: dict[str, Any]) -> None:
        model_dir.mkdir(parents=True, exist_ok=True)
        torch.save(self.model.state_dict(), model_dir / "recommender.pt")
        meta = {**meta, "q_scaler": self.q_scaler.to_dict(), "c_scaler": self.c_scaler.to_dict(),
                "economics": asdict(self.econ), "retrieve_k": self.retrieve_k,
                "buyer_codes": self.cube.buyer_codes, "commodities": list(COMMODITY_KEYS),
                "buyer_types": list(BUYER_TYPES), "query_features": list(QUERY_FEATURES),
                "candidate_features": list(CANDIDATE_FEATURES)}
        (model_dir / "recommender_meta.json").write_text(json.dumps(meta, indent=2, default=str))

    @classmethod
    def load(cls, model_dir: Path, depot_market: pd.DataFrame, hubs: pd.DataFrame) -> DiversionRecommender:
        meta = json.loads((model_dir / "recommender_meta.json").read_text())
        cube = MarketCube(depot_market, hubs)
        if cube.buyer_codes != meta["buyer_codes"]:
            raise ValueError("Buyer set differs from the one the recommender was trained on; retrain Phase 3")
        model = TwoTowerRecommender(len(COMMODITY_KEYS), cube.n_buyers, len(BUYER_TYPES), len(QUERY_FEATURES),
                                    len(CANDIDATE_FEATURES), int(meta["model"]["embed_dim"]), int(meta["model"]["hidden"]))
        model.load_state_dict(torch.load(model_dir / "recommender.pt", weights_only=True))
        return cls(model, cube, Standardizer.from_dict(meta["q_scaler"]), Standardizer.from_dict(meta["c_scaler"]),
                   DiversionEconomics(**meta["economics"]), int(meta["retrieve_k"]))


def query_batch_from_states(states: pd.DataFrame, shipments: pd.DataFrame, cube: MarketCube,
                            rsl_column: str = "predicted_rsl_days") -> QueryBatch:
    """Build a QueryBatch from latest container states (one row per container).

    `states` needs container_id, commodity, lat, lon, timestamp, pulp_temp_c (or virtual pulp),
    remaining_transit_h and the RSL column.
    """
    ship = shipments.set_index(shipments["container_id"].astype(str))
    cid: list[str] = states["container_id"].astype(str).tolist()
    commodity_idx: IntArray = np.asarray(
        states["commodity"].astype(str).map({k: i for i, k in enumerate(COMMODITY_KEYS)}).to_numpy(), dtype=np.int64)
    return QueryBatch(
        commodity_idx=commodity_idx, lat=states["lat"].to_numpy(np.float64), lon=states["lon"].to_numpy(np.float64),
        rsl_days=states[rsl_column].to_numpy(np.float64), holding_temp_c=states["pulp_temp_c"].to_numpy(np.float64),
        payload_kg=ship.loc[cid, "payload_kg"].to_numpy(np.float64),
        value_per_kg=np.array([COMMODITIES[k].unit_value_usd_per_kg for k in COMMODITY_KEYS])[commodity_idx],
        remaining_transit_h=states["remaining_transit_h"].to_numpy(np.float64),
        planned_idx=np.array([cube.index.get(d, -1) for d in ship.loc[cid, "destination"].astype(str)], dtype=np.int64),
        day_idx=cube.day_index(_to_day(states["timestamp"])),
    )


# ======================================================================================
# Training and evaluation
# ======================================================================================
def make_tensors(q_true: QueryBatch, q_pred: QueryBatch, cube: MarketCube, econ: DiversionEconomics,
                 q_scaler: Standardizer | None, c_scaler: Standardizer | None, temperature: float
                 ) -> tuple[TensorPack, Standardizer, Standardizer]:
    ce_pred = evaluate_candidates(q_pred, cube, econ)  # features from observable (predicted) state
    ce_true = evaluate_candidates(q_true, cube, econ)  # labels from true shelf life
    xq_raw, xc_raw = query_features(q_pred), candidate_features(q_pred, cube, ce_pred)
    q_scaler = q_scaler or Standardizer.fit(xq_raw)
    c_scaler = c_scaler or Standardizer.fit(xc_raw)
    cargo_value = q_true.payload_kg * q_true.value_per_kg
    target = soft_targets(ce_true.net_value_usd, ce_true.accepts, cargo_value, temperature)
    pack = TensorPack(
        torch.tensor(q_pred.commodity_idx), torch.as_tensor(q_scaler.transform(xq_raw), dtype=torch.float32),
        torch.as_tensor(c_scaler.transform(xc_raw), dtype=torch.float32), torch.tensor(ce_pred.accepts),
        torch.as_tensor(target, dtype=torch.float32),
    )
    return pack, q_scaler, c_scaler


def listwise_loss(logits: Tensor, accepts: Tensor, target: Tensor) -> Tensor:
    logp = torch.log_softmax(logits.masked_fill(~accepts, MASK_VALUE), dim=1)
    return -(target * logp.masked_fill(~accepts, 0.0)).sum(dim=1).mean()


def train_two_tower(train: TensorPack, val: TensorPack, n_buyers: int, buyer_type_idx: IntArray,
                    cfg: RecommenderConfig) -> tuple[TwoTowerRecommender, list[dict[str, float]]]:
    torch.manual_seed(cfg.seed)
    model = TwoTowerRecommender(len(COMMODITY_KEYS), n_buyers, len(BUYER_TYPES), train.xq.shape[1],
                                train.xc.shape[2], cfg.embed_dim, cfg.hidden)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=cfg.epochs)
    b_idx = torch.arange(n_buyers)[None, :]
    bt_idx = torch.as_tensor(buyer_type_idx)[None, :]
    gen = torch.Generator().manual_seed(cfg.seed)
    history: list[dict[str, float]] = []
    best_state: dict[str, Tensor] | None = None
    best_val, stale = math.inf, 0
    n = train.xq.shape[0]
    for epoch in range(1, cfg.epochs + 1):
        model.train()
        perm = torch.randperm(n, generator=gen)
        total = 0.0
        for start in range(0, n, cfg.batch_size):
            b = train.slice(perm[start:start + cfg.batch_size])
            loss = listwise_loss(model(b.commodity_idx, b.xq, b_idx, bt_idx, b.xc), b.accepts, b.target)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            total += float(loss.detach()) * b.xq.shape[0]
        sched.step()
        model.eval()
        with torch.no_grad():
            vlogits = model(val.commodity_idx, val.xq, b_idx, bt_idx, val.xc)
            vloss = float(listwise_loss(vlogits, val.accepts, val.target))
            vtop1 = float((vlogits.masked_fill(~val.accepts, MASK_VALUE).argmax(1) == val.target.argmax(1)).float().mean())
        history.append({"epoch": epoch, "train_loss": total / n, "val_loss": vloss, "val_top1": vtop1})
        LOGGER.info("epoch %2d  train %.4f  val %.4f  val top-1 %.3f", epoch, total / n, vloss, vtop1)
        if vloss < best_val - 1e-4:
            best_val, stale = vloss, 0
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
            if stale >= cfg.patience:
                LOGGER.info("Early stopping at epoch %d", epoch)
                break
    if best_state is not None:
        model.load_state_dict(best_state)
    return model.eval(), history


def evaluate_policies(rec: DiversionRecommender, q_true: QueryBatch, q_pred: QueryBatch,
                      label: str) -> list[dict[str, Any]]:
    """Realized (true) net value of each policy's choice versus the perfect-information oracle."""
    n = len(q_true)
    rows = np.arange(n)
    ce_true = evaluate_candidates(q_true, rec.cube, rec.econ)
    ce_pred = evaluate_candidates(q_pred, rec.cube, rec.econ)
    true_net = np.where(ce_true.accepts, ce_true.net_value_usd, -np.inf)
    oracle_choice = np.argmax(true_net, axis=1)
    oracle = true_net[rows, oracle_choice]
    has_plan = q_true.planned_idx >= 0
    plan = np.where(has_plan, ce_true.net_value_usd[rows, np.maximum(q_true.planned_idx, 0)], oracle)

    s, _ = rec.scores(q_pred)
    choices: dict[str, IntArray] = {
        "two_tower_top1": np.argmax(s, axis=1),
        "two_tower_retrieval+rerank": rec.select(q_pred)[0],
        "full_scan_economics(pred_rsl)": np.argmax(np.where(ce_pred.accepts, ce_pred.net_value_usd, -np.inf), axis=1),
        "nearest_accepting_buyer": np.argmin(np.where(ce_pred.accepts & ~ce_pred.is_planned, ce_pred.distance_km, np.inf), axis=1),
        "max_deficit_buyer": np.argmax(np.where(ce_pred.accepts, rec.cube.deficit_kg[q_pred.day_idx, :, q_pred.commodity_idx], -np.inf), axis=1),
        "always_continue": np.where(has_plan, q_true.planned_idx, oracle_choice),
    }
    upside = oracle - plan
    out: list[dict[str, Any]] = []
    for name, ch in choices.items():
        realized = true_net[rows, ch]
        realized = np.where(np.isfinite(realized), realized, plan)
        top5 = np.argsort(-s, axis=1)[:, :5]
        out.append({
            "query_set": label, "policy": name, "n_queries": n,
            "mean_realized_net_usd": float(realized.mean()),
            "mean_regret_vs_oracle_usd": float((oracle - realized).mean()),
            "value_capture_vs_plan_pct": float(100.0 * (realized - plan).sum() / max(upside.sum(), 1e-9)),
            "oracle_match_pct": float(100.0 * (ch == oracle_choice).mean()),
            "two_tower_recall@5_pct": float(100.0 * (top5 == oracle_choice[:, None]).any(axis=1).mean()),
            "divert_rate_pct": float(100.0 * (has_plan & (ch != q_true.planned_idx)).mean()),
        })
    return out


def run(data_dir: Path, model_dir: Path, cfg: RecommenderConfig, econ: DiversionEconomics) -> pd.DataFrame:
    telemetry = load_table(data_dir, "telemetry")
    shipments = load_table(data_dir, "shipments")
    cube = MarketCube(load_table(data_dir, "depot_market"), load_table(data_dir, "hubs"))
    LOGGER.info("Market cube: %d days x %d buyers x %d commodities", len(cube.days), cube.n_buyers, len(COMMODITY_KEYS))

    t0 = time.perf_counter()
    predictor = SpoilagePredictor.load(model_dir)
    pred = predictor.predict(telemetry, shipments)
    telemetry = telemetry.assign(container_id=telemetry["container_id"].astype(str)).sort_values(
        ["container_id", "elapsed_h"], kind="mergesort").reset_index(drop=True)
    pred = pred.sort_values(["container_id", "elapsed_h"], kind="mergesort").reset_index(drop=True)
    if not np.allclose(pred["elapsed_h"].to_numpy(), telemetry["elapsed_h"].to_numpy()):
        raise RuntimeError("Phase 2 predictions are misaligned with telemetry")
    LOGGER.info("Phase 2 RSL predictions for %s rows (%.1fs)", f"{len(pred):,}", time.perf_counter() - t0)

    ds = build_query_dataset(telemetry, shipments, pred["predicted_rsl_days"].to_numpy(np.float64), cube, cfg)
    tr, va, te = split_by_container(ds.container_id, cfg)
    LOGGER.info("Queries: %d (%d augmented) | train/val/test %d/%d/%d (grouped by container)",
                len(ds.true_q), int(ds.augmented.sum()), int(tr.sum()), int(va.sum()), int(te.sum()))
    train_pack, qs, cs = make_tensors(ds.true_q.subset(tr), ds.pred_q.subset(tr), cube, econ, None, None, cfg.target_temperature)
    val_pack, _, _ = make_tensors(ds.true_q.subset(va), ds.pred_q.subset(va), cube, econ, qs, cs, cfg.target_temperature)
    model, history = train_two_tower(train_pack, val_pack, cube.n_buyers, cube.buyer_type_idx, cfg)
    rec = DiversionRecommender(model, cube, qs, cs, econ, cfg.retrieve_k)

    results: list[dict[str, Any]] = []
    for label, mask in (("test_real_all", te & ~ds.augmented),
                        ("test_real_at_risk", te & ~ds.augmented & np.isin(ds.status, ["amber", "red"])),
                        ("test_counterfactual_excursions", te & ds.augmented)):
        if mask.sum() >= 20:
            results += evaluate_policies(rec, ds.true_q.subset(mask), ds.pred_q.subset(mask), label)
    table = pd.DataFrame(results)

    rec.save(model_dir, {
        "model_version": MODEL_VERSION, "trained_at_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "model": {"embed_dim": cfg.embed_dim, "hidden": cfg.hidden}, "train_config": asdict(cfg),
        "history": history, "n_queries": len(ds.true_q),
        "evaluation": table.to_dict(orient="records"),
    })
    table.to_csv(model_dir / "recommender_eval.csv", index=False)
    pd.set_option("display.width", 200)
    for set_name, grp in table.groupby("query_set", sort=False):
        LOGGER.info("%s (n=%d):\n%s", str(set_name), int(grp["n_queries"].iloc[0]), grp.drop(columns=["query_set", "n_queries"])
                    .to_string(index=False, float_format=lambda v: f"{v:,.1f}"))

    # Demo: fleet assignment on the at-risk subset of the live snapshot.
    snap = load_table(data_dir, "fleet_snapshot")
    snap = snap[snap["status"].astype(str).isin(["amber", "red"]) & (snap["remaining_transit_h"] > 1.0)]
    if not snap.empty:
        hist = telemetry.merge(snap[["container_id", "snapshot_elapsed_h"]].astype({"container_id": str}), on="container_id")
        hist = hist[hist["elapsed_h"] <= hist["snapshot_elapsed_h"]]
        latest = predictor.predict_latest(hist, shipments).merge(
            hist.sort_values("elapsed_h").groupby("container_id").tail(1)[
                ["container_id", "lat", "lon", "timestamp", "pulp_temp_c", "remaining_transit_h"]], on="container_id")
        plan = rec.assign_fleet(query_batch_from_states(latest, shipments, cube), latest["container_id"].tolist())
        LOGGER.info("Fleet assignment for %d at-risk containers in snapshot:\n%s", len(plan), plan.to_string(index=False))
    return table


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train the two-tower diversion recommender.")
    p.add_argument("--data-dir", type=Path, default=Path("data"))
    p.add_argument("--model-dir", type=Path, default=Path("models"), help="Must contain the Phase 2 model")
    p.add_argument("--queries", type=int, default=30_000, help="Max real telemetry queries (before augmentation)")
    p.add_argument("--epochs", type=int, default=40)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--log-level", type=str, default="INFO")
    return p.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=args.log_level.upper(), format="%(asctime)s %(levelname)s %(name)s | %(message)s")
    torch.set_num_threads(max(1, torch.get_num_threads()))
    run(args.data_dir, args.model_dir, RecommenderConfig(seed=args.seed, max_real_queries=args.queries,
                                                          epochs=args.epochs), DiversionEconomics())
    return 0


if __name__ == "__main__":
    sys.exit(main())
