#!/usr/bin/env python3
"""
spoilage_model.py — Phase 2 of the Cold-Chain Preservation & Dynamic Rerouting System.

Trains, evaluates and serializes an XGBoost regressor that predicts
Remaining Shelf-Life (RSL, days at optimal setpoint) for every reefer telemetry row.

Why a physics-informed design
-----------------------------
RSL is an *integral* over the container's whole thermal history, and it starts from
the load's quality at gate-out. A 6-hour rolling window observes neither, so a
rolling-only model has a hard error floor. We therefore stack three feature layers:

  1. Rolling 6-hour statistics (mean / variance / max / min) of return air, supply
     air, pulp probe and relative humidity, plus shocks, door events, power and duty
     cycle, plus transit duration so far.
  2. Causal cumulative exposure: degree-hours above setpoint, hours below
     chilling or freezing thresholds, humidity-deficit hours, door-open and
     power-off hours, and shock excess above the 2.5 g bruise threshold. We also use
     the load-out QC quality assessment and any setpoint misconfiguration.
  3. Arrhenius kinetic integration of the *product* temperature,
     k = A*exp(-Ea/(R*T)), using public commodity constants (USDA AH-66 / Q10). This
     yields a physics prior, RSL_phys. XGBoost learns the residual (RSL - RSL_phys),
     which corrects for sensor noise, sampling discretization and unmodelled effects.

Kinetics must run on product (pulp) temperature, not air. Air swings with door
openings, defrost and power gaps while ~20 t of cargo barely moves. Integrating
Arrhenius on air gives errors of several days (see the ablation).

Two production variants are serialized:
  * "pulp": uses the USDA pulp probe (many reefers carry one for cold treatment).
  * "air":  for fleets without pulp probes. A virtual pulp sensor reconstructs cargo
            temperature from return air with a first-order thermal-lag observer,
            initialized from the pulp temperature recorded at load-out QC.
An ablation also reports the rolling-only and cumulative-no-kinetics variants, so the
contribution of each layer is measurable rather than asserted.

Splits are grouped by container (no row from a test container is seen in training),
which avoids trajectory leakage.

Artifacts (in --model-dir)
--------------------------
  spoilage_xgb_pulp.json / spoilage_xgb_air.json   XGBoost boosters (native JSON)
  spoilage_model_meta.json                         features, bases, metrics, config
  feature_importance.csv (+ .html if plotly)       gain + permutation importance
  ablation.csv                                     test metrics per feature set
  test_predictions.csv                             held-out predictions (Phase 4 QA)

Usage
-----
    python spoilage_model.py --data-dir data --model-dir models
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Final, Literal, Mapping, Sequence

import numpy as np
import numpy.typing as npt
import pandas as pd
import xgboost as xgb

from data_engine import (
    BRUISE_THRESHOLD_G,
    COMMODITIES,
    FREEZE_DAMAGE_RATE_MULTIPLIER,
    HOURS_PER_DAY,
    KELVIN_OFFSET,
    R_GAS_J_PER_MOL_K,
    TAU_PULP_H,
    KineticModel,
    load_table,
)

LOGGER: Final[logging.Logger] = logging.getLogger("coldchain.spoilage_model")

MODEL_VERSION: Final[str] = "2.0.0"
TARGET: Final[str] = "remaining_shelf_life_days"
COMMODITY_KEYS: Final[tuple[str, ...]] = tuple(COMMODITIES)
NO_THRESHOLD_SENTINEL: Final[float] = -99.0

# Simulator internals / labels that must never become features.
LEAKAGE_COLUMNS: Final[frozenset[str]] = frozenset({
    "quality_index", TARGET, "arrhenius_rate_per_day", "hours_to_zero_current_conditions",
    "remaining_transit_h", "projected_rsl_at_arrival_days", "projected_rsl_at_arrival_current_days",
    "status", "snapshot_elapsed_h", "true_initial_quality", "true_initial_pulp_temp_c",
    "true_lot_shelf_life_factor", "true_lot_q10",
})

FloatArray = npt.NDArray[np.float64]
BoolArray = npt.NDArray[np.bool_]
Variant = Literal["pulp", "air"]


# ======================================================================================
# Vectorized kinetics (mirrors data_engine.KineticModel, applied to observed sensors)
# ======================================================================================
def kinetic_rate_per_day(commodity: npt.NDArray[Any], temp_c: FloatArray, rh_pct: FloatArray) -> FloatArray:
    """Vectorized quality-loss rate (fraction of shelf life per day) for observed conditions."""
    rate = np.full(temp_c.shape[0], np.nan, dtype=np.float64)
    for key, profile in COMMODITIES.items():
        mask = commodity == key
        if not mask.any():
            continue
        kin = KineticModel.from_profile(profile)
        t = temp_c[mask]
        k = kin.pre_exponential_per_day * np.exp(
            -kin.activation_energy_j_per_mol / (R_GAS_J_PER_MOL_K * np.maximum(t + KELVIN_OFFSET, 200.0))
        )
        if profile.chilling_threshold_c is not None:
            k = k + kin.k_ref_per_day * profile.chilling_injury_coeff * np.maximum(0.0, profile.chilling_threshold_c - t)
        k = k + kin.k_ref_per_day * FREEZE_DAMAGE_RATE_MULTIPLIER * np.maximum(0.0, profile.highest_freezing_point_c - t)
        k = k * (1.0 + profile.rh_sensitivity * np.maximum(0.0, profile.optimal_rh_pct - rh_pct[mask]) / 10.0)
        rate[mask] = k
    if np.isnan(rate).any():
        unknown = sorted(set(commodity[np.isnan(rate)].tolist()))
        raise ValueError(f"Unknown commodity keys: {unknown}")
    return rate


def project_remaining_shelf_life(rsl_days: npt.ArrayLike, commodity: str, temp_c: npt.ArrayLike,
                                 hours: npt.ArrayLike, rh_pct: npt.ArrayLike | None = None) -> FloatArray:
    """Project RSL forward for `hours` at a constant product temperature.

    RSL is expressed in setpoint-days, so it is consumed at k(T)/k_ref setpoint-days per day.
    Used by Phase 3/4 to test whether cargo survives a candidate diversion leg.
    """
    profile = COMMODITIES[commodity]
    kin = KineticModel.from_profile(profile)
    t = np.atleast_1d(np.asarray(temp_c, dtype=np.float64))
    rh = (np.full_like(t, profile.optimal_rh_pct) if rh_pct is None
          else np.broadcast_to(np.asarray(rh_pct, dtype=np.float64), t.shape).copy())
    rel = kinetic_rate_per_day(np.full(t.shape[0], commodity, dtype=object), t, rh) / kin.k_ref_per_day
    out = np.asarray(rsl_days, dtype=np.float64) - rel * np.asarray(hours, dtype=np.float64) / HOURS_PER_DAY
    return np.maximum(out, 0.0)


def hours_until_threshold(rsl_days: float, commodity: str, temp_c: float, threshold_days: float = 0.0) -> float:
    """Hours until RSL falls to `threshold_days` if held at `temp_c` (inf if already cold enough to never cross)."""
    if rsl_days <= threshold_days:
        return 0.0
    kin = KineticModel.from_profile(COMMODITIES[commodity])
    rel = float(kinetic_rate_per_day(np.array([commodity], dtype=object), np.array([temp_c]),
                                     np.array([COMMODITIES[commodity].optimal_rh_pct]))[0]) / kin.k_ref_per_day
    return math.inf if rel <= 0 else (rsl_days - threshold_days) / rel * HOURS_PER_DAY


# ======================================================================================
# Feature engineering
# ======================================================================================
@dataclass(frozen=True, slots=True)
class FeatureConfig:
    window_hours: float = 6.0
    initial_quality_noise: float = 0.0  # extra log-sd noise on QC RSL (sensitivity studies)
    seed: int = 42


def _group_roll(df: pd.DataFrame, col: str, window: int, stat: str) -> FloatArray:
    roller = df.groupby("container_id", sort=False, observed=True)[col].rolling(window, min_periods=1)
    series = roller.var(ddof=0) if stat == "var" else getattr(roller, stat)()
    return series.to_numpy(dtype=np.float64)


def infer_sample_interval_h(telemetry: pd.DataFrame) -> float:
    d = telemetry.groupby("container_id", sort=False, observed=True)["elapsed_h"].diff().dropna()
    if d.empty:
        raise ValueError("Telemetry needs >= 2 rows per container to infer the sampling interval")
    return float(d.median())


def load_out_qc(shipments: pd.DataFrame, cfg: FeatureConfig) -> pd.DataFrame:
    """Observable load-out QC per container: estimated RSL (days) and pulp temperature.

    Prefers the Phase 1 QC columns (qc_rsl_days_at_load, qc_pulp_temp_c_at_load). Legacy
    datasets that only carry `initial_quality` are converted using nominal shelf life.
    Latent `true_*` columns are never read.
    """
    out = pd.DataFrame({"container_id": shipments["container_id"].astype(str)})
    if "qc_rsl_days_at_load" in shipments.columns:
        rsl = shipments["qc_rsl_days_at_load"].to_numpy(np.float64)
    elif {"initial_quality", "commodity"} <= set(shipments.columns):
        sl = shipments["commodity"].map({k: p.shelf_life_days_at_setpoint for k, p in COMMODITIES.items()})
        rsl = shipments["initial_quality"].to_numpy(np.float64) * sl.to_numpy(np.float64)
    else:
        raise ValueError("Shipments need 'qc_rsl_days_at_load' (or legacy 'initial_quality' + 'commodity')")
    if cfg.initial_quality_noise > 0:
        rng = np.random.default_rng(cfg.seed)
        rsl = rsl * np.exp(rng.normal(0.0, cfg.initial_quality_noise, rsl.shape[0]))
    out["qc_rsl_days_at_load"] = rsl
    pulp_col = next((c for c in ("qc_pulp_temp_c_at_load", "initial_pulp_temp_c") if c in shipments.columns), None)
    if pulp_col is None:
        LOGGER.warning("No load-out pulp temperature in shipments; virtual pulp starts at setpoint")
        out["qc_initial_pulp_temp_c"] = np.nan
    else:
        out["qc_initial_pulp_temp_c"] = shipments[pulp_col].to_numpy(np.float64)
    return out


def estimate_pulp_from_air(df: pd.DataFrame) -> FloatArray:
    """Virtual pulp sensor: dT_pulp/dt = (T_air - T_pulp)/tau_pulp + respiration heat.

    Initialized per container from the load-out QC pulp temperature and driven by the
    trapezoidal mean of consecutive return-air readings. `df` must be sorted by
    container_id, elapsed_h and contain dt_h and qc_initial_pulp_temp_c.
    """
    air = df["return_air_temp_c"].to_numpy(np.float64)
    dt = df["dt_h"].to_numpy(np.float64)
    p0 = df["qc_initial_pulp_temp_c"].to_numpy(np.float64)
    commodity = df["commodity"].to_numpy(dtype=object)
    cid = df["container_id"].to_numpy(dtype=object)
    kin = {k: KineticModel.from_profile(p) for k, p in COMMODITIES.items()}
    out = np.empty_like(air)
    pulp = 0.0
    air_prev = 0.0
    for i in range(air.shape[0]):
        new_container = i == 0 or cid[i] != cid[i - 1]
        if new_container:
            pulp, air_prev = p0[i], air[i]
        model = kin[commodity[i]]
        drive = 0.5 * (air[i] + air_prev)
        n_sub = max(1, int(math.ceil(dt[i] / 0.1)))
        h = dt[i] / n_sub
        for _ in range(n_sub):
            resp = model.profile.respiration_heat_k_per_h * model.relative_rate(pulp)
            pulp += ((drive - pulp) / TAU_PULP_H + resp) * h
        out[i] = pulp
        air_prev = air[i]
    return out


def build_features(telemetry: pd.DataFrame, shipments: pd.DataFrame, cfg: FeatureConfig,
                   sample_interval_h: float | None = None) -> pd.DataFrame:
    """Causal (past-only) features per telemetry row. Pulp features appear only if a pulp probe exists."""
    required = {"container_id", "commodity", "elapsed_h", "return_air_temp_c", "supply_air_temp_c",
                "relative_humidity_pct", "vibration_peak_g", "door_open", "power_on",
                "compressor_duty_cycle", "setpoint_c", "defrost_active"}
    missing = required - set(telemetry.columns)
    if missing:
        raise ValueError(f"Telemetry missing columns: {sorted(missing)}")
    df = telemetry.copy()
    df["container_id"] = df["container_id"].astype(str)
    df["commodity"] = df["commodity"].astype(str)
    df = df.sort_values(["container_id", "elapsed_h"], kind="mergesort").reset_index(drop=True)
    df = df.merge(load_out_qc(shipments, cfg), on="container_id", how="left", validate="many_to_one")
    if df["qc_rsl_days_at_load"].isna().any():
        raise ValueError("Some telemetry containers have no shipment record / load-out QC")

    has_pulp = "pulp_temp_c" in df.columns and df["pulp_temp_c"].notna().all()
    interval = sample_interval_h or infer_sample_interval_h(df)
    window = max(1, int(round(cfg.window_hours / interval)))
    g = df.groupby("container_id", sort=False, observed=True)
    commodity = df["commodity"].to_numpy(dtype=object)

    # Static commodity reference data
    lookup = {k: COMMODITIES[k] for k in COMMODITY_KEYS}
    for key in COMMODITY_KEYS:
        df[f"is_{key}"] = (df["commodity"] == key).astype(np.int8)
    df["ref_setpoint_c"] = df["commodity"].map({k: p.setpoint_c for k, p in lookup.items()})
    df["ref_shelf_life_days"] = df["commodity"].map({k: p.shelf_life_days_at_setpoint for k, p in lookup.items()})
    df["ref_q10"] = df["commodity"].map({k: p.q10 for k, p in lookup.items()})
    df["ref_optimal_rh_pct"] = df["commodity"].map({k: p.optimal_rh_pct for k, p in lookup.items()})
    chill = df["commodity"].map({k: (p.chilling_threshold_c if p.chilling_threshold_c is not None
                                     else NO_THRESHOLD_SENTINEL) for k, p in lookup.items()})
    freeze = df["commodity"].map({k: p.highest_freezing_point_c for k, p in lookup.items()})
    bruise = df["commodity"].map({k: p.bruise_coeff for k, p in lookup.items()}).to_numpy(np.float64)
    df["ref_chill_threshold_c"], df["ref_freeze_point_c"] = chill, freeze
    k_ref = 1.0 / df["ref_shelf_life_days"].to_numpy(np.float64)

    # Load-out QC RSL expressed as nominal-equivalent quality (the physics prior starts here).
    df["qc_initial_quality"] = df["qc_rsl_days_at_load"] / df["ref_shelf_life_days"]
    df["setpoint_offset_c"] = df["setpoint_c"] - df["ref_setpoint_c"]
    df["qc_initial_pulp_temp_c"] = df["qc_initial_pulp_temp_c"].fillna(df["ref_setpoint_c"])
    df["qc_initial_pulp_excess_c"] = df["qc_initial_pulp_temp_c"] - df["ref_setpoint_c"]
    dt = g["elapsed_h"].diff().fillna(df["elapsed_h"]).to_numpy(np.float64)
    df["dt_h"] = dt

    # Layer 1: rolling window statistics
    temp_cols = ["return_air_temp_c", "supply_air_temp_c", "relative_humidity_pct"] + (["pulp_temp_c"] if has_pulp else [])
    for col in temp_cols:
        for stat in ("mean", "var", "max", "min"):
            df[f"{col}_roll{cfg.window_hours:g}h_{stat}"] = _group_roll(df, col, window, stat)
    df[f"vibration_roll{cfg.window_hours:g}h_max"] = _group_roll(df, "vibration_peak_g", window, "max")
    df[f"door_open_roll{cfg.window_hours:g}h_sum"] = _group_roll(df, "door_open", window, "sum")
    df[f"power_on_roll{cfg.window_hours:g}h_mean"] = _group_roll(df, "power_on", window, "mean")
    df[f"duty_roll{cfg.window_hours:g}h_mean"] = _group_roll(df, "compressor_duty_cycle", window, "mean")
    df[f"return_air_dev_roll{cfg.window_hours:g}h_mean"] = (
        df[f"return_air_temp_c_roll{cfg.window_hours:g}h_mean"] - df["ref_setpoint_c"])

    # Layer 2: cumulative exposure (causal cumulative sums)
    def cum(values: FloatArray) -> FloatArray:
        summed = pd.Series(values, index=df.index).groupby(df["container_id"], sort=False).cumsum()
        return np.asarray(summed.to_numpy(), dtype=np.float64)

    air = df["return_air_temp_c"].to_numpy(np.float64)
    rh = df["relative_humidity_pct"].to_numpy(np.float64)
    ref_sp = df["ref_setpoint_c"].to_numpy(np.float64)
    df["cum_degh_above_sp_air"] = cum(np.maximum(0.0, air - ref_sp) * dt)
    df["cum_h_above_sp2_air"] = cum((air > ref_sp + 2.0) * dt)
    df["cum_rh_deficit_pct_h"] = cum(np.maximum(0.0, df["ref_optimal_rh_pct"].to_numpy(np.float64) - rh) * dt)
    df["cum_door_open_h"] = cum(df["door_open"].to_numpy(np.float64) * dt)
    df["cum_power_off_h"] = cum((1.0 - df["power_on"].to_numpy(np.float64)) * dt)
    shock_excess = np.maximum(0.0, df["vibration_peak_g"].to_numpy(np.float64) - BRUISE_THRESHOLD_G)
    df["cum_shock_excess_g"] = cum(shock_excess)
    df["cum_shock_events"] = cum((shock_excess > 0).astype(np.float64))
    df["setpoint_hold_rsl_days"] = np.maximum(
        0.0, df["qc_initial_quality"] * df["ref_shelf_life_days"] - df["elapsed_h"] / HOURS_PER_DAY)

    # Layer 3: Arrhenius integration of observed sensor streams (trapezoidal)
    def kinetic_block(temp: FloatArray, tag: str) -> None:
        rate = kinetic_rate_per_day(commodity, temp, rh)
        prev = pd.Series(rate, index=df.index).groupby(df["container_id"], sort=False).shift(1)
        prev_arr = prev.fillna(pd.Series(rate, index=df.index)).to_numpy(np.float64)
        loss = cum(0.5 * (rate + prev_arr) * dt / HOURS_PER_DAY)
        q_phys = np.clip(df["qc_initial_quality"].to_numpy(np.float64) - loss - bruise * df["cum_shock_excess_g"].to_numpy(np.float64), 0.0, 1.0)
        df[f"rel_rate_now_{tag}"] = rate / k_ref
        df[f"cum_kinetic_loss_{tag}"] = loss
        df[f"phys_rsl_days_{tag}"] = q_phys / k_ref

    kinetic_block(air, "air")
    vpulp = estimate_pulp_from_air(df)
    df["virtual_pulp_temp_c"] = vpulp
    df["cum_degh_above_sp_vpulp"] = cum(np.maximum(0.0, vpulp - ref_sp) * dt)
    df["cum_degh_below_chill_vpulp"] = cum(np.maximum(0.0, chill.to_numpy(np.float64) - vpulp) * dt)
    df["cum_degh_below_freeze_vpulp"] = cum(np.maximum(0.0, freeze.to_numpy(np.float64) - vpulp) * dt)
    kinetic_block(vpulp, "vpulp")
    if has_pulp:
        pulp = df["pulp_temp_c"].to_numpy(np.float64)
        df["cum_degh_above_sp_pulp"] = cum(np.maximum(0.0, pulp - ref_sp) * dt)
        df["cum_degh_below_chill_pulp"] = cum(np.maximum(0.0, chill.to_numpy(np.float64) - pulp) * dt)
        df["cum_degh_below_freeze_pulp"] = cum(np.maximum(0.0, freeze.to_numpy(np.float64) - pulp) * dt)
        kinetic_block(pulp, "pulp")
        # Respiration signature: faster-ageing lots respire more, so pulp runs warmer than air.
        gap = pd.Series(pulp - air, index=df.index)
        df[f"pulp_minus_air_roll{cfg.window_hours:g}h_mean"] = _group_roll(df.assign(_gap=gap), "_gap", window, "mean")
        df["pulp_minus_air_mean_since_load"] = gap.groupby(df["container_id"], sort=False).expanding().mean().to_numpy()
    df["duty_mean_since_load"] = (df.groupby("container_id", sort=False)["compressor_duty_cycle"]
                                  .expanding().mean().to_numpy())
    return df


# ======================================================================================
# Feature sets (ablation) and training
# ======================================================================================
@dataclass(frozen=True, slots=True)
class FeatureSet:
    name: str
    description: str
    features: tuple[str, ...]
    base_column: str | None  # physics prior; model learns (target - base)


def define_feature_sets(columns: Sequence[str], window_hours: float) -> dict[str, FeatureSet]:
    w = f"{window_hours:g}h"
    cols = set(columns)
    onehot = tuple(f"is_{k}" for k in COMMODITY_KEYS)
    static = ("ref_setpoint_c", "ref_shelf_life_days", "ref_q10", "ref_optimal_rh_pct",
              "ref_chill_threshold_c", "ref_freeze_point_c")
    spec_rolling = tuple(f"{c}_roll{w}_{s}" for c in ("return_air_temp_c", "relative_humidity_pct")
                         for s in ("mean", "var", "max"))
    rolling_air = tuple(f"{c}_roll{w}_{s}" for c in ("return_air_temp_c", "supply_air_temp_c", "relative_humidity_pct")
                        for s in ("mean", "var", "max", "min")) + (
        f"vibration_roll{w}_max", f"door_open_roll{w}_sum", f"power_on_roll{w}_mean", f"duty_roll{w}_mean",
        f"return_air_dev_roll{w}_mean")
    rolling_pulp = tuple(f"pulp_temp_c_roll{w}_{s}" for s in ("mean", "var", "max", "min"))
    cumulative = ("qc_initial_quality", "qc_rsl_days_at_load", "qc_initial_pulp_excess_c", "duty_mean_since_load", "setpoint_offset_c", "setpoint_hold_rsl_days", "cum_degh_above_sp_air",
                  "cum_h_above_sp2_air", "cum_rh_deficit_pct_h", "cum_door_open_h", "cum_power_off_h",
                  "cum_shock_excess_g", "cum_shock_events")
    kin_air = ("rel_rate_now_air", "cum_kinetic_loss_air", "phys_rsl_days_air")
    kin_vpulp = ("virtual_pulp_temp_c", "cum_degh_above_sp_vpulp", "cum_degh_below_chill_vpulp",
                 "cum_degh_below_freeze_vpulp", "rel_rate_now_vpulp", "cum_kinetic_loss_vpulp", "phys_rsl_days_vpulp")
    kin_pulp = (f"pulp_minus_air_roll{w}_mean", "pulp_minus_air_mean_since_load", "cum_degh_above_sp_pulp", "cum_degh_below_chill_pulp", "cum_degh_below_freeze_pulp",
                "rel_rate_now_pulp", "cum_kinetic_loss_pulp", "phys_rsl_days_pulp")
    base = ("elapsed_h",) + onehot + static
    sets = {
        "A_rolling_only": FeatureSet("A_rolling_only", "Spec baseline: 6h rolling temp/RH stats + transit duration",
                                     base + spec_rolling, None),
        "B_cumulative": FeatureSet("B_cumulative", "+ full rolling set, cumulative exposure, load-out QC (no kinetics)",
                                   base + rolling_air + cumulative, "setpoint_hold_rsl_days"),
        "C0_kinetics_on_air": FeatureSet("C0_kinetics_on_air", "Anti-pattern: Arrhenius integrated on air temperature",
                                         base + rolling_air + cumulative + kin_air, "phys_rsl_days_air"),
        "C_physics_air": FeatureSet("C_physics_air", "Air sensors only + virtual pulp observer + Arrhenius",
                                    base + rolling_air + cumulative + kin_air + kin_vpulp, "phys_rsl_days_vpulp"),
        "D_physics_pulp": FeatureSet("D_physics_pulp", "+ pulp probe rolling stats and Arrhenius integration",
                                     base + rolling_air + cumulative + kin_air + kin_vpulp + rolling_pulp + kin_pulp,
                                     "phys_rsl_days_pulp"),
    }
    return {k: v for k, v in sets.items() if set(v.features) <= cols and (v.base_column is None or v.base_column in cols)}


@dataclass(frozen=True, slots=True)
class TrainConfig:
    seed: int = 42
    val_fraction: float = 0.15
    test_fraction: float = 0.15
    n_estimators: int = 3000
    learning_rate: float = 0.05
    max_depth: int = 7
    min_child_weight: float = 5.0
    subsample: float = 0.8
    colsample_bytree: float = 0.8
    reg_lambda: float = 1.0
    early_stopping_rounds: int = 100


@dataclass(slots=True)
class Metrics:
    rmse: float
    mae: float
    r2: float
    p95_abs_error: float
    n: int

    @staticmethod
    def compute(y: FloatArray, p: FloatArray) -> Metrics:
        err = p - y
        ss_tot = float(np.sum((y - y.mean()) ** 2))
        return Metrics(
            rmse=float(np.sqrt(np.mean(err ** 2))), mae=float(np.mean(np.abs(err))),
            r2=float(1.0 - np.sum(err ** 2) / ss_tot) if ss_tot > 0 else float("nan"),
            p95_abs_error=float(np.quantile(np.abs(err), 0.95)), n=int(y.size),
        )

    def as_dict(self) -> dict[str, float | int]:
        return {"rmse": self.rmse, "mae": self.mae, "r2": self.r2, "p95_abs_error": self.p95_abs_error, "n": self.n}


@dataclass(slots=True)
class TrainedVariant:
    feature_set: FeatureSet
    model: xgb.XGBRegressor
    best_iteration: int
    test_metrics: Metrics
    residual_enabled: bool = True  # False => validation showed ML residual does not beat the physics prior
    val_rmse_model: float = float("nan")
    val_rmse_physics: float = float("nan")
    breakdown: dict[str, dict[str, dict[str, float | int]]] = field(default_factory=dict)

    def predict(self, features: pd.DataFrame, force_residual: bool = False) -> FloatArray:
        base = (features[self.feature_set.base_column].to_numpy(np.float64)
                if self.feature_set.base_column is not None else np.zeros(len(features)))
        if not (self.residual_enabled or force_residual):
            return np.maximum(base, 0.0)
        x = features.loc[:, list(self.feature_set.features)].astype(np.float32)
        pred = self.model.predict(x, iteration_range=(0, self.best_iteration + 1)).astype(np.float64)
        return np.maximum(pred + base, 0.0)


def grouped_split(container_ids: pd.Series, cfg: TrainConfig) -> tuple[BoolArray, BoolArray, BoolArray]:
    """Boolean masks (train, val, test) with every container entirely in one split."""
    unique = np.array(sorted(container_ids.unique()))
    rng = np.random.default_rng(cfg.seed)
    rng.shuffle(unique)
    n_test = max(1, int(round(len(unique) * cfg.test_fraction)))
    n_val = max(1, int(round(len(unique) * cfg.val_fraction)))
    test_ids, val_ids = set(unique[:n_test]), set(unique[n_test:n_test + n_val])
    ids = container_ids.to_numpy()
    test = np.isin(ids, list(test_ids))
    val = np.isin(ids, list(val_ids))
    return ~(test | val), val, test


def train_variant(fs: FeatureSet, df: pd.DataFrame, masks: tuple[BoolArray, BoolArray, BoolArray],
                  cfg: TrainConfig) -> TrainedVariant:
    train_m, val_m, test_m = masks
    x = df.loc[:, list(fs.features)].astype(np.float32)
    base = df[fs.base_column].to_numpy(np.float64) if fs.base_column else np.zeros(len(df))
    y = df[TARGET].to_numpy(np.float64)
    resid = y - base
    model = xgb.XGBRegressor(
        n_estimators=cfg.n_estimators, learning_rate=cfg.learning_rate, max_depth=cfg.max_depth,
        min_child_weight=cfg.min_child_weight, subsample=cfg.subsample, colsample_bytree=cfg.colsample_bytree,
        reg_lambda=cfg.reg_lambda, tree_method="hist", objective="reg:squarederror", eval_metric="rmse",
        early_stopping_rounds=cfg.early_stopping_rounds, random_state=cfg.seed, n_jobs=-1,
    )
    t0 = time.perf_counter()
    model.fit(x[train_m], resid[train_m], eval_set=[(x[val_m], resid[val_m])], verbose=False)
    best = int(model.best_iteration)
    variant = TrainedVariant(fs, model, best, Metrics(0, 0, 0, 0, 0))
    if fs.base_column is not None:
        # Validation gate: keep the residual model only if it beats the physics prior on unseen containers.
        y_val = y[val_m]
        variant.val_rmse_model = Metrics.compute(y_val, variant.predict(df[val_m], force_residual=True)).rmse
        variant.val_rmse_physics = Metrics.compute(y_val, np.maximum(base[val_m], 0.0)).rmse
        variant.residual_enabled = variant.val_rmse_model < variant.val_rmse_physics
        if not variant.residual_enabled:
            LOGGER.info("%s: residual model (val %.4f) does not beat physics prior (val %.4f); using physics only",
                        fs.name, variant.val_rmse_model, variant.val_rmse_physics)
    pred = variant.predict(df[test_m])
    variant.test_metrics = Metrics.compute(y[test_m], pred)
    LOGGER.info("%-15s trees=%-5d test RMSE=%.4f d  MAE=%.4f  R2=%.5f  (%.1fs)", fs.name, best + 1,
                variant.test_metrics.rmse, variant.test_metrics.mae, variant.test_metrics.r2, time.perf_counter() - t0)
    return variant


def breakdown_metrics(df: pd.DataFrame, pred: FloatArray, by: Sequence[str]) -> dict[str, dict[str, dict[str, float | int]]]:
    out: dict[str, dict[str, dict[str, float | int]]] = {}
    y = df[TARGET].to_numpy(np.float64)
    for col in by:
        out[col] = {}
        for level, idx in df.groupby(col, observed=True).indices.items():
            if len(idx) >= 20:
                out[col][str(level)] = Metrics.compute(y[idx], pred[idx]).as_dict()
    return out


def importance_table(variant: TrainedVariant, df_test: pd.DataFrame, seed: int, repeats: int = 3,
                     max_rows: int = 20_000) -> pd.DataFrame:
    """XGBoost gain importance plus permutation importance (RMSE increase on held-out rows)."""
    feats = list(variant.feature_set.features)
    gain = variant.model.get_booster().get_score(importance_type="gain")
    rng = np.random.default_rng(seed)
    sample = df_test.sample(n=min(max_rows, len(df_test)), random_state=seed) if len(df_test) > max_rows else df_test
    y = sample[TARGET].to_numpy(np.float64)
    base_rmse = Metrics.compute(y, variant.predict(sample)).rmse
    perm: dict[str, float] = {}
    for f in feats:
        deltas: list[float] = []
        for _ in range(repeats):
            shuffled = sample.copy()
            shuffled[f] = rng.permutation(shuffled[f].to_numpy())
            # If the shuffled feature is also the physics base, the permuted base propagates too (true dependence).
            deltas.append(Metrics.compute(y, variant.predict(shuffled)).rmse - base_rmse)
        perm[f] = float(np.mean(deltas))
    table = pd.DataFrame({
        "feature": feats,
        "gain": [float(np.mean(gain.get(f, 0.0))) for f in feats],
        "permutation_rmse_increase_days": [perm[f] for f in feats],
    })
    table["gain_share"] = table["gain"] / max(table["gain"].sum(), 1e-12)
    return table.sort_values("permutation_rmse_increase_days", ascending=False).reset_index(drop=True)


# ======================================================================================
# Inference API (used by Phase 3 and Phase 4)
# ======================================================================================
class SpoilagePredictor:
    """Loads serialized variants and predicts RSL for arbitrary telemetry histories."""

    def __init__(self, models: Mapping[Variant, xgb.XGBRegressor], meta: Mapping[str, Any]) -> None:
        self.models = dict(models)
        self.meta = dict(meta)
        self.feature_config = FeatureConfig(window_hours=float(meta["window_hours"]))

    @classmethod
    def load(cls, model_dir: Path) -> SpoilagePredictor:
        meta = json.loads((model_dir / "spoilage_model_meta.json").read_text())
        models: dict[Variant, xgb.XGBRegressor] = {}
        for variant in ("pulp", "air"):
            info = meta["variants"].get(variant)
            if info is None:
                continue
            m = xgb.XGBRegressor()
            m.load_model(model_dir / info["model_file"])
            models[variant] = m  # type: ignore[index]
        if not models:
            raise FileNotFoundError(f"No serialized variants in {model_dir}")
        return cls(models, meta)

    def _choose(self, telemetry: pd.DataFrame, variant: Literal["auto", "pulp", "air"]) -> Variant:
        has_pulp = "pulp_temp_c" in telemetry.columns and telemetry["pulp_temp_c"].notna().all()
        if variant == "auto":
            return "pulp" if (has_pulp and "pulp" in self.models) else "air"
        if variant == "pulp" and not has_pulp:
            raise ValueError("Pulp variant requested but telemetry has no complete pulp_temp_c column")
        return variant

    def predict(self, telemetry: pd.DataFrame, shipments: pd.DataFrame,
                variant: Literal["auto", "pulp", "air"] = "auto") -> pd.DataFrame:
        chosen = self._choose(telemetry, variant)
        info = self.meta["variants"][chosen]
        tel = telemetry if chosen == "pulp" else telemetry.drop(columns=["pulp_temp_c"], errors="ignore")
        feats = build_features(tel, shipments, self.feature_config, float(self.meta["sample_interval_h"]))
        base = feats[info["base_column"]].to_numpy(np.float64)
        if info.get("residual_enabled", True):
            x = feats.loc[:, info["features"]].astype(np.float32)
            resid = self.models[chosen].predict(x, iteration_range=(0, int(info["best_iteration"]) + 1))
            pred = np.maximum(base + resid.astype(np.float64), 0.0)
        else:
            pred = np.maximum(base, 0.0)
        return pd.DataFrame({
            "container_id": feats["container_id"], "commodity": feats["commodity"],
            "elapsed_h": feats["elapsed_h"], "predicted_rsl_days": pred,
            "physics_rsl_days": feats[info["base_column"]].to_numpy(np.float64), "variant": chosen,
        })

    def predict_latest(self, telemetry: pd.DataFrame, shipments: pd.DataFrame,
                       variant: Literal["auto", "pulp", "air"] = "auto") -> pd.DataFrame:
        """One row per container at its most recent reading (fleet status view)."""
        pred = self.predict(telemetry, shipments, variant)
        return pred.sort_values("elapsed_h").groupby("container_id", sort=False).tail(1).reset_index(drop=True)


# ======================================================================================
# Orchestration
# ======================================================================================
def save_artifacts(model_dir: Path, variants: Mapping[str, TrainedVariant], ablation: pd.DataFrame,
                   importance: pd.DataFrame, test_pred: pd.DataFrame, meta: dict[str, Any]) -> None:
    model_dir.mkdir(parents=True, exist_ok=True)
    meta["variants"] = {}
    for key, name in (("pulp", "D_physics_pulp"), ("air", "C_physics_air")):
        v = variants.get(name)
        if v is None:
            continue
        fname = f"spoilage_xgb_{key}.json"
        v.model.save_model(model_dir / fname)
        meta["variants"][key] = {
            "feature_set": name, "model_file": fname, "features": list(v.feature_set.features),
            "base_column": v.feature_set.base_column, "best_iteration": v.best_iteration,
            "residual_enabled": v.residual_enabled, "val_rmse_model": v.val_rmse_model,
            "val_rmse_physics": v.val_rmse_physics,
            "test_metrics": v.test_metrics.as_dict(), "breakdown": v.breakdown,
        }
    (model_dir / "spoilage_model_meta.json").write_text(json.dumps(meta, indent=2, default=str))
    ablation.to_csv(model_dir / "ablation.csv", index=False)
    importance.to_csv(model_dir / "feature_importance.csv", index=False)
    test_pred.to_csv(model_dir / "test_predictions.csv", index=False)
    try:
        import plotly.express as px
    except ImportError:
        LOGGER.info("plotly not installed; skipping importance chart")
        return
    top = importance.head(20).iloc[::-1]
    fig = px.bar(top, x="permutation_rmse_increase_days", y="feature", orientation="h",
                 title="Permutation importance: RMSE increase (days) when a feature is shuffled",
                 labels={"permutation_rmse_increase_days": "RMSE increase (days)", "feature": ""})
    fig.update_layout(height=640, margin={"l": 260})
    fig.write_html(model_dir / "feature_importance.html", include_plotlyjs="cdn")


def run(data_dir: Path, model_dir: Path, fcfg: FeatureConfig, tcfg: TrainConfig,
        target_rmse: float, ablation: bool) -> dict[str, Any]:
    telemetry = load_table(data_dir, "telemetry")
    shipments = load_table(data_dir, "shipments")
    LOGGER.info("Loaded %s telemetry rows, %d shipments", f"{len(telemetry):,}", len(shipments))
    interval = infer_sample_interval_h(telemetry.sort_values(["container_id", "elapsed_h"]))
    t0 = time.perf_counter()
    df = build_features(telemetry, shipments, fcfg, interval)
    LOGGER.info("Built features in %.1fs (interval %.3f h, window %g h)", time.perf_counter() - t0, interval, fcfg.window_hours)
    df = df.merge(shipments[["container_id", "faults"]].astype({"container_id": str}), on="container_id", how="left")
    df["fault_primary"] = df["faults"].fillna("none").str.split("|").str[0]

    sets = define_feature_sets(list(df.columns), fcfg.window_hours)
    leaked = [f for fs in sets.values() for f in fs.features if f in LEAKAGE_COLUMNS]
    if leaked:
        raise RuntimeError(f"Leakage columns in feature sets: {leaked}")
    masks = grouped_split(df["container_id"], tcfg)
    LOGGER.info("Split rows train/val/test = %d / %d / %d (grouped by container)",
                int(masks[0].sum()), int(masks[1].sum()), int(masks[2].sum()))

    to_train = list(sets) if ablation else [k for k in ("C_physics_air", "D_physics_pulp") if k in sets]
    variants = {name: train_variant(sets[name], df, masks, tcfg) for name in to_train}
    prod_name = "D_physics_pulp" if "D_physics_pulp" in variants else "C_physics_air"
    prod = variants[prod_name]
    test_df = df[masks[2]].reset_index(drop=True)
    for v in variants.values():
        if v.feature_set.name in ("C_physics_air", "D_physics_pulp"):
            v.breakdown = breakdown_metrics(test_df, v.predict(test_df), ("commodity", "status", "fault_primary"))

    ablation_df = pd.DataFrame([{"feature_set": n, "description": v.feature_set.description,
                                 "n_features": len(v.feature_set.features), "physics_base": v.feature_set.base_column or "",
                                 "residual_enabled": v.residual_enabled,
                                 **v.test_metrics.as_dict(), "meets_target": v.test_metrics.rmse < target_rmse}
                                for n, v in variants.items()])
    # Physics prior alone, for reference: what does pure kinetics achieve without ML?
    for col in ("phys_rsl_days_air", "phys_rsl_days_vpulp", "phys_rsl_days_pulp"):
        if col in test_df:
            m = Metrics.compute(test_df[TARGET].to_numpy(np.float64), test_df[col].to_numpy(np.float64))
            ablation_df.loc[len(ablation_df)] = {"feature_set": f"physics_only_{col.split('_')[-1]}",
                                                  "description": "Arrhenius integration alone (no ML)", "n_features": 0,
                                                  "physics_base": col, "residual_enabled": False,
                                                  **m.as_dict(), "meets_target": m.rmse < target_rmse}
    importance = importance_table(prod, test_df, tcfg.seed)
    test_pred = test_df[["container_id", "commodity", "elapsed_h", "status", "fault_primary", TARGET]].copy()
    test_pred["predicted_rsl_days"] = prod.predict(test_df)
    test_pred["abs_error_days"] = (test_pred["predicted_rsl_days"] - test_pred[TARGET]).abs()

    meta: dict[str, Any] = {
        "model_version": MODEL_VERSION, "trained_at_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "target": TARGET, "target_rmse_days": target_rmse, "production_feature_set": prod_name,
        "production_test_rmse_days": prod.test_metrics.rmse, "meets_target": prod.test_metrics.rmse < target_rmse,
        "window_hours": fcfg.window_hours, "sample_interval_h": interval,
        "initial_quality_noise": fcfg.initial_quality_noise, "commodities": list(COMMODITY_KEYS),
        "train_config": asdict(tcfg),
        "n_rows": int(len(df)), "n_containers": int(df["container_id"].nunique()),
    }
    save_artifacts(model_dir, variants, ablation_df, importance, test_pred, meta)

    pd.set_option("display.width", 160)
    LOGGER.info("Ablation (held-out containers):\n%s",
                ablation_df[["feature_set", "n_features", "residual_enabled", "rmse", "mae", "r2", "p95_abs_error", "meets_target"]]
                .to_string(index=False, float_format=lambda v: f"{v:.4f}"))
    LOGGER.info("Top features (%s):\n%s", prod_name,
                importance.head(12).to_string(index=False, float_format=lambda v: f"{v:.4f}"))
    for comm, cm in prod.breakdown.get("commodity", {}).items():
        sl = COMMODITIES[comm].shelf_life_days_at_setpoint
        LOGGER.info("  %-22s RMSE %.3f d  (%.1f%% of %g-day shelf life)", comm, cm["rmse"], 100 * float(cm["rmse"]) / sl, sl)
    status_bd = prod.breakdown.get("status", {})
    LOGGER.info("Production RMSE by status: %s", {k: round(float(v["rmse"]), 4) for k, v in status_bd.items()})
    verdict = "PASS" if meta["meets_target"] else "FAIL"
    LOGGER.info("%s: production RMSE %.4f d vs target < %.2f d", verdict, prod.test_metrics.rmse, target_rmse)
    return meta


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Train the physics-informed XGBoost shelf-life regressor.")
    p.add_argument("--data-dir", type=Path, default=Path("data"))
    p.add_argument("--model-dir", type=Path, default=Path("models"))
    p.add_argument("--window-hours", type=float, default=6.0)
    p.add_argument("--initial-quality-noise", type=float, default=0.0,
                   help="Extra multiplicative (log-sd) error injected on top of the QC RSL estimate")
    p.add_argument("--target-rmse", type=float, default=0.25)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--skip-ablation", action="store_true", help="Train production variants only")
    p.add_argument("--strict", action="store_true", help="Exit non-zero if the RMSE target is missed")
    p.add_argument("--log-level", type=str, default="INFO")
    return p.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    logging.basicConfig(level=args.log_level.upper(), format="%(asctime)s %(levelname)s %(name)s | %(message)s")
    meta = run(args.data_dir, args.model_dir,
               FeatureConfig(args.window_hours, args.initial_quality_noise, args.seed),
               TrainConfig(seed=args.seed), args.target_rmse, not args.skip_ablation)
    return 0 if (meta["meets_target"] or not args.strict) else 2


if __name__ == "__main__":
    sys.exit(main())
