"""
api.py — Phase 4: REST API for the Cold-Chain Preservation & Dynamic Rerouting System (FastAPI).

It shares fleet_service.FleetService with the Streamlit dashboard, so both surfaces
return identical status, alerts and recommendations. This is the integration point for
a TMS, a carrier portal or alerting (e.g., a webhook consumer polling /fleet?status=red).

Run:
    COLDCHAIN_DATA_DIR=data COLDCHAIN_MODEL_DIR=models uvicorn api:app --host 0.0.0.0 --port 8000
Docs: http://localhost:8000/docs
"""
from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from fleet_service import ARRIVED, FleetService

app = FastAPI(title="Cold-Chain Preservation & Dynamic Rerouting API", version="4.0.0")

StatusFilter = Literal["green", "amber", "red", "arrived"]
FLEET_FIELDS: list[str] = [
    "container_id", "commodity", "display_name", "status", "origin", "destination", "activity", "lat", "lon",
    "timestamp", "remaining_transit_h", "setpoint_c", "return_air_temp_c", "pulp_temp_c", "relative_humidity_pct",
    "predicted_rsl_days", "rsl_fraction", "projected_arrival_rsl_days", "hours_to_retail_spec",
    "cargo_value_usd", "alerts",
]


@lru_cache(maxsize=1)
def service() -> FleetService:
    return FleetService(Path(os.environ.get("COLDCHAIN_DATA_DIR", "data")),
                        Path(os.environ.get("COLDCHAIN_MODEL_DIR", "models")))


def records(df: pd.DataFrame) -> list[dict[str, Any]]:
    """JSON-safe records (ISO timestamps, NaN -> null, numpy scalars -> Python)."""
    return json.loads(df.to_json(orient="records", date_format="iso"))


def container_row(fleet: pd.DataFrame, container_id: str) -> pd.Series:
    match = fleet[fleet["container_id"] == container_id]
    if match.empty:
        raise HTTPException(status_code=404, detail=f"Unknown container {container_id}")
    return match.iloc[0]


class DecisionRequest(BaseModel):
    buyer_code: str = Field(..., description="Buyer to route to (the planned destination = keep on plan)")
    operator: str = Field(..., min_length=1)
    note: str = ""
    offset_h: float = Field(0.0, ge=0.0)


@app.get("/health")
def health() -> dict[str, Any]:
    svc = service()
    return {"status": "ok", "containers": int(len(svc.total_elapsed)), "model_variant": svc.model_variant,
            "max_offset_h": svc.max_offset_h()}


@app.get("/fleet")
def fleet(offset_h: float = Query(0.0, ge=0.0), status: list[StatusFilter] | None = Query(None),
          include_arrived: bool = False) -> dict[str, Any]:
    df = service().fleet_state(offset_h)
    if not include_arrived:
        df = df[df["status"] != ARRIVED]
    if status:
        df = df[df["status"].isin(status)]
    summary = df["status"].value_counts().to_dict()
    return {"offset_h": offset_h, "summary": summary, "containers": records(df[FLEET_FIELDS])}


@app.get("/containers/{container_id}")
def container(container_id: str, offset_h: float = Query(0.0, ge=0.0),
              history_hours: float = Query(48.0, gt=0.0)) -> dict[str, Any]:
    svc = service()
    row = container_row(svc.fleet_state(offset_h), container_id)
    hist = svc.container_history(container_id, offset_h)
    hist = hist[hist["elapsed_h"] >= hist["elapsed_h"].max() - history_hours]
    cols = ["timestamp", "elapsed_h", "lat", "lon", "activity", "return_air_temp_c", "supply_air_temp_c", "pulp_temp_c",
            "setpoint_c", "relative_humidity_pct", "vibration_peak_g", "door_open", "power_on",
            "compressor_duty_cycle", "predicted_rsl_days"]
    return {"state": records(pd.DataFrame([row[FLEET_FIELDS]]))[0], "history": records(hist[cols]),
            "projection": records(svc.rsl_projection(row))}


@app.get("/containers/{container_id}/recommendations")
def recommendations(container_id: str, offset_h: float = Query(0.0, ge=0.0),
                    top_k: int = Query(5, ge=1, le=20)) -> dict[str, Any]:
    svc = service()
    row = container_row(svc.fleet_state(offset_h), container_id)
    if row["status"] == ARRIVED:
        raise HTTPException(status_code=409, detail="Container has already arrived")
    recs = svc.recommendations(pd.DataFrame([row]).reset_index(drop=True), top_k=top_k)[0]
    return {"container_id": container_id, "any_feasible": bool(recs["feasible"].any()), "options": records(recs)}


@app.get("/fleet/assignments")
def assignments(offset_h: float = Query(0.0, ge=0.0)) -> dict[str, Any]:
    svc = service()
    plan = svc.assignments(svc.fleet_state(offset_h))
    return {"offset_h": offset_h, "diversions": int((plan["action"] == "divert").sum()),
            "total_gain_usd": float(plan["gain_usd"].sum()) if not plan.empty else 0.0, "assignments": records(plan)}


@app.post("/containers/{container_id}/decisions", status_code=201)
def decide(container_id: str, req: DecisionRequest) -> dict[str, Any]:
    svc = service()
    row = container_row(svc.fleet_state(req.offset_h), container_id)
    if row["status"] == ARRIVED:
        raise HTTPException(status_code=409, detail="Container has already arrived")
    recs = svc.recommendations(pd.DataFrame([row]).reset_index(drop=True), top_k=20)[0].set_index("buyer_code")
    if req.buyer_code not in recs.index:
        raise HTTPException(status_code=422, detail=f"{req.buyer_code} is not an eligible buyer for this load")
    plan = recs[recs["is_planned_destination"]]
    plan_value = float(plan["net_salvage_value_usd"].iloc[0]) if not plan.empty else float("nan")
    chosen = recs.loc[req.buyer_code].squeeze()
    if not isinstance(chosen, pd.Series):
        raise HTTPException(status_code=500, detail="Ambiguous buyer option")
    action: Literal["divert", "continue"] = "continue" if bool(chosen["is_planned_destination"]) else "divert"
    return svc.log_action(row, action, req.buyer_code, float(chosen["net_salvage_value_usd"]), plan_value,
                          req.operator, req.note)


@app.get("/decisions")
def decisions() -> dict[str, Any]:
    return {"decisions": records(service().action_log())}
